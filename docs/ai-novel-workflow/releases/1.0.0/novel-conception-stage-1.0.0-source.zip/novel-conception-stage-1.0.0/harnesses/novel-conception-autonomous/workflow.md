# Autonomous Novel-Conception V2 Workflow

## Fixed graph

```text
B0 → S1 → W1 → E1 → T1 → C1 → Q1 → P1
                                      ↓
H1-A plan → H1-B fragments → independent fidelity review → H1-A assemble → H1-C render
                                      ↓
                         formal H1 completion
                                      ↓
                    external sealed author decision
                      ↙             ↓             ↘
                 approved         revise        rejected
                    ↓               │               │
          final completion     routed return      stop
                    ↓
          development_status=ready
```

The diagram is logical: P1 is the sole top-level input to H1-A plan, while all
H1 packages and workspaces carry the same run/session/lineage.

The independent fidelity review is a bounded quality dependency, not another
top-level stage and not a content producer. It reads only sealed P1, plan,
fragments and the candidate report, and H1-A consumes its pass verdict before
publishing the assembly package. A missing, producer-authored, incomplete or
semantically failing review blocks assembly.

## P1 crash recovery boundary

If the P1 destination already exists, the P1 runtime must not overwrite or
repair it. It may reuse a fully valid package only when its sealed input gate,
B0-Q1 source packages, hashes, lineage, and implementation snapshot exactly
match the current invocation. The coordinator must either be at the exact
recorded pre-state with P1 non-current, or, for forward mode only, at a
persistent successor whose `previous_state`, current P1 completion, and
successor reference path exactly match. The runtime revalidates the package
and current sources read-only, repeats the source inventory check immediately
before coordinator admission, and leaves the existing directory byte-for-byte
unchanged.

The pre-state case returns `P1RunReceipt.replayed=true` and
`transition.replayed=false`; exact forward persistent replay returns both as
`true`. A return-resolution completion already present in `resolved_returns`
is strictly one-shot: propagate `COORD_RETURN_ALREADY_RESOLVED` unchanged and
return no new receipt. A partial, invalid, tampered, stale, differently gated,
or differently sourced directory fails closed and remains in place for
forensic inspection. Recovery is a runtime rule and does not change the public
JSON Schemas. Packages carrying an older implementation snapshot, including
the A4 artifact, are stale and must not be reused.

## H1 crash recovery boundary

The formal H1 publisher uses the same fail-closed publication boundary without
turning H1-A/B/C workspaces into top-level stages. If `H1/stage` already exists,
the publisher never overwrites, repairs, merges, or deletes it. It may reuse
the directory only after validating the complete formal package against the
current rendered workspace, current P1/plan/fragments/assembly/HTML packages,
their byte inventories, the exact sealed plan input gate and state-before,
the current implementation snapshot, and the canonical H1 completion.

At the recorded pre-state, accepting a valid non-current orphan returns
`H1CompletionReceipt.replayed=true` and `transition.replayed=false`. A
coordinator reconstructed from the exact forward `waiting_author` successor
must additionally match `previous_state`, current H1 completion, rendered H1
workspace, and `next_state_path`; its persistent replay returns both flags as
`true`. Coordinator errors are propagated unchanged. Partial, tampered, stale,
foreign, differently gated, differently sourced, or differently pathed
packages fail closed and remain untouched. If atomic publication loses a race,
only an independently valid exact winner is recovered.

## Public production invocation

For a new approved interview baseline, call
`runtime.production_orchestrator.initialize_production_run`. For every later
process or Agent turn, call `resume_production_run`; the append-only state chain,
not conversation memory, is authoritative.

The scheduler then repeats this transaction:

1. `issue_stage_work(action=...)` builds the exact current input gate and one
   pending work order. The action fixes its owner through `ACTION_CONTRACT` and
   `dependency-spec.json`.
2. The owner submits its exact actor id and executes its existing controlled
   start/submit/run API. The orchestrator rejects an actor mismatch before the
   executor is called. Domain content never enters the orchestrator.
3. `execute_stage_work` persists a top-level transition, or
   `commit_h1_workspace` persists an H1 internal transition.
4. A crash reloads the latest valid state. A published package orphan may be
   admitted only after its owning validator passes and the recovery API proves
   the current gate, state and completion.

Before any state/workspace successor is persisted, the orchestrator writes an
immutable commit intent binding the work order, actor, input gate, H1
predecessor (when present), successor kind and exact successor hash. If a crash
occurs before the consumed marker is written, `resume_production_run` reconciles
only the byte-exact successor named by that intent. An unjournaled or ambiguous
successor fails closed. Input-gate paths include both the state revision and
action, so a routed return never overwrites its forward gate.

The intent is prepared only after a fresh coordinator reconstructed from the
persisted predecessor recomputes the complete state transition from the exact
gate and owner completion. Author revise additionally reuses and compares the
sealed return request, including its round-specific `return_id`. H1 internal
work similarly proves the exact owner manifest and complete workspace delta.

After P1, call `initialize_h1_workspace` exactly once for the new H1 session.
Repeating the same session id is an idempotent recovery; a different session
cannot replace an active workspace. A new session is admitted only when a new
P1 invalidates the old binding or a sealed H1 return requires a revision.

Only one pending work order may exist. Work orders are immutable and one-shot;
wrong owners, stale contexts, forged bodies, direct state writes and semantic
fallback owners fail closed.

## Author and final transactions

After H1-C, issue `H1-publish` and call `publish_h1_transaction`. Persist the
resulting `waiting_author` state before requesting a decision. The next process
may resume that state and issue `author-decision`; `record_author_transaction`
accepts only the external sealed event.

- `revise` persists its return body first, then the state and deterministic
  invalidation route.
- `rejected` persists the terminal state and creates no final completion.
- `approved` persists approval; a later resumable `final` transaction alone may
  call `publish_final_transaction` and grant development admission.

No transaction overwrites an existing package or invents a missing decision.

## Terminal compatibility API

`runtime.harness.run_from_rendered_h1` remains available only for callers that
already own a complete rendered H1 chain and can finish its old atomic boundary.
It is not the public entry for new interview-to-conception work and must not be
used to bypass persisted production work orders.
