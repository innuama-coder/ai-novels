from __future__ import annotations

import importlib
import json
import tempfile
import types
import unittest
from concurrent.futures import ThreadPoolExecutor
from unittest import mock
from pathlib import Path


rt = importlib.import_module("harnesses.novel-conception-autonomous.runtime")
prod = importlib.import_module(
    "harnesses.novel-conception-autonomous.runtime.production_orchestrator"
)
store_module = importlib.import_module(
    "harnesses.novel-conception-autonomous.runtime.production_store"
)


class ProductionOrchestratorTests(unittest.TestCase):
    def setUp(self) -> None:
        self.temporary = tempfile.TemporaryDirectory(prefix="prod-orchestrator-")
        self.root = Path(self.temporary.name)

    def tearDown(self) -> None:
        self.temporary.cleanup()

    def _context(self):
        return prod.initialize_production_run(
            self.root,
            run_id="RUN-PROD-1",
            source_interview_state={
                "path": "interview/interview-state.json",
                "sha256": "1" * 64,
            },
        )

    @staticmethod
    def _fake_executor(stage: str, revision: int):
        def execute(coordinator, gate):
            completion_data = {
                "schema_version": "2.0",
                "run_id": "RUN-PROD-1",
                "stage": stage,
                "status": "ready",
                "manifest": {
                    "path": f"{stage}/package-manifest.json",
                    "sha256": "a" * 64,
                },
                "validation": {
                    "path": f"{stage}/validation.json",
                    "sha256": "b" * 64,
                },
                "input_gate": gate.reference,
                "state_before": gate.data["run_state"],
                "previous_stage_completions": gate.data[
                    "upstream_completions"
                ],
                "return_binding": gate.data["return_binding"],
            }
            if stage in {"S1", "W1", "E1", "T1", "C1", "Q1", "H1"}:
                completion_data["session_id"] = f"SESSION-{stage}"
            completion = rt.seal_stage_document(
                completion_data,
                stage,
                f"{stage}/stage-completion.json",
            )
            transition = coordinator.accept_stage_completion(
                gate=gate,
                completion=completion,
                next_state_path=f"state/revision-{revision:03d}.json",
            )
            return types.SimpleNamespace(
                transition=transition, completion=completion
            )

        return execute

    def test_state_is_durable_and_work_order_is_one_shot(self) -> None:
        context = self._context()
        self.assertTrue((self.root / "state" / "revision-000.json").is_file())
        gate, order = prod.issue_stage_work(
            context,
            action="B0",
            inputs={"source_root": "interview"},
        )
        self.assertTrue((self.root / gate.reference["path"]).is_file())
        _, successor = prod.execute_stage_work(
            context,
            work_order=order,
            actor="baseline-controller",
            executor=self._fake_executor("B0", 1),
        )
        self.assertEqual(1, successor.state.data["revision"])
        resumed = prod.resume_production_run(self.root)
        self.assertEqual(successor.state.reference, resumed.state.reference)
        self.assertIn("B0", resumed.state.data["current_stage_completions"])
        with self.assertRaises(store_module.ProductionStoreError):
            prod.execute_stage_work(
                resumed,
                work_order=order,
                actor="baseline-controller",
                executor=self._fake_executor("B0", 2),
            )

    def test_latest_state_rejects_hash_chain_tampering(self) -> None:
        context = self._context()
        _, order = prod.issue_stage_work(
            context,
            action="B0",
            inputs={},
        )
        prod.execute_stage_work(
            context,
            work_order=order,
            actor="baseline-controller",
            executor=self._fake_executor("B0", 1),
        )
        path = self.root / "state" / "revision-001.json"
        body = json.loads(path.read_text(encoding="utf-8"))
        body["status"] = "rejected"
        path.write_text(json.dumps(body), encoding="utf-8")
        with self.assertRaises(store_module.ProductionStoreError):
            prod.resume_production_run(self.root)

    def test_pending_order_blocks_competing_order_and_actor_is_fixed(self) -> None:
        context = self._context()
        _, order = prod.issue_stage_work(
            context, action="B0", inputs={"candidate": 1}
        )
        self.assertEqual("baseline-controller", order.data["required_actor"])
        with self.assertRaises(store_module.ProductionStoreError) as caught:
            prod.issue_stage_work(
                context, action="B0", inputs={"candidate": 2}
            )
        self.assertEqual("PROD_PENDING_WORK_EXISTS", caught.exception.code)
        with self.assertRaises(prod.ProductionOrchestratorError):
            prod.issue_stage_work(context, action="legacy-D1", inputs={})

    def test_wrong_actor_is_rejected_before_executor_and_keeps_order_pending(self) -> None:
        context = self._context()
        _, order = prod.issue_stage_work(context, action="B0", inputs={})
        executor = mock.Mock(side_effect=self._fake_executor("B0", 1))
        with self.assertRaises(prod.ProductionOrchestratorError) as caught:
            prod.execute_stage_work(
                context,
                work_order=order,
                actor="novel-development-map-designer",
                executor=executor,
            )
        self.assertEqual("PROD_WORK_ACTOR_MISMATCH", caught.exception.code)
        executor.assert_not_called()
        self.assertEqual(0, context.store.latest_state().data["revision"])
        _, successor = prod.execute_stage_work(
            context,
            work_order=order,
            actor="baseline-controller",
            executor=self._fake_executor("B0", 1),
        )
        self.assertEqual(1, successor.state.data["revision"])

    def test_resume_reconciles_state_successor_before_consumed_marker(self) -> None:
        context = self._context()
        gate, order = prod.issue_stage_work(context, action="B0", inputs={})
        receipt = self._fake_executor("B0", 1)(context.coordinator, gate)
        successor = rt.SealedDocument(
            receipt.transition.snapshot, receipt.transition.reference
        )
        prod._prepare_state_commit(
            context, order, successor, receipt.completion
        )
        context.store.persist_state(successor)

        resumed = prod.resume_production_run(self.root)
        self.assertEqual(1, resumed.state.data["revision"])
        _, next_order = prod.issue_stage_work(
            resumed, action="S1", inputs={}
        )
        self.assertEqual("S1", next_order.data["action"])

    def test_resume_rejects_unjournaled_direct_state_successor(self) -> None:
        context = self._context()
        gate, _order = prod.issue_stage_work(context, action="B0", inputs={})
        receipt = self._fake_executor("B0", 1)(context.coordinator, gate)
        successor = rt.SealedDocument(
            receipt.transition.snapshot, receipt.transition.reference
        )
        context.store.persist_state(successor)
        with self.assertRaises(prod.ProductionOrchestratorError) as caught:
            prod.resume_production_run(self.root)
        self.assertEqual("PROD_UNJOURNALED_SUCCESSOR", caught.exception.code)

    def test_commit_prepare_rejects_extra_stage_and_store_cannot_self_sign(self) -> None:
        context = self._context()
        gate, order = prod.issue_stage_work(context, action="B0", inputs={})
        receipt = self._fake_executor("B0", 1)(context.coordinator, gate)
        forged = dict(receipt.transition.snapshot)
        forged["current_stage_completions"] = {
            **forged["current_stage_completions"],
            "S1": {
                "stage": "S1",
                "path": "S1/stage-completion.json",
                "sha256": "6" * 64,
            },
        }
        forged_successor = rt.seal_document(
            forged, "state/revision-001.json"
        )
        with self.assertRaises(prod.ProductionOrchestratorError) as caught:
            prod._prepare_state_commit(
                context, order, forged_successor, receipt.completion
            )
        self.assertEqual("PROD_COMMIT_DELTA_INVALID", caught.exception.code)
        self.assertFalse(hasattr(context.store, "persist_commit_intent"))

    def test_commit_prepare_rejects_early_approved_ready_control_state(self) -> None:
        context = self._context()
        gate, order = prod.issue_stage_work(context, action="B0", inputs={})
        receipt = self._fake_executor("B0", 1)(context.coordinator, gate)
        forged = dict(receipt.transition.snapshot)
        forged["status"] = "approved"
        forged["development_status"] = "ready"
        forged["author_decision"] = {
            "path": "author/forged-decision.json",
            "sha256": "7" * 64,
        }
        forged_successor = rt.seal_document(
            forged, "state/revision-001.json"
        )
        with self.assertRaises(prod.ProductionOrchestratorError) as caught:
            prod._prepare_state_commit(
                context, order, forged_successor, receipt.completion
            )
        self.assertEqual("PROD_COMMIT_DELTA_INVALID", caught.exception.code)

    def test_prepared_intent_without_successor_remains_pending(self) -> None:
        context = self._context()
        gate, order = prod.issue_stage_work(context, action="B0", inputs={})
        receipt = self._fake_executor("B0", 1)(context.coordinator, gate)
        successor = rt.SealedDocument(
            receipt.transition.snapshot, receipt.transition.reference
        )
        prod._prepare_state_commit(
            context, order, successor, receipt.completion
        )
        resumed = prod.resume_production_run(self.root)
        self.assertEqual(0, resumed.state.data["revision"])
        self.assertEqual(
            order.reference, resumed.store.pending_work_order().reference
        )

    def test_forged_work_order_object_is_rejected(self) -> None:
        context = self._context()
        _, order = prod.issue_stage_work(context, action="B0", inputs={})
        forged = rt.SealedDocument(
            data={**order.data, "inputs": {"forged": True}},
            reference=order.reference,
        )
        with self.assertRaises(store_module.ProductionStoreError) as caught:
            prod.execute_stage_work(
                context,
                work_order=forged,
                actor="baseline-controller",
                executor=self._fake_executor("B0", 1),
            )
        self.assertEqual("PROD_WORK_ORDER_FORGED", caught.exception.code)

    def test_initialize_existing_run_fails_and_workspace_recovers(self) -> None:
        context = self._context()
        with self.assertRaises(store_module.ProductionStoreError) as caught:
            self._context()
        self.assertEqual("PROD_RUN_EXISTS", caught.exception.code)
        workspace = rt.seal_document(
            {
                "schema_version": "2.0",
                "run_id": "RUN-PROD-1",
                "stage": "H1",
                "session_id": "H1-SESSION",
                "state": "initialized",
                "p1_completion": {
                    "stage": "P1",
                    "path": "P1/stage-completion.json",
                    "sha256": "2" * 64,
                },
                "previous_state_sha256": None,
                "artifacts": {},
            },
            "H1/H1-SESSION/workspace-initialized.json",
        )
        context.store.persist_workspace(workspace)
        self.assertEqual(
            workspace.reference, context.store.latest_workspace().reference
        )

    def test_h1_workspace_initialization_is_idempotent_but_not_replaceable(self) -> None:
        context = self._context()
        for revision, stage in enumerate(
            ("B0", "S1", "W1", "E1", "T1", "C1", "Q1", "P1"), 1
        ):
            _, order = prod.issue_stage_work(context, action=stage, inputs={})
            _, context = prod.execute_stage_work(
                context,
                work_order=order,
                actor=prod.ACTION_CONTRACT[stage][1],
                executor=self._fake_executor(stage, revision),
            )
        workspace = prod.initialize_h1_workspace(
            context, session_id="H1-SESSION-1"
        )
        replay = prod.initialize_h1_workspace(
            context, session_id="H1-SESSION-1"
        )
        self.assertEqual(workspace.reference, replay.reference)
        with self.assertRaises(prod.ProductionOrchestratorError) as caught:
            prod.initialize_h1_workspace(context, session_id="H1-SESSION-2")
        self.assertEqual("PROD_H1_SESSION_EXISTS", caught.exception.code)

    def test_h1_work_order_binds_workspace_and_resume_reconciles_successor(self) -> None:
        context = self._context()
        for revision, stage in enumerate(
            ("B0", "S1", "W1", "E1", "T1", "C1", "Q1", "P1"), 1
        ):
            _, order = prod.issue_stage_work(context, action=stage, inputs={})
            _, context = prod.execute_stage_work(
                context,
                work_order=order,
                actor=prod.ACTION_CONTRACT[stage][1],
                executor=self._fake_executor(stage, revision),
            )
        initialized = prod.initialize_h1_workspace(
            context, session_id="H1-BOUND"
        )
        _, order = prod.issue_stage_work(
            context, action="H1-A-plan", inputs={}
        )
        self.assertEqual(initialized.reference, order.data["h1_workspace"])
        item = {"path": "H1/H1-BOUND/plan/item.json", "sha256": "5" * 64}
        manifest = rt.seal_document(
            {
                "schema_version": "2.0",
                "run_id": "RUN-PROD-1",
                "stage": "H1",
                "package_profile": "h1-plan",
                "verdict": "ready",
                "files": [item],
                "artifact_roles": {
                    "source_inventory": item,
                    "review_plan": item,
                    "fragment_briefs": item,
                    "generation_session": item,
                    "generation_evidence_index": item,
                    "execution_record": item,
                },
                "validation": item,
                "implementation": [item],
                "parent_state_sha256": initialized.reference["sha256"],
                "session_id": "H1-BOUND",
            },
            "H1/H1-BOUND/plan/package-manifest.json",
        )
        planned = rt.seal_document(
            {
                **initialized.data,
                "state": "planned",
                "previous_state_sha256": initialized.reference["sha256"],
                "artifacts": {"plan_manifest": manifest.reference},
            },
            "H1/H1-BOUND/workspace-planned.json",
        )
        prod._prepare_h1_commit(
            context,
            order,
            bound=initialized,
            successor=planned,
            manifest=manifest,
        )
        context.store.persist_workspace(planned)

        resumed = prod.resume_production_run(self.root)
        _, next_order = prod.issue_stage_work(
            resumed, action="H1-B", inputs={}
        )
        self.assertEqual(planned.reference, next_order.data["h1_workspace"])

    def test_resume_rejects_unjournaled_h1_workspace_successor(self) -> None:
        context = self._context()
        for revision, stage in enumerate(
            ("B0", "S1", "W1", "E1", "T1", "C1", "Q1", "P1"), 1
        ):
            _, order = prod.issue_stage_work(context, action=stage, inputs={})
            _, context = prod.execute_stage_work(
                context,
                work_order=order,
                actor=prod.ACTION_CONTRACT[stage][1],
                executor=self._fake_executor(stage, revision),
            )
        initialized = prod.initialize_h1_workspace(
            context, session_id="H1-UNJOURNALED"
        )
        prod.issue_stage_work(context, action="H1-A-plan", inputs={})
        planned = rt.seal_document(
            {
                **initialized.data,
                "state": "planned",
                "previous_state_sha256": initialized.reference["sha256"],
                "artifacts": {
                    "plan_manifest": {
                        "path": "H1/H1-UNJOURNALED/plan/package-manifest.json",
                        "sha256": "4" * 64,
                    }
                },
            },
            "H1/H1-UNJOURNALED/workspace-planned.json",
        )
        context.store.persist_workspace(planned)
        with self.assertRaises(prod.ProductionOrchestratorError) as caught:
            prod.resume_production_run(self.root)
        self.assertEqual("PROD_UNJOURNALED_SUCCESSOR", caught.exception.code)

    def test_h1_commit_rejects_workspace_pointer_divergence_before_executor(self) -> None:
        context = self._context()
        for revision, stage in enumerate(
            ("B0", "S1", "W1", "E1", "T1", "C1", "Q1", "P1"), 1
        ):
            _, order = prod.issue_stage_work(context, action=stage, inputs={})
            _, context = prod.execute_stage_work(
                context,
                work_order=order,
                actor=prod.ACTION_CONTRACT[stage][1],
                executor=self._fake_executor(stage, revision),
            )
        initialized = prod.initialize_h1_workspace(
            context, session_id="H1-ORIGINAL"
        )
        _, order = prod.issue_stage_work(
            context, action="H1-A-plan", inputs={}
        )
        foreign = rt.seal_document(
            {**initialized.data, "session_id": "H1-FOREIGN"},
            "H1/H1-FOREIGN/workspace-initialized.json",
        )
        context.store.persist_workspace(foreign)
        executor = mock.Mock()
        with self.assertRaises(prod.ProductionOrchestratorError) as caught:
            prod.commit_h1_workspace(
                context,
                work_order=order,
                actor=prod.ACTION_CONTRACT["H1-A-plan"][1],
                executor=executor,
            )
        self.assertEqual("PROD_H1_WORKSPACE_STALE", caught.exception.code)
        executor.assert_not_called()

    def test_concurrent_pending_publication_has_one_winner(self) -> None:
        context = self._context()

        def issue(candidate):
            try:
                return prod.issue_stage_work(
                    context, action="B0", inputs={"candidate": candidate}
                )[1].data["work_id"]
            except store_module.ProductionStoreError as error:
                return error.code

        with ThreadPoolExecutor(max_workers=2) as pool:
            results = list(pool.map(issue, (1, 2)))
        self.assertEqual(1, results.count("PROD_PENDING_WORK_EXISTS"))
        self.assertEqual(1, sum(value != "PROD_PENDING_WORK_EXISTS" for value in results))

    def _waiting_author_context(self):
        context = self._context()
        for revision, stage in enumerate(
            ("B0", "S1", "W1", "E1", "T1", "C1", "Q1", "P1"), 1
        ):
            _, order = prod.issue_stage_work(
                context, action=stage, inputs={}
            )
            _, context = prod.execute_stage_work(
                context,
                work_order=order,
                actor=prod.ACTION_CONTRACT[stage][1],
                executor=self._fake_executor(stage, revision),
            )
        workspace = rt.seal_document(
            {
                "schema_version": "2.0",
                "run_id": "RUN-PROD-1",
                "stage": "H1",
                "session_id": "H1-READY",
                "state": "rendered",
                "p1_completion": context.state.data[
                    "current_stage_completions"
                ]["P1"],
                "previous_state_sha256": "3" * 64,
                "artifacts": {
                    "plan_manifest": {"path": "H1/plan.json", "sha256": "4" * 64},
                    "fragment_manifest": {"path": "H1/fragments.json", "sha256": "5" * 64},
                    "assembly_manifest": {"path": "H1/assembly.json", "sha256": "6" * 64},
                    "html_manifest": {"path": "H1/html.json", "sha256": "7" * 64},
                },
            },
            "H1/H1-READY/workspace-rendered.json",
        )
        context.store.persist_workspace(workspace)
        _, order = prod.issue_stage_work(
            context, action="H1-publish", inputs={}
        )
        gate = context.store.load_document(order.data["input_gate"])
        plan_gate = rt.SealedDocument(
            data=json.loads(json.dumps(gate.data)),
            reference={
                "path": "orchestration/input-gates/revision-008-H1-A-plan/input-gate.json",
                "sha256": gate.reference["sha256"],
            },
        )
        context.store.persist_document(plan_gate)
        completion = rt.seal_stage_document(
            {
                "schema_version": "2.0",
                "run_id": "RUN-PROD-1",
                "stage": "H1",
                "status": "ready",
                "manifest": {"path": "H1/stage/package-manifest.json", "sha256": "8" * 64},
                "validation": {"path": "H1/stage/validation.json", "sha256": "9" * 64},
                "input_gate": plan_gate.reference,
                "state_before": plan_gate.data["run_state"],
                "previous_stage_completions": plan_gate.data["upstream_completions"],
                "return_binding": None,
                "session_id": "H1-READY",
            },
            "H1",
            "H1/stage/stage-completion.json",
        )
        transition = context.coordinator.accept_stage_completion(
            gate=plan_gate,
            completion=completion,
            h1_workspace=workspace.reference,
            next_state_path="state/revision-009.json",
        )
        waiting = rt.SealedDocument(transition.snapshot, transition.reference)
        prod._prepare_state_commit(context, order, waiting, completion)
        context.store.persist_state(waiting)
        context.store.mark_work_order_consumed(order, successor=waiting)
        return prod.resume_production_run(self.root)

    def test_waiting_author_and_approved_final_transactions_resume(self) -> None:
        waiting = self._waiting_author_context()
        self.assertEqual("waiting_author", waiting.state.data["status"])
        _, author_order = prod.issue_stage_work(
            waiting, action="author-decision", inputs={"external": True}
        )
        event = rt.seal_document(
            {
                "schema_version": "2.0",
                "run_id": "RUN-PROD-1",
                "approval_scope": "conception",
                "decision": "approved",
                "machine_package": {
                    "completion_path": "P1/stage-completion.json",
                    "completion_sha256": "a" * 64,
                    "manifest_path": "P1/package-manifest.json",
                    "manifest_sha256": "b" * 64,
                },
                "human_review_package": {
                    "completion_path": "H1/stage/stage-completion.json",
                    "completion_sha256": "c" * 64,
                    "manifest_path": "H1/stage/package-manifest.json",
                    "manifest_sha256": "d" * 64,
                    "html_path": "H1/html/report.html",
                    "html_sha256": "e" * 64,
                },
                "approval_record": {"event_seq": 1, "text": "approved"},
                "unresolved_items": [],
            },
            "author/decision.json",
        )
        _, approved = prod.record_author_transaction(
            waiting, work_order=author_order, event=event
        )
        approved = prod.resume_production_run(self.root)
        self.assertEqual("approved", approved.state.data["status"])
        _, final_order = prod.issue_stage_work(
            approved, action="final", inputs={}
        )

        def fake_final(_root, *, coordinator, next_state_path, **_kwargs):
            completion = rt.seal_document(
                {
                    "schema_version": "2.0",
                    "run_id": "RUN-PROD-1",
                    "status": "ready",
                    "run_state": coordinator.state_reference,
                    "stage_completions": coordinator.state["current_stage_completions"],
                    "p1_manifest": {"path": "P1/package-manifest.json", "sha256": "1" * 64},
                    "h1_html_manifest": {"path": "H1/html/package-manifest.json", "sha256": "2" * 64},
                    "author_decision": event.reference,
                    "development_handoff": {"path": "P1/development-handoff.json", "sha256": "3" * 64},
                    "validation": {"path": "completion/validation.json", "sha256": "4" * 64},
                },
                "completion/conception-completion.json",
            )
            transition = coordinator.accept_final_completion(
                completion=completion, next_state_path=next_state_path
            )
            return types.SimpleNamespace(
                transition=transition, completion=completion
            )

        with mock.patch.object(prod, "publish_final_completion", fake_final):
            _, final = prod.publish_final_transaction(
                approved,
                self.root / "completion",
                work_order=final_order,
            )
        final = prod.resume_production_run(self.root)
        self.assertEqual("ready", final.state.data["development_status"])

    def test_revise_uses_revisioned_gate_without_overwriting_forward_gate(self) -> None:
        waiting = self._waiting_author_context()
        _, author_order = prod.issue_stage_work(
            waiting, action="author-decision", inputs={"external": True}
        )
        event = rt.seal_document(
            {
                "schema_version": "2.0",
                "run_id": "RUN-PROD-1",
                "approval_scope": "conception",
                "decision": "revise",
                "machine_package": {
                    "completion_path": "P1/stage-completion.json",
                    "completion_sha256": "a" * 64,
                    "manifest_path": "P1/package-manifest.json",
                    "manifest_sha256": "b" * 64,
                },
                "human_review_package": {
                    "completion_path": "H1/stage/stage-completion.json",
                    "completion_sha256": "c" * 64,
                    "manifest_path": "H1/stage/package-manifest.json",
                    "manifest_sha256": "d" * 64,
                    "html_path": "H1/html/report.html",
                    "html_sha256": "e" * 64,
                },
                "revision_record": {
                    "event_seq": 2,
                    "text": "Revise the approved intent baseline.",
                },
                "revision_targets": [
                    {
                        "target_scope": "conception",
                        "visible_element_ids": [],
                        "source_ids": ["INT-001"],
                        "requested_change": "Revise the intent baseline.",
                    }
                ],
            },
            "author/revise-decision.json",
        )
        _, revised = prod.record_author_transaction(
            waiting,
            work_order=author_order,
            event=event,
            return_id="RET-PRODUCTION-ROUND-1",
        )
        revised = prod.resume_production_run(self.root)
        self.assertEqual("revise", revised.state.data["status"])
        self.assertEqual(
            "RET-PRODUCTION-ROUND-1",
            revised.active_return.data["return_id"],
        )
        forward_gate = self.root / "orchestration/input-gates/revision-000-B0/input-gate.json"
        self.assertTrue(forward_gate.is_file())
        gate, order = prod.issue_stage_work(
            revised, action="B0", inputs={"return": True}
        )
        self.assertNotEqual(
            "orchestration/input-gates/revision-000-B0/input-gate.json",
            gate.reference["path"],
        )
        self.assertEqual("B0", order.data["action"])


if __name__ == "__main__":
    unittest.main()
