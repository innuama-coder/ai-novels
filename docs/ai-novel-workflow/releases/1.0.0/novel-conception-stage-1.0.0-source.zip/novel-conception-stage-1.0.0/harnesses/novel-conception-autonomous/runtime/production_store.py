"""Durable control-plane storage for the production conception runner.

The portable coordinator deliberately keeps state in memory.  This store is
the single persistence owner used by the production orchestrator: snapshots
remain append-only, a mutable pointer is only a cache, and recovery always
rebuilds the hash-linked chain before selecting the latest revision.
"""

from __future__ import annotations

import json
import os
import tempfile
from contextlib import contextmanager
from pathlib import Path, PurePosixPath
from typing import Any, Iterator, Mapping

from .canonical import canonical_json, canonical_sha256, sha256_file
from .contracts import ContractRuntime, ContractValidationError
from .coordinator import SealedDocument


class ProductionStoreError(ValueError):
    def __init__(self, code: str, message: str):
        self.code = code
        super().__init__(f"{code}: {message}")


def _fail(code: str, message: str) -> None:
    raise ProductionStoreError(code, message)


class ProductionRunStore:
    """Append-only state/workspace store rooted in one run directory."""

    def __init__(self, root: str | Path, *, runtime: ContractRuntime | None = None):
        self.root = Path(root).resolve()
        self.runtime = runtime or ContractRuntime()

    def _path(self, logical: str) -> Path:
        pure = PurePosixPath(logical)
        if pure.is_absolute() or not pure.parts or ".." in pure.parts:
            _fail("PROD_PATH_INVALID", logical)
        target = (self.root / Path(*pure.parts)).resolve()
        try:
            target.relative_to(self.root)
        except ValueError:
            _fail("PROD_PATH_ESCAPE", logical)
        return target

    @contextmanager
    def lock(self) -> Iterator[None]:
        """Take an OS-held exclusive lock which is released on process death."""

        self.root.mkdir(parents=True, exist_ok=True)
        path = self.root / "orchestration" / "run.lock"
        path.parent.mkdir(parents=True, exist_ok=True)
        handle = path.open("a+b")
        try:
            if os.name == "nt":
                import msvcrt

                handle.seek(0)
                if handle.tell() == 0:
                    handle.write(b"0")
                    handle.flush()
                handle.seek(0)
                msvcrt.locking(handle.fileno(), msvcrt.LK_LOCK, 1)
            else:
                import fcntl

                fcntl.flock(handle.fileno(), fcntl.LOCK_EX)
            yield
        finally:
            if os.name == "nt":
                import msvcrt

                handle.seek(0)
                msvcrt.locking(handle.fileno(), msvcrt.LK_UNLCK, 1)
            else:
                import fcntl

                fcntl.flock(handle.fileno(), fcntl.LOCK_UN)
            handle.close()

    def _write_new(self, path: Path, data: bytes) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        try:
            with path.open("xb") as handle:
                handle.write(data)
                handle.flush()
                os.fsync(handle.fileno())
        except FileExistsError:
            if path.read_bytes() != data:
                _fail("PROD_IMMUTABLE_CONFLICT", str(path))

    def _replace(self, path: Path, value: Mapping[str, Any]) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        body = canonical_json(value).encode("utf-8")
        descriptor, temporary_name = tempfile.mkstemp(
            prefix=f".{path.name}.", dir=path.parent
        )
        temporary = Path(temporary_name)
        try:
            with os.fdopen(descriptor, "wb") as handle:
                handle.write(body)
                handle.flush()
                os.fsync(handle.fileno())
            os.replace(temporary, path)
        finally:
            if temporary.exists():
                temporary.unlink()

    def persist_document(self, document: SealedDocument) -> Path:
        if canonical_sha256(document.data) != document.reference.get("sha256"):
            _fail("PROD_DOCUMENT_HASH_MISMATCH", str(document.reference))
        path = self._path(str(document.reference["path"]))
        self._write_new(path, canonical_json(document.data).encode("utf-8"))
        if sha256_file(path) != document.reference["sha256"]:
            _fail("PROD_DOCUMENT_WRITE_MISMATCH", str(path))
        return path

    def persist_state(self, document: SealedDocument) -> Path:
        self.runtime.validate(document.data, "autonomous-run-state.schema.json")
        revision = int(document.data["revision"])
        expected = f"state/revision-{revision:03d}.json"
        if document.reference.get("path") != expected:
            _fail("PROD_STATE_PATH_INVALID", str(document.reference.get("path")))
        path = self.persist_document(document)
        self._replace(
            self.root / "orchestration" / "current-state.json",
            {"schema_version": "2.0", "state": dict(document.reference)},
        )
        return path

    def ensure_uninitialized(self) -> None:
        """Reject every pre-existing run; an empty caller-created root is fine."""

        allowed_lock = self.root / "orchestration" / "run.lock"
        residue = [
            path
            for path in self.root.rglob("*")
            if path != allowed_lock
            and not (path.is_dir() and path == allowed_lock.parent)
        ]
        if residue:
            _fail("PROD_RUN_EXISTS", str(self.root))

    def load_document(self, reference: Mapping[str, str]) -> SealedDocument:
        path = self._path(str(reference["path"]))
        if not path.is_file() or sha256_file(path) != reference.get("sha256"):
            _fail("PROD_DOCUMENT_STALE", str(reference))
        data = json.loads(path.read_text(encoding="utf-8"))
        if canonical_sha256(data) != reference["sha256"]:
            _fail("PROD_DOCUMENT_NONCANONICAL", str(path))
        return SealedDocument(data=data, reference=dict(reference))

    def latest_state(self) -> SealedDocument:
        def revision_of(path: Path) -> int:
            try:
                return int(path.stem.split("-")[-1])
            except ValueError:
                _fail("PROD_STATE_FILENAME_INVALID", path.name)

        files = sorted(
            (self.root / "state").glob("revision-*.json"), key=revision_of
        )
        if not files:
            _fail("PROD_STATE_MISSING", str(self.root))
        previous: SealedDocument | None = None
        for expected_revision, path in enumerate(files):
            try:
                revision = int(path.stem.split("-")[-1])
            except ValueError:
                _fail("PROD_STATE_FILENAME_INVALID", path.name)
            if revision != expected_revision:
                _fail("PROD_STATE_CHAIN_GAP", path.name)
            data = json.loads(path.read_text(encoding="utf-8"))
            try:
                self.runtime.validate(data, "autonomous-run-state.schema.json")
            except ContractValidationError as error:
                _fail("PROD_STATE_SCHEMA_INVALID", str(error))
            reference = {
                "path": f"state/revision-{revision:03d}.json",
                "sha256": sha256_file(path),
            }
            if canonical_sha256(data) != reference["sha256"]:
                _fail("PROD_STATE_NONCANONICAL", path.name)
            if revision == 0:
                if data["previous_state"] is not None:
                    _fail("PROD_STATE_CHAIN_INVALID", path.name)
            elif previous is None or data["previous_state"] != previous.reference:
                _fail("PROD_STATE_CHAIN_INVALID", path.name)
            previous = SealedDocument(data=data, reference=reference)
        assert previous is not None
        return previous

    def persist_workspace(self, workspace: SealedDocument) -> Path:
        self.runtime.validate(workspace.data, "h1-workspace-state.schema.json")
        path = self.persist_document(workspace)
        self._replace(
            self.root / "orchestration" / "current-h1-workspace.json",
            {"schema_version": "2.0", "workspace": workspace.reference},
        )
        return path

    def latest_workspace(self) -> SealedDocument:
        pointer = self.root / "orchestration" / "current-h1-workspace.json"
        if not pointer.is_file():
            _fail("PROD_H1_WORKSPACE_MISSING", str(pointer))
        value = json.loads(pointer.read_text(encoding="utf-8"))
        return self.load_document(value["workspace"])

    def issue_work_order(
        self,
        *,
        run_id: str,
        action: str,
        state: SealedDocument,
        input_gate: SealedDocument | None,
        h1_workspace: SealedDocument | None,
        required_actor: str,
        inputs: Mapping[str, Any],
    ) -> SealedDocument:
        body = {
            "schema_version": "2.0",
            "run_id": run_id,
            "action": action,
            "state": dict(state.reference),
            "input_gate": (
                dict(input_gate.reference) if input_gate is not None else None
            ),
            "h1_workspace": (
                dict(h1_workspace.reference)
                if h1_workspace is not None
                else None
            ),
            "required_actor": required_actor,
            "inputs": dict(inputs),
            "status": "pending",
        }
        work_id = canonical_sha256(body)[:24]
        document = SealedDocument(
            data={**body, "work_id": work_id},
            reference={
                "path": f"orchestration/work-orders/{work_id}.json",
                "sha256": canonical_sha256({**body, "work_id": work_id}),
            },
        )
        pointer_path = self.root / "orchestration" / "current-work-order.json"
        if pointer_path.is_file():
            pointer = json.loads(pointer_path.read_text(encoding="utf-8"))
            prior = self.load_document(pointer["work_order"])
            consumed = self.root / "orchestration" / "work-orders" / (
                f"{prior.data['work_id']}.consumed.json"
            )
            if not consumed.exists():
                if prior.reference == document.reference and prior.data == document.data:
                    return prior
                _fail("PROD_PENDING_WORK_EXISTS", prior.data["work_id"])
        self.persist_document(document)
        self._replace(
            self.root / "orchestration" / "current-work-order.json",
            {"schema_version": "2.0", "work_order": document.reference},
        )
        return document

    def pending_work_order(self) -> SealedDocument | None:
        """Return the current unconsumed work order, if one exists."""

        current = self.root / "orchestration" / "current-work-order.json"
        if not current.is_file():
            return None
        pointer = json.loads(current.read_text(encoding="utf-8"))
        order = self.load_document(pointer["work_order"])
        consumed = self.root / "orchestration" / "work-orders" / (
            f"{order.data['work_id']}.consumed.json"
        )
        return None if consumed.is_file() else order

    def _persist_commit_intent(
        self,
        work_order: SealedDocument,
        *,
        successor: SealedDocument,
        successor_kind: str,
        evidence: SealedDocument,
    ) -> SealedDocument:
        """Prepare an immutable exact-successor journal before publication."""

        if successor_kind not in {"state", "h1-workspace"}:
            _fail("PROD_COMMIT_KIND_INVALID", successor_kind)
        if canonical_sha256(successor.data) != successor.reference.get("sha256"):
            _fail("PROD_COMMIT_SUCCESSOR_INVALID", str(successor.reference))
        try:
            self.runtime.validate(
                successor.data,
                (
                    "autonomous-run-state.schema.json"
                    if successor_kind == "state"
                    else "h1-workspace-state.schema.json"
                ),
            )
        except ContractValidationError as error:
            _fail("PROD_COMMIT_SUCCESSOR_INVALID", str(error))
        body = {
            "schema_version": "2.0",
            "work_order": dict(work_order.reference),
            "action": work_order.data["action"],
            "required_actor": work_order.data["required_actor"],
            "predecessor_state": dict(work_order.data["state"]),
            "input_gate": work_order.data.get("input_gate"),
            "h1_workspace": work_order.data.get("h1_workspace"),
            "successor_kind": successor_kind,
            "successor": dict(successor.reference),
            "admission_evidence": dict(evidence.reference),
            "status": "prepared",
        }
        intent = SealedDocument(
            data=body,
            reference={
                "path": (
                    "orchestration/commit-intents/"
                    f"{work_order.data['work_id']}.json"
                ),
                "sha256": canonical_sha256(body),
            },
        )
        self.persist_document(intent)
        return intent

    def _load_commit_intent(
        self, work_order: SealedDocument
    ) -> SealedDocument | None:
        path = (
            self.root
            / "orchestration"
            / "commit-intents"
            / f"{work_order.data['work_id']}.json"
        )
        if not path.is_file():
            return None
        reference = {
            "path": (
                "orchestration/commit-intents/"
                f"{work_order.data['work_id']}.json"
            ),
            "sha256": sha256_file(path),
        }
        intent = self.load_document(reference)
        expected = {
            "schema_version": "2.0",
            "work_order": dict(work_order.reference),
            "action": work_order.data["action"],
            "required_actor": work_order.data["required_actor"],
            "predecessor_state": dict(work_order.data["state"]),
            "input_gate": work_order.data.get("input_gate"),
            "h1_workspace": work_order.data.get("h1_workspace"),
            "successor_kind": intent.data.get("successor_kind"),
            "successor": intent.data.get("successor"),
            "admission_evidence": intent.data.get("admission_evidence"),
            "status": "prepared",
        }
        if intent.data != expected:
            _fail("PROD_COMMIT_INTENT_INVALID", work_order.data["work_id"])
        return intent

    def require_current_work_order(
        self, work_order: SealedDocument, *, state: SealedDocument
    ) -> None:
        current = self.root / "orchestration" / "current-work-order.json"
        if not current.is_file():
            _fail("PROD_WORK_ORDER_MISSING", str(current))
        pointer = json.loads(current.read_text(encoding="utf-8"))
        if pointer.get("work_order") != work_order.reference:
            _fail("PROD_WORK_ORDER_NOT_CURRENT", work_order.data.get("work_id", ""))
        persisted = self.load_document(pointer["work_order"])
        if persisted.reference != work_order.reference or persisted.data != work_order.data:
            _fail("PROD_WORK_ORDER_FORGED", work_order.data.get("work_id", ""))
        if work_order.data.get("state") != state.reference:
            _fail("PROD_WORK_ORDER_STALE", work_order.data.get("work_id", ""))
        consumed = self.root / "orchestration" / "work-orders" / (
            f"{work_order.data['work_id']}.consumed.json"
        )
        if consumed.exists():
            _fail("PROD_WORK_ORDER_CONSUMED", work_order.data["work_id"])

    def mark_work_order_consumed(
        self, work_order: SealedDocument, *, successor: SealedDocument
    ) -> Path:
        intent = self._load_commit_intent(work_order)
        if intent is None or intent.data.get("successor") != successor.reference:
            _fail("PROD_COMMIT_INTENT_MISSING", work_order.data["work_id"])
        committed = self.load_document(successor.reference)
        if committed.data != successor.data:
            _fail("PROD_COMMIT_SUCCESSOR_INVALID", work_order.data["work_id"])
        if intent.data["successor_kind"] == "state":
            current = self.latest_state()
        else:
            current = self.latest_workspace()
        if current.reference != successor.reference or current.data != successor.data:
            _fail("PROD_COMMIT_SUCCESSOR_NOT_CURRENT", work_order.data["work_id"])
        body = {
            "schema_version": "2.0",
            "work_order": dict(work_order.reference),
            "successor": dict(successor.reference),
            "status": "consumed",
        }
        path = self.root / "orchestration" / "work-orders" / (
            f"{work_order.data['work_id']}.consumed.json"
        )
        self._write_new(path, canonical_json(body).encode("utf-8"))
        return path


__all__ = ["ProductionRunStore", "ProductionStoreError"]
