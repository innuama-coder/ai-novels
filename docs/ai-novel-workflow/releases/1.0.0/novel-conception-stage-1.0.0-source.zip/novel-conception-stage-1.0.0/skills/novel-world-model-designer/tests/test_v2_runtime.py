import copy
import importlib
import json
import os
import shutil
import tempfile
import unittest
from pathlib import Path
from unittest import mock


runtime = importlib.import_module(
    "harnesses.novel-conception-autonomous.runtime"
)
s1 = importlib.import_module(
    "skills.novel-storyline-architecture-designer.scripts.run_v2"
)
s1_test = importlib.import_module(
    "skills.novel-storyline-architecture-designer.tests.test_v2_runtime"
)
w1 = importlib.import_module(
    "skills.novel-world-model-designer.scripts.run_v2"
)
baseline_test = importlib.import_module(
    "harnesses.novel-conception-autonomous.tests.test_baseline"
)


def agent_world_proposal(
    *,
    run_id: str,
    gate_reference: dict[str, str],
    source_artifacts: list[dict[str, str]],
    baseline: dict[str, object],
    storyline: dict[str, object],
) -> dict[str, object]:
    """A test Agent's authored world model; production never synthesizes it."""

    requirements = copy.deepcopy(storyline["world_requirements"])
    lines = {item["id"]: item for item in storyline["storylines"]}
    decisions = []
    facts = []
    history = []
    institutions = []
    systems = []
    resource_flows = []
    authority_flows = []
    information_flows = []
    conflicts = []
    support = []
    environment_demands = []
    derivations = []
    owned_ids = []
    all_markers = " | ".join(item["responsibility"] for item in requirements)

    for index, requirement in enumerate(requirements, 1):
        line_id = next(item for item in requirement["source_ids"] if item in lines)
        line = lines[line_id]
        marker = requirement["responsibility"]
        decision_id = f"DEC-W1-{index:03d}"
        fact_id = f"WF-RULE-{index:03d}"
        history_id = f"HIS-{index:03d}"
        institution_id = f"INST-{index:03d}"
        system_id = f"WS-{index:03d}"
        resource_id = f"RF-{index:03d}"
        authority_id = f"AF-{index:03d}"
        information_id = f"IF-{index:03d}"
        conflict_id = f"WRC-{index:03d}"
        support_id = f"COV-W1-{index:03d}"
        environment_id = f"END-W1-{index:03d}"

        decisions.append(
            {
                "id": decision_id,
                "gap": f"Choose world pressure for {requirement['id']}: {marker}",
                "options": [
                    f"Use a costly regulated system for {marker}.",
                    f"Use an unrestricted system for {marker}.",
                ],
                "selection": f"Use a costly regulated system for {marker}.",
                "owner": "W1",
                "authority_basis": f"W1 owns world realization of {requirement['id']}.",
                "compatibility": f"Preserves the S1 responsibility: {marker}",
                "impact_ids": [fact_id, system_id],
                "cost": f"The rule makes {marker} possible but never free.",
                "reversibility": "costly",
                "downstream_freedom": "E1 may choose concrete places within the rule.",
                "projection_ids": [fact_id, system_id],
            }
        )
        fact = {
            "id": fact_id,
            "kind": "rule",
            "statement": f"The world permits and pressures this obligation: {marker}",
            "applies_to_ids": [line_id],
            "constraints": [
                f"Scope: applies wherever {marker} must be realized.",
                f"Exception: no actor may bypass the rule merely to achieve {marker}.",
                f"Cost: using the capability consumes scarce capacity for {marker}.",
                f"Constraint: authority must be verified before pursuing {marker}.",
            ],
            "consequences": [
                f"Success leaves an observable cost while supporting {marker}.",
                f"Failure blocks or worsens {marker}.",
            ],
            "source_ids": [requirement["id"], decision_id],
        }
        facts.append(fact)
        history.append(
            {
                "id": history_id,
                "origin": f"Earlier misuse created regulation around {marker}.",
                "current_pressure": f"Institutions now ration access needed for {marker}.",
                "storyline_ids": [line_id],
                "constraints": [f"Past damage cannot be erased to simplify {marker}."],
            }
        )
        institutions.append(
            {
                "id": institution_id,
                "responsibility": f"Govern the capability required by {marker}.",
                "authority": [f"Authorize bounded access for {marker}."],
                "resources": [f"Maintain scarce capacity used by {marker}."],
                "constraints": [f"Must record every authorization affecting {marker}."],
                "failure_modes": [f"Delay or capture can prevent {marker}."],
                "storyline_ids": [line_id],
            }
        )
        system = {
            "id": system_id,
            "input_conditions": [
                f"A verified request exists for {marker}.",
                f"The originating storyline is in state: {line['start_state']}",
            ],
            "actor_slot_ids": copy.deepcopy(line["actor_slot_ids"]),
            "resources": [f"Scarce capacity allocated to {marker}."],
            "authorities": [f"Recorded permission governing {marker}."],
            "transformation_rules": [
                f"Scope: transform only verified inputs related to {marker}.",
                f"Exception: refuse inputs that would bypass the conflict in {marker}.",
            ],
            "observable_outputs": [f"An auditable output advances or blocks {marker}."],
            "costs": [f"Capacity and trust are spent whenever {marker} proceeds."],
            "limits": [f"No operation may remove the core pressure in {marker}."],
            "failure_modes": [f"Denial, delay, or corrupted input can defeat {marker}."],
            "state_changes": [
                f"The world moves from latent capacity to accountable consequence for {marker}."
            ],
            "storyline_ids": [line_id],
        }
        systems.append(system)
        resource_flows.append(
            {
                "id": resource_id,
                "from_id": system_id,
                "to_id": institution_id,
                "relation": f"accounts for capacity used by {marker}",
                "mechanism": f"usage ledger for {marker}",
                "constraints": [f"No unrecorded resource transfer for {marker}."],
            }
        )
        authority_flows.append(
            {
                "id": authority_id,
                "from_id": institution_id,
                "to_id": system_id,
                "relation": f"grants bounded permission for {marker}",
                "mechanism": f"revocable authorization for {marker}",
                "constraints": [f"Permission cannot erase the cost of {marker}."],
            }
        )
        information_flows.append(
            {
                "id": information_id,
                "from_id": system_id,
                "to_id": institution_id,
                "relation": f"reports observable consequences of {marker}",
                "mechanism": f"auditable report for {marker}",
                "constraints": [f"Visibility remains bounded while preserving {marker}."],
            }
        )
        conflicts.append(
            {
                "id": conflict_id,
                "rule_ids": [fact_id, system_id],
                "tension": f"Capability and restriction pull against each other in {marker}.",
                "resolution_rule": f"Cost and authorization remain active whichever side wins {marker}.",
                "storyline_ids": [line_id],
            }
        )
        realization_ids = [fact_id, system_id, history_id, institution_id]
        support.append(
            {
                "id": support_id,
                "source_ids": [requirement["id"]],
                "realization_ids": realization_ids,
                "status": "covered",
                "evidence": f"{marker} is carried by a rule, system, history pressure, and institution.",
            }
        )
        environment_demands.append(
            {
                "id": environment_id,
                "target_stage": "E1",
                "responsibility": f"Provide concrete carrying conditions for {marker}.",
                "source_ids": [requirement["id"], *realization_ids],
                "required_capability": f"Expose access, cost, limits, and failure for {marker}.",
                "constraints": [
                    f"Do not bypass {fact_id} while carrying {marker}.",
                    f"Make {system_id} inputs and outputs observable for {marker}.",
                ],
                "acceptance_checks": [
                    f"A concrete environment can carry success and failure for {marker}.",
                    f"The environment cites the exact W1 support set for {marker}.",
                ],
                "downstream_freedom": "E1 chooses topology and functional zones.",
            }
        )
        derivations.extend(
            [
                {
                    "id": f"DRV-W1-RULE-{index:03d}",
                    "value_sha256": runtime.canonical_sha256(fact),
                    "source_ids": [requirement["id"]],
                    "decision_ids": [decision_id],
                    "projection_ids": [fact_id],
                },
                {
                    "id": f"DRV-W1-SYSTEM-{index:03d}",
                    "value_sha256": runtime.canonical_sha256(system),
                    "source_ids": [requirement["id"]],
                    "decision_ids": [decision_id],
                    "projection_ids": [system_id],
                },
            ]
        )
        owned_ids.extend(
            [
                decision_id,
                fact_id,
                history_id,
                institution_id,
                system_id,
                resource_id,
                authority_id,
                information_id,
                conflict_id,
                support_id,
            ]
        )

    reality_claims = []
    for index, dependency in enumerate(baseline["fact_dependencies"], 1):
        handling = {
            "adopted": "adopted",
            "open": "preserve_open",
            "not_applicable": "fiction_boundary",
        }[dependency["status"]]
        details = dependency["claim"]
        if dependency["status"] == "adopted":
            details += (
                f" Allowed use: {dependency['allowed_use']}."
                f" Fiction boundary: {dependency['fiction_boundary']}."
            )
        claim_id = f"WF-REALITY-{index:03d}"
        reality_claims.append(
            {
                "id": claim_id,
                "fact_dependency_id": dependency["id"],
                "handling": handling,
                "claim": details,
            }
        )
        owned_ids.append(claim_id)

    facets = {
        name: [f"{name} domain constrains the complete requirement set: {all_markers}"]
        for name in (
            "physical",
            "technology",
            "social",
            "political",
            "economic",
            "legal_and_ethical",
            "information",
            "historical",
        )
    }
    locked = [
        item["id"]
        for item in baseline["control_registry"]
        if item["hardness"] == "author_locked"
    ]
    author_open_controls = [
        item
        for item in baseline["control_registry"]
        if item["hardness"] == "author_open"
    ]
    model = {
        "schema_version": "2.0",
        "skill": "novel-world-model-designer",
        "stage": "W1",
        "run_id": run_id,
        "status": "ready",
        "input_gate": copy.deepcopy(gate_reference),
        "source_artifacts": copy.deepcopy(source_artifacts),
        "authority_partition": {
            "author_locked": locked,
            "autonomous_owned": owned_ids,
            "downstream_freedom": [item["id"] for item in environment_demands],
            "author_open": [item["id"] for item in author_open_controls],
        },
        "design_decisions": decisions,
        "derivation_claims": derivations,
        "storyline_requirements": requirements,
        "world_definition": {
            "premise": f"One regulated world carries all approved obligations: {all_markers}",
            "scope": f"The designed world covers only story-relevant operations: {all_markers}",
            "period": f"A period shaped by accumulated institutional pressure: {all_markers}",
            "reality_relation": f"Reality claims are bounded by B0 while fiction carries: {all_markers}",
            "operating_logic": f"Capability always meets authority, scarcity, and failure: {all_markers}",
            "boundaries": [
                f"No convenient world mechanism may bypass: {all_markers}",
                "Concrete environments, events, and character profiles remain downstream.",
            ],
            "story_relevance": f"Every rule exists to carry an S1 obligation: {all_markers}",
        },
        "world_facts": facts,
        "reality_claims": reality_claims,
        "world_facets": facets,
        "history_pressures": history,
        "institutions": institutions,
        "systems": systems,
        "resource_flows": resource_flows,
        "authority_flows": authority_flows,
        "information_flows": information_flows,
        "rule_conflict_matrix": conflicts,
        "storyline_support_ledger": support,
        "environment_demands": environment_demands,
        "open_items": [
            {
                "id": f"OPEN-W1-{index:03d}",
                "question": f"Preserve author-open control {item['id']}.",
                "source_ids": [item["id"]],
                "status": "author_open",
            }
            for index, item in enumerate(author_open_controls, 1)
        ],
    }
    return model


class W1RuntimeTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.shared_temporary = tempfile.TemporaryDirectory()
        cls.shared = Path(cls.shared_temporary.name)
        cls.sources = baseline_test.SourceFixture(cls.shared / "sources")
        coordinator = runtime.AutonomousCoordinator.initialize(
            run_id=cls.sources.run_id,
            source_interview_state={
                "path": "interview/interview-state.json",
                "sha256": runtime.sha256_file(cls.sources.state),
            },
            state_path="state/revision-000.json",
        )
        b0_gate = coordinator.build_input_gate("B0", "B0/input-gate.json")
        cls.shared_b0 = cls.shared / "run" / "B0"
        runtime.build_baseline_package(
            **cls.sources.build_args(cls.shared_b0, b0_gate)
        )
        runtime.complete_b0(
            cls.shared_b0,
            coordinator=coordinator,
            input_gate=b0_gate,
            logical_package_path="B0",
            next_state_path="state/revision-001.json",
        )
        s1_gate = coordinator.build_input_gate("S1", "S1/input-gate.json")
        cls.shared_s1 = cls.shared / "run" / "S1"
        s1_workspace = cls.shared / "workspace" / "S1"
        baseline = json.loads(
            (cls.shared_b0 / "author-control-baseline.json").read_text(
                encoding="utf-8"
            )
        )
        controls = s1._controls(cls.shared_b0, baseline)
        source_artifacts = [
            {
                "path": f"sources/B0/{name}",
                "sha256": runtime.sha256_file(cls.shared_b0 / name),
            }
            for name in (
                "author-control-baseline.json",
                "package-manifest.json",
                "stage-completion.json",
            )
        ]
        s1_proposal = s1_test.agent_proposal(
            run_id=cls.sources.run_id,
            gate_reference=s1_gate.reference,
            source_artifacts=source_artifacts,
            controls=controls,
        )
        with mock.patch.dict(
            os.environ, {"CODEX_THREAD_ID": "thread-shared-s1"}, clear=False
        ):
            s1.start_s1_session(
                s1_workspace,
                baseline_package=cls.shared_b0,
                input_gate=s1_gate,
            )
            for phase in s1.PHASES:
                payload = (
                    {"model": s1_proposal}
                    if phase == "final-storyline-model"
                    else {
                        field: s1_proposal[field]
                        for field in s1.PHASE_FIELDS[phase]
                    }
                )
                s1.submit_s1_phase(
                    s1_workspace,
                    baseline_package=cls.shared_b0,
                    input_gate=s1_gate,
                    phase=phase,
                    payload=payload,
                )
            s1.run_s1(
                cls.shared_s1,
                baseline_package=cls.shared_b0,
                coordinator=coordinator,
                input_gate=s1_gate,
                controlled_workspace=s1_workspace,
                logical_package_path="S1",
                next_state_path="state/revision-002.json",
            )
        cls.coordinator_state = coordinator.state
        cls.coordinator_reference = coordinator.state_reference

    @classmethod
    def tearDownClass(cls) -> None:
        cls.shared_temporary.cleanup()

    def setUp(self) -> None:
        self.temporary = tempfile.TemporaryDirectory()
        self.work = Path(self.temporary.name)
        self.b0 = self.work / "run" / "B0"
        self.s1 = self.work / "run" / "S1"
        shutil.copytree(self.shared_b0, self.b0)
        shutil.copytree(self.shared_s1, self.s1)
        self.coordinator = runtime.AutonomousCoordinator.from_snapshot(
            self.coordinator_state,
            self.coordinator_reference,
        )
        self.gate = self.coordinator.build_input_gate(
            "W1", "W1/input-gate.json"
        )
        self.package = self.work / "run" / "W1"
        self.workspace = self.work / "workspace" / "W1"
        self.baseline = json.loads(
            (self.b0 / "author-control-baseline.json").read_text(encoding="utf-8")
        )
        self.storyline = json.loads(
            (self.s1 / "storyline-architecture.json").read_text(encoding="utf-8")
        )
        source_artifacts = [
            *[
                {
                    "path": f"sources/B0/{name}",
                    "sha256": runtime.sha256_file(self.b0 / name),
                }
                for name in (
                    "author-control-baseline.json",
                    "package-manifest.json",
                    "stage-completion.json",
                )
            ],
            *[
                {
                    "path": f"sources/S1/{name}",
                    "sha256": runtime.sha256_file(self.s1 / name),
                }
                for name in (
                    "storyline-architecture.json",
                    "package-manifest.json",
                    "stage-completion.json",
                )
            ],
        ]
        self.proposal = agent_world_proposal(
            run_id=self.sources.run_id,
            gate_reference=self.gate.reference,
            source_artifacts=source_artifacts,
            baseline=self.baseline,
            storyline=self.storyline,
        )
        with mock.patch.dict(
            os.environ, {"CODEX_THREAD_ID": "thread-generic-w1"}, clear=False
        ):
            w1.start_w1_session(
                self.workspace,
                baseline_package=self.b0,
                storyline_package=self.s1,
                input_gate=self.gate,
            )
            for phase in w1.PHASES:
                payload = (
                    {"model": self.proposal}
                    if phase == "final-world-model"
                    else {
                        field: self.proposal[field]
                        for field in w1.PHASE_FIELDS[phase]
                    }
                )
                w1.submit_w1_phase(
                    self.workspace,
                    baseline_package=self.b0,
                    storyline_package=self.s1,
                    input_gate=self.gate,
                    phase=phase,
                    payload=payload,
                )

    def tearDown(self) -> None:
        self.temporary.cleanup()

    def run_w1(self) -> w1.W1RunReceipt:
        with mock.patch.dict(
            os.environ, {"CODEX_THREAD_ID": "thread-generic-w1"}, clear=False
        ):
            return w1.run_w1(
                self.package,
                baseline_package=self.b0,
                storyline_package=self.s1,
                coordinator=self.coordinator,
                input_gate=self.gate,
                controlled_workspace=self.workspace,
                logical_package_path="W1",
                next_state_path="state/revision-003.json",
            )

    def _validate(self, model: dict[str, object]) -> None:
        w1._validate_model(
            model,
            self.baseline,
            self.storyline,
            w1._controls(self.b0, self.baseline),
            runtime.ContractRuntime(),
            expected_gate=self.gate.reference,
            expected_sources=self.proposal["source_artifacts"],
        )

    def test_authority_partition_rejects_overlap_before_deep_validation(self) -> None:
        model = copy.deepcopy(self.proposal)
        model["authority_partition"]["downstream_freedom"].append(
            model["authority_partition"]["autonomous_owned"][0]
        )
        with self.assertRaisesRegex(
            w1.W1Error, "W1_AUTHORITY_PARTITION_OVERLAP"
        ):
            self._validate(model)

    def test_authority_partition_requires_all_four_exact_sets(self) -> None:
        model = copy.deepcopy(self.proposal)
        model["authority_partition"]["autonomous_owned"].pop()
        with self.assertRaisesRegex(
            w1.W1Error, "W1_AUTHORITY_PARTITION_MISMATCH"
        ):
            self._validate(model)

    def test_ready_world_model_covers_every_storyline_and_advances(self) -> None:
        receipt = self.run_w1()
        model = receipt.model
        requirement_ids = {item["id"] for item in model["storyline_requirements"]}
        self.assertEqual(
            requirement_ids,
            {
                item["source_ids"][0]
                for item in model["storyline_support_ledger"]
            },
        )
        self.assertEqual(
            requirement_ids,
            {
                next(
                    source
                    for source in item["source_ids"]
                    if source in requirement_ids
                )
                for item in model["environment_demands"]
            },
        )
        self.assertTrue(
            all(
                all(
                    any(tag in value for value in item["constraints"])
                    for tag in w1._RULE_TAGS
                )
                for item in model["world_facts"]
                if item["kind"] == "rule"
            )
        )
        self.assertEqual("W1", receipt.completion.data["stage"])
        self.assertEqual(3, receipt.transition.snapshot["revision"])
        self.assertEqual(
            "ready", w1.validate_w1_package(self.package)["verdict"]
        )

    def test_opposite_s1_values_change_every_agent_phase_payload(self) -> None:
        left_storyline = copy.deepcopy(self.storyline)
        right_storyline = copy.deepcopy(self.storyline)
        left_storyline["world_requirements"][0]["responsibility"] = (
            "The world must keep the protected subject present."
        )
        right_storyline["world_requirements"][0]["responsibility"] = (
            "The world must force the protected subject to leave."
        )
        sources = copy.deepcopy(self.proposal["source_artifacts"])
        left = agent_world_proposal(
            run_id=self.sources.run_id,
            gate_reference=self.gate.reference,
            source_artifacts=sources,
            baseline=self.baseline,
            storyline=left_storyline,
        )
        right = agent_world_proposal(
            run_id=self.sources.run_id,
            gate_reference=self.gate.reference,
            source_artifacts=sources,
            baseline=self.baseline,
            storyline=right_storyline,
        )
        for phase in w1.PHASES:
            left_payload = (
                {"model": left}
                if phase == "final-world-model"
                else {field: left[field] for field in w1.PHASE_FIELDS[phase]}
            )
            right_payload = (
                {"model": right}
                if phase == "final-world-model"
                else {field: right[field] for field in w1.PHASE_FIELDS[phase]}
            )
            self.assertNotEqual(
                runtime.canonical_sha256(left_payload),
                runtime.canonical_sha256(right_payload),
                phase,
            )

    def test_resealed_rule_coverage_deletion_is_rejected(self) -> None:
        self.run_w1()
        model = self._read_model()
        model["storyline_support_ledger"][0]["realization_ids"] = [
            item
            for item in model["storyline_support_ledger"][0]["realization_ids"]
            if not item.startswith("WF-RULE-")
        ]
        self._reseal_model(model)
        with self.assertRaises(w1.W1Error) as caught:
            w1.validate_w1_package(self.package)
        self.assertEqual("W1_SUPPORT_COVERAGE_MISMATCH", caught.exception.code)

    def test_resealed_forged_gate_is_rejected(self) -> None:
        self.run_w1()
        model = self._read_model()
        model["input_gate"]["sha256"] = "0" * 64
        self._reseal_model(model, input_gate=model["input_gate"])
        with self.assertRaises(w1.W1Error) as caught:
            w1.validate_w1_package(self.package)
        self.assertEqual("W1_GATE_REFERENCE_MISMATCH", caught.exception.code)

    def test_missing_completion_is_not_ready(self) -> None:
        self.run_w1()
        (self.package / "stage-completion.json").unlink()
        with self.assertRaises(w1.W1Error) as caught:
            w1.validate_w1_package(self.package)
        self.assertEqual("W1_COMPLETION_MISSING", caught.exception.code)

    def test_downstream_artifact_is_a_boundary_violation(self) -> None:
        self.run_w1()
        forbidden = self.package / "environment-system.json"
        forbidden.write_text("{}", encoding="utf-8")
        with self.assertRaises(w1.W1Error) as caught:
            w1.validate_w1_package(self.package)
        self.assertEqual("W1_BOUNDARY_VIOLATION", caught.exception.code)

    def test_semantic_shells_are_rejected_after_reseal(self) -> None:
        self.run_w1()
        cases = []

        empty_actor = self._read_model()
        empty_actor["systems"][0]["actor_slot_ids"] = []
        cases.append(("empty-actor", empty_actor, "W1_ACTOR_SLOT_DANGLING"))

        dangling_fact = self._read_model()
        dangling_fact["world_facts"].append(
            {
                "id": "WF-UNSOURCED",
                "kind": "condition",
                "statement": "An unsupported condition.",
                "applies_to_ids": ["SL-UNKNOWN"],
                "constraints": ["Unsupported."],
                "consequences": ["Unsupported."],
                "source_ids": ["WR-UNKNOWN"],
            }
        )
        dangling_fact["authority_partition"]["autonomous_owned"].append(
            "WF-UNSOURCED"
        )
        cases.append(("dangling-fact", dangling_fact, "W1_SOURCE_ID_DANGLING"))

        placeholder_facets = self._read_model()
        placeholder_facets["world_facets"] = {
            name: ["placeholder"]
            for name in placeholder_facets["world_facets"]
        }
        cases.append(
            ("placeholder-facets", placeholder_facets, "W1_FACET_UNBOUND")
        )

        for name, model, expected_code in cases:
            with self.subTest(name=name):
                mutant = self.work / "mutants" / name
                shutil.copytree(self.package, mutant)
                self._reseal_model(model, package=mutant)
                with self.assertRaises(w1.W1Error) as caught:
                    w1.validate_w1_package(mutant)
                self.assertEqual(expected_code, caught.exception.code)

    def test_missing_controlled_thread_is_blocked(self) -> None:
        with mock.patch.dict(os.environ, {}, clear=True):
            with self.assertRaises(w1.W1Error) as caught:
                w1.run_w1(
                    self.package,
                    baseline_package=self.b0,
                    storyline_package=self.s1,
                    coordinator=self.coordinator,
                    input_gate=self.gate,
                    controlled_workspace=self.workspace,
                    logical_package_path="W1",
                    next_state_path="state/revision-003.json",
                )
        self.assertEqual("W1_THREAD_REQUIRED", caught.exception.code)
        self.assertFalse(self.package.exists())

    def _read_model(self) -> dict[str, object]:
        return json.loads(
            (self.package / "world-model.json").read_text(encoding="utf-8")
        )

    def _reseal_model(
        self,
        model: dict[str, object],
        *,
        input_gate: dict[str, str] | None = None,
        package: Path | None = None,
    ) -> None:
        root = package or self.package
        model_path = root / "world-model.json"
        model_path.write_text(runtime.canonical_json(model), encoding="utf-8")
        execution_path = root / "execution-record.json"
        execution = json.loads(execution_path.read_text(encoding="utf-8"))
        execution["output_sha256"] = runtime.canonical_sha256(model)
        if input_gate is not None:
            execution["input_gate"] = copy.deepcopy(input_gate)
        execution_path.write_text(
            runtime.canonical_json(execution), encoding="utf-8"
        )
        manifest_path = root / "package-manifest.json"
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
        replacements = {
            "world-model.json": runtime.artifact_reference(
                model_path, root=root
            ),
            "execution-record.json": runtime.artifact_reference(
                execution_path, root=root
            ),
        }
        manifest["files"] = [
            replacements.get(item["path"], item) for item in manifest["files"]
        ]
        manifest["artifact_roles"]["canonical"] = replacements["world-model.json"]
        manifest["artifact_roles"]["execution_record"] = replacements[
            "execution-record.json"
        ]
        manifest_path.write_text(
            runtime.canonical_json(manifest), encoding="utf-8"
        )
        completion_path = root / "stage-completion.json"
        completion = json.loads(completion_path.read_text(encoding="utf-8"))
        completion["manifest"]["sha256"] = runtime.sha256_file(manifest_path)
        if input_gate is not None:
            completion["input_gate"] = copy.deepcopy(input_gate)
        completion_path.write_text(
            runtime.canonical_json(completion), encoding="utf-8"
        )


if __name__ == "__main__":
    unittest.main()
