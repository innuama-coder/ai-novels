---
name: novel-world-model-designer
description: 根据完整故事线架构构建可承载故事并主动制造机会、限制、成本、失败和后果的虚拟世界模型。用于自主构思 V2 的 W1 阶段；不定义具体主要环境、全局事件时间线或人物档案。
---

# 小说虚拟世界设计

## 目标

建立环境、事件和人物可以共同运行的自洽世界，使全部故事线受同一组规则、系统、
资源、权限和信息机制约束。

## 权威契约

完整读取工作流第 3、5、14、15 节，以及：

- [W1 Schema](../../docs/ai-novel-workflow/contracts/autonomous-v2/world-model.schema.json)；
- [W1 唯一运行契约](references/runtime-contract.md)。

## 唯一生产运行路径

只允许使用 `scripts/run_v2.py`。在同一 `CODEX_THREAD_ID` 中依次调用
`start_w1_session()`、按契约顺序调用 `submit_w1_phase()`、最后调用
`run_w1()`。不得跳过受控会话、倒填阶段证据、传入会话外的一次性完整候选稿，
也不得手写 validation、manifest 或 completion。`validate_w1_package()` 只用于
只读复验，不能替代上述生产调用。

## 输入硬准入

只接受当前 B0、S1 completion、manifest、canonical 模型、W1 input gate 和执行前
run-state。W1 消费的 `storyline_requirements` ID 集必须与 S1
`world_requirements` 精确相等。不得从聊天、旧地图或常识补充作者事实。

## 职责

1. 定义世界范围、时代、现实关系、运行逻辑和虚构边界。
2. 定义物理、技术、社会、政治、经济、法律／伦理、信息和历史八域。
3. 定义世界事实、历史压力、真实参与故事运行的组织／机构，以及系统、资源、权限和信息流。
   组织不得退化为抽象流程名：必须说明它在世界中的位置、职责、利益、权限、资源、
   与其他组织的依赖或冲突，以及它介入哪些故事活动。
4. 为每个关键冲突提供规则、成本、限制和真实失败路径。
5. 证明所有故事线能在同一世界并存。
6. 生成 E1 所需的完整环境需求。

## 边界

- 不创建具体功能区和事件落点；但必须向 E1 明确提出宏观地理层级、机构设施、
  空间关系和情节承载方面的需求，不能只交付抽象规则。
- 不创建事件时间线或人物档案。
- 不新增与故事线无关的百科设定。
- 遇到未登记的结构性现实主张，必须 return I2 并从 B0 恢复。

## 交付与验收

交付 `world-model.json`、证据、validation、manifest 和 W1 completion。ready 必须证明：
S1 需求完整消费；所有系统输入、输出、权限、成本和失败闭合；外部事实逐条绑定 B0
fact dependency；环境需求具有来源、约束和验收条件。
