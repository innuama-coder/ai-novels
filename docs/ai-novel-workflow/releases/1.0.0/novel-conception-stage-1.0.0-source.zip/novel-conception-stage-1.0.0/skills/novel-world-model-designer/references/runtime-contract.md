# W1 V2 runtime contract

`scripts/run_v2.py` is the sole production runtime for W1. Python controls
lineage, stage order, validation, sealing, and publication. The Agent authors
all world semantics; the runtime never templates rules, institutions, history,
systems, flows, or downstream demands.

## Controlled generation protocol

1. Call `start_w1_session()` with the current B0 package, current ready S1
   package, and coordinator-issued W1 gate. `CODEX_THREAD_ID` is mandatory.
2. The session freezes the exact B0 and S1 completions, gate, pre-stage state,
   source artifact hashes, B0 controls and fact dependencies, S1 storylines, and
   complete S1 world-requirement objects.
3. Let the Agent submit exactly five phases in order:
   `requirement-projection`, `world-rules-and-history`, `systems-and-flows`,
   `cross-line-world-test`, and `final-world-model`.
4. Every evidence record binds the frozen inputs, thread, payload hash, and
   previous evidence hash. Earlier phase payloads must equal their final-model
   projections.
5. Call `run_w1()` to validate and package the fifth submission. It writes the
   completion and asks the coordinator to accept it before publishing W1.

One-shot candidate models and evidence backfilling are not production inputs.
Changing B0 or S1 requires a new session and new Agent-authored phase payloads.

## Ready guarantees

- `storyline_requirements` is byte-semantic equality with S1
  `world_requirements`, and every storyline is covered;
- each requirement is carried by at least one rule and one operating system;
- every world fact, regardless of kind, binds valid S1 storylines and valid
  S1/B0/W1 source IDs;
- every one of the eight world facets carries at least one approved S1
  requirement, so a nonempty placeholder is not evidence;
- every rule states scope, exception, cost, and constraint;
- every system has at least one valid S1 actor slot and closes inputs,
  resources, authorities,
  transformation rules, observable outputs, costs, limits, failures, state
  changes, and resource/authority/information flows;
- history, institutions, systems, and conflict tests cover every storyline;
- support ledger and E1 environment demands cover each S1 requirement exactly
  once, with exact source sets;
- fact-dependency handling is exactly closed against B0; author-open controls
  remain open;
- the four local authority classes are pairwise-disjoint; locked/open equal
  B0, autonomous-owned equals W1 decisions and governed world entities, and
  downstream-freedom equals the W1 environment-demand IDs exactly;
- gate, B0, S1, session, evidence, implementation, manifest, validation,
  completion, and coordinator transition share one immutable lineage.

`validate_w1_package()` is read-only and recomputes these guarantees. Resealing
hash declarations cannot replace semantic coverage, source-value
participation, boundary, or completion checks. A package without a valid
`stage-completion.json` is not ready.

## Boundary

W1 defines world scope, rules, history pressure, institutions, systems,
resources, authority, information mechanisms, and requirements for E1. It does
not enumerate concrete environments or functional zones, build an event
timeline, create events, or create character profiles. Such artifacts are a
hard `W1_BOUNDARY_VIOLATION`.
