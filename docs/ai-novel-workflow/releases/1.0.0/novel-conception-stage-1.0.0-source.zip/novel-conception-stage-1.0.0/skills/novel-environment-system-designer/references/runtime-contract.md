# E1 V2 runtime contract

`scripts/run_v2.py` is the sole E1 production runtime. Python controls lineage,
submission order, validation, sealing, and publication. The Agent authors every
environment, zone, interface, risk, topology, and transition contract; Python
does not template environment semantics.

## Controlled generation protocol

1. `start_e1_session()` accepts the current ready B0, S1, and W1 packages plus
   the coordinator-issued E1 gate. It requires `CODEX_THREAD_ID`.
2. The session freezes the exact three completions, gate, pre-stage state,
   source hashes, B0 controls, S1 storylines, complete S1 environment and event
   requirements, W1 rules, and complete W1 environment-demand objects.
3. The Agent submits exactly five phases in order:
   `environment-demand-scan`, `environment-architecture`,
   `zones-and-topology`, `storyline-hosting-test`, and
   `final-environment-model`.
4. Every evidence record binds all frozen inputs, thread, payload hash, and
   previous evidence hash. Earlier payloads must equal final-model projections.
5. `run_e1()` validates, packages, seals the completion, asks the coordinator
   to accept it, and only then publishes E1.

A one-shot model or backfilled evidence is not accepted. Any B0, S1, or W1
change requires a new session and new Agent-authored payloads.

## Ready guarantees

- `storyline_environment_requirements` exactly equals S1 output and
  `environment_demands` exactly equals W1 output;
- every hosting record jointly binds exactly one S1 environment requirement
  and one W1 environment demand for the same storyline; both universes are
  covered exactly once, and each realization preserves both responsibilities
  and the union of their constraints;
- every S1 storyline has a hosting path and every S1 event requirement has
  exactly one usable affordance;
- environments have distinct narrative duties, observable sensory conditions,
  access, resources, actions, blockers, hazards, state vocabulary, and
  transitions;
- zones, topology, permissions, resource/information channels, hazards,
  affordances, and transitions have closed references;
- the environment graph is reachable; each environment binds its incident
  connections and at least one zone, authority interface, channel, hazard, and
  transition;
- access evidence, affordance constraints, and transition permissions preserve
  the exact W1 support rules instead of providing a bypass;
- each affordance's S1 event requirement resolves to the same storyline as the
  environment's hosted W1 demand, and a transition may only use affordances
  belonging to its own environment;
- each resource/information channel uses exact `[DEMAND:id]`,
  `[SUPPORT:id]`, `[MARKER_SHA256:hash]`, and `[ACTION_SHA256:hash]` tokens to
  bind its hosted demand, complete W1 rule/system/institution support set,
  demand meaning, and an exposed environment action; substring matches and
  nonempty placeholder prose are not evidence;
- the local authority partition is pairwise-disjoint: locked/open equal B0,
  autonomous-owned equals all E1 decisions and governed entities (including
  affordances and transition contracts), and downstream-freedom equals the S1
  event-requirement IDs exactly;
- gate, B0, S1, W1, session, evidence, implementation, manifest, validation,
  completion, and coordinator transition share one immutable lineage.

`validate_e1_package()` is read-only and recomputes these guarantees. Resealing
hash declarations cannot replace semantic coverage, reachability, action
interfaces, world-rule consistency, boundary checks, or completion lineage.

## Boundary

E1 defines concrete reusable environments and the conditions under which later
events could act or transition state. It does not add storylines, decide event
time, initiator, occurrence, or result, create event objects, write scenes,
dialogue, camera direction, or character profiles. Those outputs are a hard
`E1_BOUNDARY_VIOLATION`. Package validation uses an allowlist, not filename
guessing: only the formal E1 root artifacts, the five exact phase-evidence
files, the exact `_implementation_paths()` target set, and formal
`sources/B0|S1|W1/**` inputs may exist. Implementation files must also equal the
execution catalog, execution implementation list, and manifest implementation
list. Any other path is rejected regardless of its name; the formal
`environment-preview.md` remains allowed.
