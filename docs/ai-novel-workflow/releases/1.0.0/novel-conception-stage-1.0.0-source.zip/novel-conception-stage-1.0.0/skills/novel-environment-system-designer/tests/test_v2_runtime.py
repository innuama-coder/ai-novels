import copy
import importlib
import json
import os
import shutil
import tempfile
import unittest
from pathlib import Path
from unittest import mock


runtime = importlib.import_module(
    "harnesses.novel-conception-autonomous.runtime"
)
s1 = importlib.import_module(
    "skills.novel-storyline-architecture-designer.scripts.run_v2"
)
s1_test = importlib.import_module(
    "skills.novel-storyline-architecture-designer.tests.test_v2_runtime"
)
w1 = importlib.import_module(
    "skills.novel-world-model-designer.scripts.run_v2"
)
w1_test = importlib.import_module(
    "skills.novel-world-model-designer.tests.test_v2_runtime"
)
e1 = importlib.import_module(
    "skills.novel-environment-system-designer.scripts.run_v2"
)
baseline_test = importlib.import_module(
    "harnesses.novel-conception-autonomous.tests.test_baseline"
)


def agent_environment_proposal(
    *,
    run_id: str,
    gate_reference: dict[str, str],
    source_artifacts: list[dict[str, str]],
    baseline: dict[str, object],
    storyline: dict[str, object],
    world: dict[str, object],
) -> dict[str, object]:
    """A test Agent's authored E1 model; production never synthesizes it."""

    demands = copy.deepcopy(world["environment_demands"])
    storyline_environment_requirements = copy.deepcopy(
        storyline["environment_requirements"]
    )
    lines = {item["id"]: item for item in storyline["storylines"]}
    world_requirements = {
        item["id"]: item for item in world["storyline_requirements"]
    }
    world_entities = {
        item["id"]: item
        for field in (
            "world_facts",
            "history_pressures",
            "institutions",
            "systems",
            "resource_flows",
            "authority_flows",
            "information_flows",
            "rule_conflict_matrix",
            "storyline_support_ledger",
        )
        for item in world[field]
    }
    event_by_line = {}
    for requirement in storyline["event_requirements"]:
        line_id = next(item for item in requirement["source_ids"] if item in lines)
        event_by_line[line_id] = requirement
    environment_requirement_by_line = {}
    for requirement in storyline_environment_requirements:
        line_id = next(item for item in requirement["source_ids"] if item in lines)
        environment_requirement_by_line[line_id] = requirement

    decisions = []
    environments = []
    zones = []
    assignments = []
    channels = []
    hazards = []
    hosting = []
    affordances = []
    transitions = []
    derivations = []
    owned_ids = []
    environment_meta = []

    for index, demand in enumerate(demands, 1):
        world_requirement_id = next(
            item for item in demand["source_ids"] if item in world_requirements
        )
        world_requirement = world_requirements[world_requirement_id]
        line_id = next(
            item for item in world_requirement["source_ids"] if item in lines
        )
        event_requirement = event_by_line[line_id]
        storyline_environment_requirement = environment_requirement_by_line[line_id]
        support_ids = [
            item for item in demand["source_ids"] if item in world_entities
        ]
        marker = demand["responsibility"]
        storyline_marker = storyline_environment_requirement["responsibility"]
        environment_id = f"ENV-{index:03d}"
        zone_id = f"ZONE-{index:03d}"
        decision_id = f"DEC-E1-{index:03d}"
        assignment_id = f"ACCESS-{index:03d}"
        channel_id = f"CHANNEL-{index:03d}"
        hazard_id = f"HAZ-{index:03d}"
        hosting_id = f"COV-E1-{index:03d}"
        affordance_id = f"AFF-{index:03d}"
        transition_id = f"TRANS-{index:03d}"
        action = f"Perform a bounded action required by {marker}."
        from_state = f"available for {marker}"
        to_state = f"restricted after an attempted action for {marker}"

        decisions.append(
            {
                "id": decision_id,
                "gap": f"Choose a reusable environment duty for {marker}.",
                "options": [
                    f"Create a controlled host for {marker}.",
                    f"Use an incidental one-use location for {marker}.",
                ],
                "selection": f"Create a controlled host for {marker}.",
                "owner": "E1",
                "authority_basis": f"E1 owns concrete carrying conditions for {demand['id']}.",
                "compatibility": f"Expands W1 without changing its rule: {marker}",
                "impact_ids": [environment_id, zone_id],
                "cost": f"The environment preserves access costs for {marker}.",
                "reversibility": "costly",
                "downstream_freedom": "T1 may select an event that uses the interface.",
                "projection_ids": [environment_id, zone_id],
            }
        )
        environment = {
            "id": environment_id,
            "scope": f"A bounded operational environment for {marker}.",
            "narrative_responsibility": (
                f"Uniquely host {demand['id']}: {marker}; and "
                f"{storyline_environment_requirement['id']}: {storyline_marker}"
            ),
            "features": [
                f"Control surfaces expose the capability needed by {marker}.",
                f"Boundaries make the limits of {marker} observable.",
            ],
            "sensory_conditions": [
                f"Actors can perceive access status and resource pressure for {marker}."
            ],
            "access_rules": [
                *copy.deepcopy(demand["constraints"]),
                *copy.deepcopy(storyline_environment_requirement["constraints"]),
                f"Access must cite W1 support {', '.join(support_ids)} for {marker}.",
            ],
            "resources": [
                f"Resources explicitly support {demand['required_capability']}"
            ],
            "allowed_actions": [action],
            "hazards": [f"{hazard_id} can block or worsen {marker}."],
            "zone_ids": [zone_id],
            "connections": [],
            "blockers": [f"Failed permission or exhausted resources block {marker}."],
            "state_vocabulary": [from_state, to_state],
            "allowed_transitions": [transition_id],
            "storyline_stage_ids": [
                line_id,
                demand["id"],
                storyline_environment_requirement["id"],
            ],
        }
        environments.append(environment)
        zones.append(
            {
                "id": zone_id,
                "environment_id": environment_id,
                "responsibility": (
                    f"Expose the action interface for {marker} and "
                    f"{storyline_marker}."
                ),
                "features": [
                    f"Observable controls support {marker} and {storyline_marker}."
                ],
                "access_rules": [
                    *copy.deepcopy(demand["constraints"]),
                    *copy.deepcopy(
                        storyline_environment_requirement["constraints"]
                    ),
                ],
                "resources": [f"Bounded resource access for {marker}."],
                "constraints": [f"The zone cannot decide an event result for {marker}."],
            }
        )
        assignments.append(
            {
                "id": assignment_id,
                "subject_id": environment_id,
                "responsibility": (
                    f"Authorize bounded access for {marker} and "
                    f"{storyline_marker}."
                ),
                "evidence_ids": support_ids,
                "constraints": [
                    *copy.deepcopy(demand["constraints"]),
                    *copy.deepcopy(
                        storyline_environment_requirement["constraints"]
                    ),
                ],
            }
        )
        channels.append(
            {
                "id": channel_id,
                "from_id": environment_id,
                "to_id": zone_id,
                "relation": (
                    f"[DEMAND:{demand['id']}] supplies resource and "
                    f"observable information for {marker} and {storyline_marker}"
                ),
                "mechanism": (
                    f"[MARKER_SHA256:{runtime.canonical_sha256(marker)}] "
                    f"[ACTION_SHA256:{runtime.canonical_sha256(action)}] "
                    f"bounded operational channel for {marker} and "
                    f"{storyline_marker}"
                ),
                "constraints": [
                    *copy.deepcopy(demand["constraints"]),
                    *copy.deepcopy(
                        storyline_environment_requirement["constraints"]
                    ),
                    *[
                        f"[SUPPORT:{support_id}] remains mandatory for {marker}."
                        for support_id in support_ids
                    ],
                ],
            }
        )
        hazards.append(
            {
                "id": hazard_id,
                "environment_id": environment_id,
                "trigger": (
                    "Permission, resource, or information failure during "
                    f"{marker} or {storyline_marker}."
                ),
                "effect": (
                    "The attempted action is blocked or becomes costlier for "
                    f"{marker} and {storyline_marker}."
                ),
                "mitigation_limits": [
                    f"Mitigation cannot remove W1 constraints for {marker}."
                ],
            }
        )
        hosting.append(
            {
                "id": hosting_id,
                "source_ids": [
                    demand["id"],
                    storyline_environment_requirement["id"],
                ],
                "realization_ids": [environment_id],
                "status": "covered",
                "evidence": (
                    f"{environment_id} concretely hosts {marker}; and "
                    f"{storyline_marker}."
                ),
            }
        )
        affordance = {
            "id": affordance_id,
            "environment_id": environment_id,
            "event_requirement_ids": [event_requirement["id"]],
            "allowed_actions": [action],
            "prerequisites": [
                f"{assignment_id} grants access and required resources exist for {marker}."
            ],
            "constraints": [
                *copy.deepcopy(demand["constraints"]),
                *copy.deepcopy(storyline_environment_requirement["constraints"]),
            ],
        }
        affordances.append(affordance)
        transition = {
            "id": transition_id,
            "subject_id": environment_id,
            "from_state": from_state,
            "trigger_ids": [affordance_id],
            "to_state": to_state,
            "allowed_by_ids": [assignment_id, *support_ids],
            "consequence": (
                "The environment changes availability without deciding an "
                f"event result for {marker} or {storyline_marker}."
            ),
        }
        transitions.append(transition)
        derivations.extend(
            [
                {
                    "id": f"DRV-E1-ENV-{index:03d}",
                    "value_sha256": runtime.canonical_sha256(environment),
                    "source_ids": [
                        demand["id"],
                        storyline_environment_requirement["id"],
                        *support_ids,
                    ],
                    "decision_ids": [decision_id],
                    "projection_ids": [environment_id],
                },
                {
                    "id": f"DRV-E1-AFF-{index:03d}",
                    "value_sha256": runtime.canonical_sha256(affordance),
                    "source_ids": [
                        demand["id"],
                        storyline_environment_requirement["id"],
                        event_requirement["id"],
                    ],
                    "decision_ids": [decision_id],
                    "projection_ids": [affordance_id],
                },
            ]
        )
        owned_ids.extend(
            [
                decision_id,
                environment_id,
                zone_id,
                assignment_id,
                channel_id,
                hazard_id,
                hosting_id,
                affordance_id,
                transition_id,
            ]
        )
        environment_meta.append((environment_id, marker))

    topology = []
    for index in range(len(environment_meta) - 1):
        left_id, left_marker = environment_meta[index]
        right_id, right_marker = environment_meta[index + 1]
        edge_id = f"TOPO-{index+1:03d}"
        topology.append(
            {
                "id": edge_id,
                "from_id": left_id,
                "to_id": right_id,
                "relation": f"controlled transition between {left_marker} and {right_marker}",
                "mechanism": "permission-aware physical or secure logical passage",
                "constraints": [
                    f"Transition preserves constraints for {left_marker}.",
                    f"Transition preserves constraints for {right_marker}.",
                ],
            }
        )
        next(item for item in environments if item["id"] == left_id)[
            "connections"
        ].append(edge_id)
        next(item for item in environments if item["id"] == right_id)[
            "connections"
        ].append(edge_id)
        owned_ids.append(edge_id)

    projection_objects = {
        **{item["id"]: item for item in environments},
        **{item["id"]: item for item in affordances},
    }
    for claim in derivations:
        claim["value_sha256"] = runtime.canonical_sha256(
            projection_objects[claim["projection_ids"][0]]
        )

    locked = [
        item["id"]
        for item in baseline["control_registry"]
        if item["hardness"] == "author_locked"
    ]
    open_controls = [
        item
        for item in baseline["control_registry"]
        if item["hardness"] == "author_open"
    ]
    return {
        "schema_version": "2.0",
        "skill": "novel-environment-system-designer",
        "stage": "E1",
        "run_id": run_id,
        "status": "ready",
        "input_gate": copy.deepcopy(gate_reference),
        "source_artifacts": copy.deepcopy(source_artifacts),
        "authority_partition": {
            "author_locked": locked,
            "autonomous_owned": owned_ids,
            "downstream_freedom": [
                item["id"] for item in storyline["event_requirements"]
            ],
            "author_open": [item["id"] for item in open_controls],
        },
        "design_decisions": decisions,
        "derivation_claims": derivations,
        "environment_demands": demands,
        "storyline_environment_requirements": storyline_environment_requirements,
        "environments": environments,
        "functional_zones": zones,
        "environment_topology": topology,
        "access_and_authority": assignments,
        "resource_and_information_channels": channels,
        "hazards_and_failure_modes": hazards,
        "storyline_hosting_ledger": hosting,
        "event_affordance_catalog": affordances,
        "transition_contracts": transitions,
        "open_items": [
            {
                "id": f"OPEN-E1-{index:03d}",
                "question": f"Preserve author-open control {item['id']}.",
                "source_ids": [item["id"]],
                "status": "author_open",
            }
            for index, item in enumerate(open_controls, 1)
        ],
    }


class E1RuntimeTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.shared_temporary = tempfile.TemporaryDirectory()
        cls.shared = Path(cls.shared_temporary.name)
        cls.sources = baseline_test.SourceFixture(cls.shared / "sources")
        coordinator = runtime.AutonomousCoordinator.initialize(
            run_id=cls.sources.run_id,
            source_interview_state={
                "path": "interview/interview-state.json",
                "sha256": runtime.sha256_file(cls.sources.state),
            },
            state_path="state/revision-000.json",
        )
        b0_gate = coordinator.build_input_gate("B0", "B0/input-gate.json")
        cls.shared_b0 = cls.shared / "run" / "B0"
        runtime.build_baseline_package(
            **cls.sources.build_args(cls.shared_b0, b0_gate)
        )
        runtime.complete_b0(
            cls.shared_b0,
            coordinator=coordinator,
            input_gate=b0_gate,
            logical_package_path="B0",
            next_state_path="state/revision-001.json",
        )
        baseline = json.loads(
            (cls.shared_b0 / "author-control-baseline.json").read_text(
                encoding="utf-8"
            )
        )

        s1_gate = coordinator.build_input_gate("S1", "S1/input-gate.json")
        cls.shared_s1 = cls.shared / "run" / "S1"
        s1_workspace = cls.shared / "workspace" / "S1"
        controls = s1._controls(cls.shared_b0, baseline)
        s1_sources = [
            {
                "path": f"sources/B0/{name}",
                "sha256": runtime.sha256_file(cls.shared_b0 / name),
            }
            for name in (
                "author-control-baseline.json",
                "package-manifest.json",
                "stage-completion.json",
            )
        ]
        s1_model = s1_test.agent_proposal(
            run_id=cls.sources.run_id,
            gate_reference=s1_gate.reference,
            source_artifacts=s1_sources,
            controls=controls,
        )
        with mock.patch.dict(
            os.environ, {"CODEX_THREAD_ID": "thread-shared-s1"}, clear=False
        ):
            s1.start_s1_session(
                s1_workspace,
                baseline_package=cls.shared_b0,
                input_gate=s1_gate,
            )
            cls._submit(
                s1,
                s1_workspace,
                cls.shared_b0,
                None,
                None,
                s1_gate,
                s1_model,
                "final-storyline-model",
            )
            s1.run_s1(
                cls.shared_s1,
                baseline_package=cls.shared_b0,
                coordinator=coordinator,
                input_gate=s1_gate,
                controlled_workspace=s1_workspace,
                logical_package_path="S1",
                next_state_path="state/revision-002.json",
            )

        storyline = json.loads(
            (cls.shared_s1 / "storyline-architecture.json").read_text(
                encoding="utf-8"
            )
        )
        w1_gate = coordinator.build_input_gate("W1", "W1/input-gate.json")
        cls.shared_w1 = cls.shared / "run" / "W1"
        w1_workspace = cls.shared / "workspace" / "W1"
        w1_sources = [
            *[
                {
                    "path": f"sources/B0/{name}",
                    "sha256": runtime.sha256_file(cls.shared_b0 / name),
                }
                for name in (
                    "author-control-baseline.json",
                    "package-manifest.json",
                    "stage-completion.json",
                )
            ],
            *[
                {
                    "path": f"sources/S1/{name}",
                    "sha256": runtime.sha256_file(cls.shared_s1 / name),
                }
                for name in (
                    "storyline-architecture.json",
                    "package-manifest.json",
                    "stage-completion.json",
                )
            ],
        ]
        w1_model = w1_test.agent_world_proposal(
            run_id=cls.sources.run_id,
            gate_reference=w1_gate.reference,
            source_artifacts=w1_sources,
            baseline=baseline,
            storyline=storyline,
        )
        with mock.patch.dict(
            os.environ, {"CODEX_THREAD_ID": "thread-shared-w1"}, clear=False
        ):
            w1.start_w1_session(
                w1_workspace,
                baseline_package=cls.shared_b0,
                storyline_package=cls.shared_s1,
                input_gate=w1_gate,
            )
            cls._submit(
                w1,
                w1_workspace,
                cls.shared_b0,
                cls.shared_s1,
                None,
                w1_gate,
                w1_model,
                "final-world-model",
            )
            w1.run_w1(
                cls.shared_w1,
                baseline_package=cls.shared_b0,
                storyline_package=cls.shared_s1,
                coordinator=coordinator,
                input_gate=w1_gate,
                controlled_workspace=w1_workspace,
                logical_package_path="W1",
                next_state_path="state/revision-003.json",
            )
        cls.coordinator_state = coordinator.state
        cls.coordinator_reference = coordinator.state_reference

    @classmethod
    def _submit(
        cls,
        module,
        workspace,
        b0,
        s1_package,
        w1_package,
        gate,
        model,
        final_phase,
    ) -> None:
        for phase in module.PHASES:
            payload = (
                {"model": model}
                if phase == final_phase
                else {
                    field: model[field] for field in module.PHASE_FIELDS[phase]
                }
            )
            kwargs = {
                "baseline_package": b0,
                "input_gate": gate,
                "phase": phase,
                "payload": payload,
            }
            if s1_package is not None:
                kwargs["storyline_package"] = s1_package
            if w1_package is not None:
                kwargs["world_package"] = w1_package
            getattr(module, f"submit_{module.__name__.split('.')[-3].split('-')[0]}_phase", None)
            if module is s1:
                module.submit_s1_phase(workspace, **kwargs)
            elif module is w1:
                module.submit_w1_phase(workspace, **kwargs)
            else:
                module.submit_e1_phase(workspace, **kwargs)

    @classmethod
    def tearDownClass(cls) -> None:
        cls.shared_temporary.cleanup()

    def setUp(self) -> None:
        self.temporary = tempfile.TemporaryDirectory()
        self.work = Path(self.temporary.name)
        self.b0 = self.work / "run" / "B0"
        self.s1 = self.work / "run" / "S1"
        self.w1 = self.work / "run" / "W1"
        shutil.copytree(self.shared_b0, self.b0)
        shutil.copytree(self.shared_s1, self.s1)
        shutil.copytree(self.shared_w1, self.w1)
        self.coordinator = runtime.AutonomousCoordinator.from_snapshot(
            self.coordinator_state, self.coordinator_reference
        )
        self.gate = self.coordinator.build_input_gate(
            "E1", "E1/input-gate.json"
        )
        self.package = self.work / "run" / "E1"
        self.workspace = self.work / "workspace" / "E1"
        self.baseline = json.loads(
            (self.b0 / "author-control-baseline.json").read_text(encoding="utf-8")
        )
        self.storyline = json.loads(
            (self.s1 / "storyline-architecture.json").read_text(encoding="utf-8")
        )
        self.world = json.loads(
            (self.w1 / "world-model.json").read_text(encoding="utf-8")
        )
        sources = e1._source_artifacts(self.b0, self.s1, self.w1)
        self.proposal = agent_environment_proposal(
            run_id=self.sources.run_id,
            gate_reference=self.gate.reference,
            source_artifacts=sources,
            baseline=self.baseline,
            storyline=self.storyline,
            world=self.world,
        )
        with mock.patch.dict(
            os.environ, {"CODEX_THREAD_ID": "thread-generic-e1"}, clear=False
        ):
            e1.start_e1_session(
                self.workspace,
                baseline_package=self.b0,
                storyline_package=self.s1,
                world_package=self.w1,
                input_gate=self.gate,
            )
            self._submit(
                e1,
                self.workspace,
                self.b0,
                self.s1,
                self.w1,
                self.gate,
                self.proposal,
                "final-environment-model",
            )

    def tearDown(self) -> None:
        self.temporary.cleanup()

    def run_e1(self) -> e1.E1RunReceipt:
        with mock.patch.dict(
            os.environ, {"CODEX_THREAD_ID": "thread-generic-e1"}, clear=False
        ):
            return e1.run_e1(
                self.package,
                baseline_package=self.b0,
                storyline_package=self.s1,
                world_package=self.w1,
                coordinator=self.coordinator,
                input_gate=self.gate,
                controlled_workspace=self.workspace,
                logical_package_path="E1",
                next_state_path="state/revision-004.json",
            )

    def _validate(self, model: dict[str, object]) -> None:
        e1._validate_model(
            model,
            self.baseline,
            self.storyline,
            self.world,
            e1._controls(self.b0, self.baseline),
            runtime.ContractRuntime(),
            expected_gate=self.gate.reference,
            expected_sources=self.proposal["source_artifacts"],
        )

    def test_authority_partition_rejects_overlap_before_deep_validation(self) -> None:
        model = copy.deepcopy(self.proposal)
        model["authority_partition"]["downstream_freedom"].append(
            model["authority_partition"]["autonomous_owned"][0]
        )
        with self.assertRaisesRegex(
            e1.E1Error, "E1_AUTHORITY_PARTITION_OVERLAP"
        ):
            self._validate(model)

    def test_authority_partition_requires_all_four_exact_sets(self) -> None:
        model = copy.deepcopy(self.proposal)
        model["authority_partition"]["autonomous_owned"].remove(
            model["event_affordance_catalog"][0]["id"]
        )
        with self.assertRaisesRegex(
            e1.E1Error, "E1_AUTHORITY_PARTITION_MISMATCH"
        ):
            self._validate(model)

    def test_storyline_environment_projection_and_joint_hosting_are_exact(
        self,
    ) -> None:
        self.assertEqual(
            self.storyline["environment_requirements"],
            self.proposal["storyline_environment_requirements"],
        )
        demand_ids = {item["id"] for item in self.world["environment_demands"]}
        requirement_ids = {
            item["id"] for item in self.storyline["environment_requirements"]
        }
        hosted_demands = []
        hosted_requirements = []
        for record in self.proposal["storyline_hosting_ledger"]:
            hosted_demands.extend(set(record["source_ids"]) & demand_ids)
            hosted_requirements.extend(set(record["source_ids"]) & requirement_ids)
        self.assertCountEqual(hosted_demands, demand_ids)
        self.assertCountEqual(hosted_requirements, requirement_ids)

        missing = copy.deepcopy(self.proposal)
        missing["storyline_hosting_ledger"][0]["source_ids"].remove(
            next(
                item
                for item in missing["storyline_hosting_ledger"][0]["source_ids"]
                if item in requirement_ids
            )
        )
        with self.assertRaisesRegex(
            e1.E1Error, "E1_HOSTING_COVERAGE_MISMATCH"
        ):
            self._validate(missing)

        wrong_line = copy.deepcopy(self.proposal)
        first, second = wrong_line["storyline_hosting_ledger"][:2]
        first_requirement = next(
            item for item in first["source_ids"] if item in requirement_ids
        )
        second_requirement = next(
            item for item in second["source_ids"] if item in requirement_ids
        )
        first["source_ids"].remove(first_requirement)
        second["source_ids"].remove(second_requirement)
        first["source_ids"].append(second_requirement)
        second["source_ids"].append(first_requirement)
        with self.assertRaisesRegex(e1.E1Error, "E1_HOSTING_LINE_MISMATCH"):
            self._validate(wrong_line)

    def test_storyline_environment_projection_is_lossless_and_session_bound(
        self,
    ) -> None:
        changed = copy.deepcopy(self.proposal)
        changed["storyline_environment_requirements"][0][
            "responsibility"
        ] += " changed"
        with self.assertRaisesRegex(
            e1.E1Error, "E1_STORYLINE_ENVIRONMENT_PROJECTION_MISMATCH"
        ):
            self._validate(changed)

        session = json.loads(
            (self.workspace / "generation-session.json").read_text(
                encoding="utf-8"
            )
        )
        self.assertIn("storyline_environment_requirement_bindings", session)
        session["storyline_environment_requirement_bindings"][0][
            "value_sha256"
        ] = "0" * 64
        (self.workspace / "generation-session.json").write_text(
            runtime.canonical_json(session), encoding="utf-8"
        )
        with mock.patch.dict(
            os.environ, {"CODEX_THREAD_ID": "thread-generic-e1"}, clear=False
        ):
            with self.assertRaisesRegex(e1.E1Error, "E1_SESSION_INVALID"):
                e1._validated_session(
                    self.workspace,
                    baseline_package=self.b0,
                    storyline_package=self.s1,
                    world_package=self.w1,
                    input_gate=self.gate,
                    runtime=runtime.ContractRuntime(),
                )

    def test_ready_environment_system_advances_and_covers_inputs(self) -> None:
        receipt = self.run_e1()
        model = receipt.model
        demand_ids = {item["id"] for item in model["environment_demands"]}
        self.assertEqual(
            demand_ids,
            {
                item["source_ids"][0]
                for item in model["storyline_hosting_ledger"]
            },
        )
        self.assertEqual(
            {item["id"] for item in self.storyline["event_requirements"]},
            {
                requirement_id
                for item in model["event_affordance_catalog"]
                for requirement_id in item["event_requirement_ids"]
            },
        )
        self.assertEqual("E1", receipt.completion.data["stage"])
        self.assertEqual(4, receipt.transition.snapshot["revision"])
        self.assertEqual(
            "ready", e1.validate_e1_package(self.package)["verdict"]
        )

    def test_changed_w1_demand_changes_every_agent_phase(self) -> None:
        left_world = copy.deepcopy(self.world)
        right_world = copy.deepcopy(self.world)
        left_world["environment_demands"][0]["responsibility"] = (
            "Host a controlled interior interface."
        )
        right_world["environment_demands"][0]["responsibility"] = (
            "Host an exposed border interface."
        )
        sources = copy.deepcopy(self.proposal["source_artifacts"])
        left = agent_environment_proposal(
            run_id=self.sources.run_id,
            gate_reference=self.gate.reference,
            source_artifacts=sources,
            baseline=self.baseline,
            storyline=self.storyline,
            world=left_world,
        )
        right = agent_environment_proposal(
            run_id=self.sources.run_id,
            gate_reference=self.gate.reference,
            source_artifacts=sources,
            baseline=self.baseline,
            storyline=self.storyline,
            world=right_world,
        )
        for phase in e1.PHASES:
            left_payload = (
                {"model": left}
                if phase == "final-environment-model"
                else {field: left[field] for field in e1.PHASE_FIELDS[phase]}
            )
            right_payload = (
                {"model": right}
                if phase == "final-environment-model"
                else {field: right[field] for field in e1.PHASE_FIELDS[phase]}
            )
            self.assertNotEqual(
                runtime.canonical_sha256(left_payload),
                runtime.canonical_sha256(right_payload),
                phase,
            )

    def test_changed_s1_environment_requirement_changes_every_agent_phase(
        self,
    ) -> None:
        left_storyline = copy.deepcopy(self.storyline)
        right_storyline = copy.deepcopy(self.storyline)
        left_storyline["environment_requirements"][0]["responsibility"] = (
            "Host a controlled interior obligation."
        )
        right_storyline["environment_requirements"][0]["responsibility"] = (
            "Host an exposed border obligation."
        )
        sources = copy.deepcopy(self.proposal["source_artifacts"])
        left = agent_environment_proposal(
            run_id=self.sources.run_id,
            gate_reference=self.gate.reference,
            source_artifacts=sources,
            baseline=self.baseline,
            storyline=left_storyline,
            world=self.world,
        )
        right = agent_environment_proposal(
            run_id=self.sources.run_id,
            gate_reference=self.gate.reference,
            source_artifacts=sources,
            baseline=self.baseline,
            storyline=right_storyline,
            world=self.world,
        )
        for phase in e1.PHASES:
            left_payload = (
                {"model": left}
                if phase == "final-environment-model"
                else {field: left[field] for field in e1.PHASE_FIELDS[phase]}
            )
            right_payload = (
                {"model": right}
                if phase == "final-environment-model"
                else {field: right[field] for field in e1.PHASE_FIELDS[phase]}
            )
            self.assertNotEqual(
                runtime.canonical_sha256(left_payload),
                runtime.canonical_sha256(right_payload),
                phase,
            )

    def test_resealed_failures_remain_blocked(self) -> None:
        self.run_e1()
        original = self._read_model(self.package)
        cases = []

        deleted_hosting = copy.deepcopy(original)
        removed = deleted_hosting["storyline_hosting_ledger"].pop()
        deleted_hosting["authority_partition"]["autonomous_owned"].remove(
            removed["id"]
        )
        cases.append(
            ("deleted-hosting", deleted_hosting, "E1_HOSTING_COVERAGE_MISMATCH")
        )

        unreachable = copy.deepcopy(original)
        unreachable["environment_topology"].pop(len(unreachable["environment_topology"]) // 2)
        cases.append(("unreachable", unreachable, "E1_TOPOLOGY_UNREACHABLE"))

        missing_action = copy.deepcopy(original)
        missing_action["event_affordance_catalog"][0]["allowed_actions"] = [
            "An action not exposed by the environment."
        ]
        cases.append(
            ("missing-action", missing_action, "E1_ACTION_INTERFACE_MISSING")
        )

        rule_conflict = copy.deepcopy(original)
        demand = rule_conflict["environment_demands"][0]
        environment = next(
            item
            for item in rule_conflict["environments"]
            if demand["id"] in item["storyline_stage_ids"]
        )
        environment["access_rules"].remove(demand["constraints"][0])
        cases.append(("rule-conflict", rule_conflict, "E1_WORLD_RULE_CONFLICT"))

        storyline_rule_conflict = copy.deepcopy(original)
        storyline_requirement = storyline_rule_conflict[
            "storyline_environment_requirements"
        ][0]
        environment = next(
            item
            for item in storyline_rule_conflict["environments"]
            if storyline_requirement["id"] in item["storyline_stage_ids"]
        )
        environment["access_rules"].remove(
            storyline_requirement["constraints"][0]
        )
        cases.append(
            (
                "storyline-rule-conflict",
                storyline_rule_conflict,
                "E1_WORLD_RULE_CONFLICT",
            )
        )

        forged_gate = copy.deepcopy(original)
        forged_gate["input_gate"]["sha256"] = "0" * 64
        cases.append(
            ("forged-gate", forged_gate, "E1_GATE_REFERENCE_MISMATCH")
        )

        for name, model, expected in cases:
            with self.subTest(name=name):
                mutant = self.work / "mutants" / name
                shutil.copytree(self.package, mutant)
                self._reseal_model(mutant, model, gate=model["input_gate"])
                with self.assertRaises(e1.E1Error) as caught:
                    e1.validate_e1_package(mutant)
                self.assertEqual(expected, caught.exception.code)

        missing_completion = self.work / "mutants" / "missing-completion"
        shutil.copytree(self.package, missing_completion)
        (missing_completion / "stage-completion.json").unlink()
        with self.assertRaises(e1.E1Error) as caught:
            e1.validate_e1_package(missing_completion)
        self.assertEqual("E1_COMPLETION_MISSING", caught.exception.code)

        boundary = self.work / "mutants" / "boundary"
        shutil.copytree(self.package, boundary)
        (boundary / "event-timeline.json").write_text("{}", encoding="utf-8")
        with self.assertRaises(e1.E1Error) as caught:
            e1.validate_e1_package(boundary)
        self.assertEqual("E1_BOUNDARY_VIOLATION", caught.exception.code)

    def test_cross_object_semantic_mismatches_are_rejected(self) -> None:
        self.run_e1()
        original = self._read_model(self.package)

        swapped_affordances = copy.deepcopy(original)
        first_affordance, second_affordance = (
            swapped_affordances["event_affordance_catalog"][:2]
        )
        (
            first_affordance["event_requirement_ids"],
            second_affordance["event_requirement_ids"],
        ) = (
            second_affordance["event_requirement_ids"],
            first_affordance["event_requirement_ids"],
        )

        foreign_transition = copy.deepcopy(original)
        foreign_transition["transition_contracts"][0]["trigger_ids"] = [
            foreign_transition["event_affordance_catalog"][1]["id"]
        ]

        placeholder_channels = copy.deepcopy(original)
        for channel in placeholder_channels["resource_and_information_channels"]:
            channel["relation"] = "generic channel"
            channel["mechanism"] = "placeholder"
            channel["constraints"] = ["nonempty but unbound"]

        cases = (
            (
                "swapped-affordances",
                swapped_affordances,
                "E1_AFFORDANCE_LINE_MISMATCH",
            ),
            (
                "foreign-transition-trigger",
                foreign_transition,
                "E1_TRANSITION_ENVIRONMENT_MISMATCH",
            ),
            (
                "placeholder-channels",
                placeholder_channels,
                "E1_CHANNEL_SEMANTICS_INCOMPLETE",
            ),
        )
        for name, model, expected in cases:
            with self.subTest(name=name):
                mutant = self.work / "semantic-mutants" / name
                shutil.copytree(self.package, mutant)
                self._reseal_model(mutant, model, gate=model["input_gate"])
                with self.assertRaises(e1.E1Error) as caught:
                    e1.validate_e1_package(mutant)
                self.assertEqual(expected, caught.exception.code)

    def test_resealed_prose_artifact_is_a_boundary_violation(self) -> None:
        self.run_e1()
        for filename in (
            "chapterDraft.md",
            "draft.md",
            "generation-evidence/draft.md",
            "implementation/draft.md",
        ):
            with self.subTest(filename=filename):
                mutant = (
                    self.work
                    / "path-mutants"
                    / filename.replace(".", "-").replace("/", "-")
                )
                shutil.copytree(self.package, mutant)
                extra = mutant / filename
                extra.parent.mkdir(parents=True, exist_ok=True)
                extra.write_text(
                    "# Unauthorized extra artifact\n", encoding="utf-8"
                )
                manifest_path = mutant / "package-manifest.json"
                manifest = json.loads(
                    manifest_path.read_text(encoding="utf-8")
                )
                manifest["files"].append(
                    runtime.artifact_reference(extra, root=mutant)
                )
                manifest_path.write_text(
                    runtime.canonical_json(manifest), encoding="utf-8"
                )
                completion_path = mutant / "stage-completion.json"
                completion = json.loads(
                    completion_path.read_text(encoding="utf-8")
                )
                completion["manifest"]["sha256"] = runtime.sha256_file(
                    manifest_path
                )
                completion_path.write_text(
                    runtime.canonical_json(completion), encoding="utf-8"
                )

                with self.assertRaises(e1.E1Error) as caught:
                    e1.validate_e1_package(mutant)

                self.assertEqual(
                    "E1_BOUNDARY_VIOLATION", caught.exception.code
                )

    @staticmethod
    def _read_model(package: Path) -> dict[str, object]:
        return json.loads(
            (package / "environment-system.json").read_text(encoding="utf-8")
        )

    @staticmethod
    def _reseal_model(
        package: Path,
        model: dict[str, object],
        *,
        gate: dict[str, str],
    ) -> None:
        model_path = package / "environment-system.json"
        model_path.write_text(runtime.canonical_json(model), encoding="utf-8")
        execution_path = package / "execution-record.json"
        execution = json.loads(execution_path.read_text(encoding="utf-8"))
        execution["output_sha256"] = runtime.canonical_sha256(model)
        execution["input_gate"] = copy.deepcopy(gate)
        execution_path.write_text(
            runtime.canonical_json(execution), encoding="utf-8"
        )
        manifest_path = package / "package-manifest.json"
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
        replacements = {
            "environment-system.json": runtime.artifact_reference(
                model_path, root=package
            ),
            "execution-record.json": runtime.artifact_reference(
                execution_path, root=package
            ),
        }
        manifest["files"] = [
            replacements.get(item["path"], item) for item in manifest["files"]
        ]
        manifest["artifact_roles"]["canonical"] = replacements[
            "environment-system.json"
        ]
        manifest["artifact_roles"]["execution_record"] = replacements[
            "execution-record.json"
        ]
        manifest_path.write_text(
            runtime.canonical_json(manifest), encoding="utf-8"
        )
        completion_path = package / "stage-completion.json"
        completion = json.loads(completion_path.read_text(encoding="utf-8"))
        completion["manifest"]["sha256"] = runtime.sha256_file(manifest_path)
        completion["input_gate"] = copy.deepcopy(gate)
        completion_path.write_text(
            runtime.canonical_json(completion), encoding="utf-8"
        )


if __name__ == "__main__":
    unittest.main()
