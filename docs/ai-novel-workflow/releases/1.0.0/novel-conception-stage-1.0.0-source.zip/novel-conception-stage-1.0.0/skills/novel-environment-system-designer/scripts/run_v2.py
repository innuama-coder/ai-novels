"""Production E1 runner for autonomous novel-conception V2."""

from __future__ import annotations

import copy
import importlib
import json
import os
import re
import shutil
import tempfile
from dataclasses import dataclass
from pathlib import Path, PurePosixPath
from typing import Any, Mapping, Sequence


rt = importlib.import_module("harnesses.novel-conception-autonomous.runtime")
s1_runtime = importlib.import_module(
    "skills.novel-storyline-architecture-designer.scripts.run_v2"
)
w1_runtime = importlib.import_module(
    "skills.novel-world-model-designer.scripts.run_v2"
)
_HERE = Path(__file__).resolve()
_REPO = _HERE.parents[3]
_SKILL = _HERE.parents[1]
_S1_SKILL = _REPO / "skills" / "novel-storyline-architecture-designer"
_W1_SKILL = _REPO / "skills" / "novel-world-model-designer"
_SCHEMAS = _REPO / "docs" / "ai-novel-workflow" / "contracts" / "autonomous-v2"

PHASES = (
    "environment-demand-scan",
    "environment-architecture",
    "zones-and-topology",
    "storyline-hosting-test",
    "final-environment-model",
)
PHASE_FIELDS = {
    "environment-demand-scan": (
        "environment_demands",
        "storyline_environment_requirements",
    ),
    "environment-architecture": ("design_decisions", "environments"),
    "zones-and-topology": (
        "functional_zones",
        "environment_topology",
        "access_and_authority",
        "resource_and_information_channels",
        "hazards_and_failure_modes",
        "transition_contracts",
    ),
    "storyline-hosting-test": (
        "storyline_hosting_ledger",
        "event_affordance_catalog",
        "authority_partition",
        "derivation_claims",
        "open_items",
    ),
    "final-environment-model": ("model",),
}
_FORBIDDEN_MODEL_KEYS = {
    "storylines",
    "events",
    "event_timeline",
    "event_results",
    "characters",
    "character_profiles",
    "scenes",
    "scene_text",
    "prose",
}
_FORBIDDEN_NESTED_KEYS = {
    "outcome",
    "result",
    "initiator",
    "scheduled_time",
    "scene_text",
    "dialogue",
    "camera",
}
_ALLOWED_ROOT_FILES = {
    "input-gate.json",
    "environment-system.json",
    "generation-session.json",
    "generation-evidence-index.json",
    "execution-record.json",
    "environment-preview.md",
    "validation.json",
    "package-manifest.json",
    "stage-completion.json",
}
_ALLOWED_SOURCE_PREFIXES = (
    "sources/B0/",
    "sources/S1/",
    "sources/W1/",
)


class E1Error(ValueError):
    def __init__(self, code: str, message: str):
        self.code = code
        super().__init__(f"{code}: {message}")


@dataclass(frozen=True)
class E1RunReceipt:
    package_root: Path
    model: dict[str, Any]
    manifest: dict[str, Any]
    completion: Any
    transition: Any


def _fail(code: str, message: str) -> None:
    raise E1Error(code, message)


def _validate_authority_disjoint(partition: Mapping[str, Any]) -> None:
    names = (
        "author_locked",
        "autonomous_owned",
        "downstream_freedom",
        "author_open",
    )
    values = {name: set(partition[name]) for name in names}
    for index, left in enumerate(names):
        for right in names[index + 1 :]:
            overlap = sorted(values[left] & values[right])
            if overlap:
                _fail(
                    "E1_AUTHORITY_PARTITION_OVERLAP",
                    f"{left}/{right}: {overlap}",
                )


def _read(path: Path, code: str) -> dict[str, Any]:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, UnicodeError, json.JSONDecodeError) as error:
        _fail(code, f"{path}: {error}")
    if not isinstance(value, dict):
        _fail(code, f"{path} root must be an object")
    return value


def _write(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(rt.canonical_json(value), encoding="utf-8", newline="")


def _logical(prefix: str, name: str) -> str:
    value = PurePosixPath(prefix, name).as_posix() if prefix else name
    if value.startswith("/") or ".." in PurePosixPath(value).parts:
        _fail("E1_PATH_INVALID", value)
    return value


def _implementation_paths() -> dict[str, Path]:
    runtime_dir = _REPO / "harnesses" / "novel-conception-autonomous" / "runtime"
    values = {
        "skill/run_v2.py": _HERE,
        "skill/SKILL.md": _SKILL / "SKILL.md",
        "skill/runtime-contract.md": _SKILL / "references" / "runtime-contract.md",
        "upstream/S1-run_v2.py": _S1_SKILL / "scripts" / "run_v2.py",
        "upstream/S1-runtime-contract.md": (
            _S1_SKILL / "references" / "runtime-contract.md"
        ),
        "upstream/W1-run_v2.py": _W1_SKILL / "scripts" / "run_v2.py",
        "upstream/W1-runtime-contract.md": (
            _W1_SKILL / "references" / "runtime-contract.md"
        ),
    }
    for name in (
        "canonical.py",
        "contracts.py",
        "coordinator.py",
        "baseline.py",
        "b0_completion.py",
    ):
        values[f"runtime/{name}"] = runtime_dir / name
    for name in (
        "environment-system.schema.json",
        "world-model.schema.json",
        "storyline-architecture.schema.json",
        "author-control-baseline.schema.json",
        "canonical-common.schema.json",
        "common-defs.schema.json",
        "input-gate.schema.json",
        "package-manifest.schema.json",
        "stage-completion.schema.json",
    ):
        values[f"schemas/{name}"] = _SCHEMAS / name
    return values


def _stage_reference(root: Path, stage: str) -> dict[str, str]:
    path = root / "stage-completion.json"
    _read(path, f"E1_{stage}_INVALID")
    return {
        "stage": stage,
        "path": f"{stage}/stage-completion.json",
        "sha256": rt.sha256_file(path),
    }


def _source_artifacts(
    b0_root: Path, s1_root: Path, w1_root: Path
) -> list[dict[str, str]]:
    selected = {
        "B0": (
            b0_root,
            (
                "author-control-baseline.json",
                "package-manifest.json",
                "stage-completion.json",
            ),
        ),
        "S1": (
            s1_root,
            (
                "storyline-architecture.json",
                "package-manifest.json",
                "stage-completion.json",
            ),
        ),
        "W1": (
            w1_root,
            (
                "world-model.json",
                "package-manifest.json",
                "stage-completion.json",
            ),
        ),
    }
    return [
        {
            "path": f"sources/{stage}/{name}",
            "sha256": rt.sha256_file(root / name),
        }
        for stage, (root, names) in selected.items()
        for name in names
    ]


def _controls(
    b0_root: Path, baseline: Mapping[str, Any]
) -> list[dict[str, Any]]:
    found: list[dict[str, Any]] = []
    for entry in baseline["design_artifacts"]:
        source = rt.verify_artifact_reference(entry["artifact"], root=b0_root)
        for value in rt.extract_controls(source, entry["domain"]):
            found.append({**value, "domain": entry["domain"]})
    found.sort(key=lambda item: item["id"])
    return found


def _object_bindings(
    values: Sequence[Mapping[str, Any]], *, extra: str | None = None
) -> list[dict[str, str]]:
    return [
        {
            "id": item["id"],
            **({extra: str(item[extra])} if extra is not None else {}),
            "value_sha256": rt.canonical_sha256(item),
        }
        for item in values
    ]


def _control_bindings(
    controls: Sequence[Mapping[str, Any]],
) -> list[dict[str, str]]:
    return [
        {
            "id": item["id"],
            "domain": item["domain"],
            "heading": item["heading"],
            "value_sha256": rt.canonical_sha256(item["value"]),
        }
        for item in controls
    ]


def _session_id(
    thread_id: str,
    gate: Mapping[str, str],
    b0: Mapping[str, str],
    s1: Mapping[str, str],
    w1: Mapping[str, str],
) -> str:
    return "E1-" + rt.canonical_sha256([thread_id, gate, b0, s1, w1])[:20]


def _session_context(
    *,
    baseline_package: str | Path,
    storyline_package: str | Path,
    world_package: str | Path,
    input_gate: Any,
    runtime: Any,
    full_validation: bool = True,
) -> tuple[
    Path,
    Path,
    Path,
    dict[str, Any],
    dict[str, Any],
    dict[str, Any],
    list[dict[str, Any]],
    dict[str, str],
    dict[str, str],
    dict[str, str],
]:
    b0_root = Path(baseline_package).resolve()
    s1_root = Path(storyline_package).resolve()
    w1_root = Path(world_package).resolve()
    if full_validation:
        try:
            rt.validate_baseline_package(b0_root, runtime=runtime)
        except Exception as error:
            _fail("E1_B0_INVALID", str(error))
        try:
            s1_runtime.validate_s1_package(s1_root, runtime=runtime)
        except Exception as error:
            _fail("E1_S1_INVALID", str(error))
        try:
            w1_runtime.validate_w1_package(w1_root, runtime=runtime)
        except Exception as error:
            _fail("E1_W1_INVALID", str(error))
    baseline = _read(
        b0_root / "author-control-baseline.json", "E1_B0_INVALID"
    )
    storyline = _read(
        s1_root / "storyline-architecture.json", "E1_S1_INVALID"
    )
    world = _read(w1_root / "world-model.json", "E1_W1_INVALID")
    if {baseline["run_id"], storyline["run_id"], world["run_id"]} != {
        baseline["run_id"]
    }:
        _fail("E1_RUN_ID_MISMATCH", "B0/S1/W1 runs differ")
    b0_ref = _stage_reference(b0_root, "B0")
    s1_ref = _stage_reference(s1_root, "S1")
    w1_ref = _stage_reference(w1_root, "W1")
    if (
        rt.sha256_file(s1_root / "sources" / "B0" / "stage-completion.json")
        != b0_ref["sha256"]
        or rt.sha256_file(
            w1_root / "sources" / "B0" / "stage-completion.json"
        )
        != b0_ref["sha256"]
        or rt.sha256_file(
            w1_root / "sources" / "S1" / "stage-completion.json"
        )
        != s1_ref["sha256"]
    ):
        _fail("E1_UPSTREAM_LINEAGE_MISMATCH", "S1/W1 do not share B0 lineage")
    try:
        runtime.validate(input_gate.data, "input-gate.schema.json")
    except Exception as error:
        _fail("E1_GATE_INVALID", str(error))
    if (
        input_gate.data.get("target_stage") != "E1"
        or input_gate.data.get("run_id") != baseline["run_id"]
        or input_gate.data.get("baseline_completion") != b0_ref
        or input_gate.data.get("upstream_completions") != [s1_ref, w1_ref]
        or rt.canonical_sha256(input_gate.data)
        != input_gate.reference.get("sha256")
    ):
        _fail("E1_GATE_INVALID", "gate is not the exact E1/B0/S1/W1 gate")
    return (
        b0_root,
        s1_root,
        w1_root,
        baseline,
        storyline,
        world,
        _controls(b0_root, baseline),
        b0_ref,
        s1_ref,
        w1_ref,
    )


def _nested_forbidden(value: Any) -> str | None:
    if isinstance(value, Mapping):
        for key, child in value.items():
            if key in _FORBIDDEN_NESTED_KEYS:
                return key
            found = _nested_forbidden(child)
            if found is not None:
                return found
    elif isinstance(value, list):
        for child in value:
            found = _nested_forbidden(child)
            if found is not None:
                return found
    return None


def _boundary_check(model: Mapping[str, Any]) -> None:
    forbidden = sorted(set(model) & _FORBIDDEN_MODEL_KEYS)
    if forbidden:
        _fail("E1_BOUNDARY_VIOLATION", f"forbidden top-level fields: {forbidden}")
    nested = _nested_forbidden(model)
    if nested is not None:
        _fail("E1_BOUNDARY_VIOLATION", f"forbidden event/prose field: {nested}")


def _reachable(environment_ids: set[str], edges: Sequence[Mapping[str, Any]]) -> bool:
    if not environment_ids:
        return False
    adjacency = {item: set() for item in environment_ids}
    for edge in edges:
        left, right = edge["from_id"], edge["to_id"]
        if left in adjacency and right in adjacency:
            adjacency[left].add(right)
            adjacency[right].add(left)
    visited: set[str] = set()
    stack = [next(iter(environment_ids))]
    while stack:
        current = stack.pop()
        if current in visited:
            continue
        visited.add(current)
        stack.extend(adjacency[current] - visited)
    return visited == environment_ids


def _channel_tokens(value: Mapping[str, Any], kind: str) -> set[str]:
    pattern = re.compile(rf"\[{re.escape(kind)}:([^\[\]]+)\]")
    return set(pattern.findall(rt.canonical_json(value)))


def _validate_model(
    model: Mapping[str, Any],
    baseline: Mapping[str, Any],
    storyline: Mapping[str, Any],
    world: Mapping[str, Any],
    controls: Sequence[Mapping[str, Any]],
    runtime: Any,
    *,
    expected_gate: Mapping[str, str] | None = None,
    expected_sources: Sequence[Mapping[str, str]] | None = None,
) -> None:
    _boundary_check(model)
    try:
        runtime.validate(model, "environment-system.schema.json")
    except Exception as error:
        _fail("E1_MODEL_SCHEMA_INVALID", str(error))
    partition = model["authority_partition"]
    _validate_authority_disjoint(partition)
    if model["run_id"] != baseline["run_id"]:
        _fail("E1_RUN_ID_MISMATCH", "model belongs to another run")
    if (
        model["storyline_environment_requirements"]
        != storyline["environment_requirements"]
    ):
        _fail(
            "E1_STORYLINE_ENVIRONMENT_PROJECTION_MISMATCH",
            "E1 must consume exact S1 environment requirements",
        )
    if model["environment_demands"] != world["environment_demands"]:
        _fail(
            "E1_DEMAND_PROJECTION_MISMATCH",
            "E1 must consume exact W1 environment demands",
        )

    demands = model["environment_demands"]
    demands_by_id = {item["id"]: item for item in demands}
    if len(demands_by_id) != len(demands):
        _fail("E1_DEMAND_DUPLICATE", "environment demand IDs repeat")
    lines = {item["id"]: item for item in storyline["storylines"]}
    storyline_environment_requirements = model[
        "storyline_environment_requirements"
    ]
    storyline_environment_requirements_by_id = {
        item["id"]: item for item in storyline_environment_requirements
    }
    if len(storyline_environment_requirements_by_id) != len(
        storyline_environment_requirements
    ):
        _fail(
            "E1_STORYLINE_ENVIRONMENT_REQUIREMENT_DUPLICATE",
            "S1 environment requirement IDs repeat",
        )
    storyline_environment_requirement_line: dict[str, str] = {}
    for requirement_id, requirement in (
        storyline_environment_requirements_by_id.items()
    ):
        line_ids = [item for item in requirement["source_ids"] if item in lines]
        if len(line_ids) != 1:
            _fail("E1_STORYLINE_ENVIRONMENT_REQUIREMENT_DANGLING", requirement_id)
        storyline_environment_requirement_line[requirement_id] = line_ids[0]
    if set(storyline_environment_requirement_line.values()) != set(lines):
        _fail(
            "E1_STORYLINE_COVERAGE_MISMATCH",
            "S1 environment requirements do not cover every storyline",
        )
    event_requirements = {
        item["id"]: item for item in storyline["event_requirements"]
    }
    event_requirement_line: dict[str, str] = {}
    for requirement_id, requirement in event_requirements.items():
        line_ids = [item for item in requirement["source_ids"] if item in lines]
        if len(line_ids) != 1:
            _fail("E1_EVENT_REQUIREMENT_DANGLING", requirement_id)
        event_requirement_line[requirement_id] = line_ids[0]
    world_entities = {
        item["id"]: item
        for field in (
            "world_facts",
            "history_pressures",
            "institutions",
            "systems",
            "resource_flows",
            "authority_flows",
            "information_flows",
            "rule_conflict_matrix",
            "storyline_support_ledger",
        )
        for item in world[field]
    }
    demand_line: dict[str, str] = {}
    demand_support: dict[str, list[str]] = {}
    for demand in demands:
        world_requirement_ids = {
            item["id"] for item in world["storyline_requirements"]
        }
        requirement_ids = [
            item for item in demand["source_ids"] if item in world_requirement_ids
        ]
        support_ids = [
            item for item in demand["source_ids"] if item in world_entities
        ]
        if len(requirement_ids) != 1 or not support_ids:
            _fail("E1_DEMAND_SOURCE_INVALID", demand["id"])
        world_requirement = next(
            item
            for item in world["storyline_requirements"]
            if item["id"] == requirement_ids[0]
        )
        line_ids = [item for item in world_requirement["source_ids"] if item in lines]
        if len(line_ids) != 1:
            _fail("E1_STORYLINE_ID_DANGLING", demand["id"])
        demand_line[demand["id"]] = line_ids[0]
        demand_support[demand["id"]] = support_ids
    if set(demand_line.values()) != set(lines):
        _fail(
            "E1_STORYLINE_COVERAGE_MISMATCH",
            "W1 demands do not cover every S1 storyline",
        )

    environments = {item["id"]: item for item in model["environments"]}
    zones = {item["id"]: item for item in model["functional_zones"]}
    if len(environments) != len(model["environments"]) or len(zones) != len(
        model["functional_zones"]
    ):
        _fail("E1_ID_DUPLICATE", "environment or zone IDs repeat")
    responsibilities = [
        item["narrative_responsibility"] for item in environments.values()
    ]
    if len(responsibilities) != len(set(responsibilities)):
        _fail(
            "E1_ENVIRONMENT_NOT_DISTINCT",
            "each environment needs a non-equivalent narrative responsibility",
        )
    for zone in zones.values():
        if zone["environment_id"] not in environments:
            _fail("E1_ZONE_DANGLING", zone["id"])
    for environment in environments.values():
        actual_zones = {
            zone["id"]
            for zone in zones.values()
            if zone["environment_id"] == environment["id"]
        }
        if set(environment["zone_ids"]) != actual_zones or not actual_zones:
            _fail("E1_ZONE_COVERAGE_MISMATCH", environment["id"])
        allowed_stage_ids = (
            set(lines)
            | set(demands_by_id)
            | set(storyline_environment_requirements_by_id)
        )
        if (
            not set(environment["storyline_stage_ids"]).issubset(allowed_stage_ids)
            or not set(environment["storyline_stage_ids"]) & set(demands_by_id)
            or not set(environment["storyline_stage_ids"])
            & set(storyline_environment_requirements_by_id)
        ):
            _fail("E1_NEW_STORYLINE_FORBIDDEN", environment["id"])
        if (
            not environment["allowed_actions"]
            or not environment["sensory_conditions"]
            or not environment["access_rules"]
            or not environment["resources"]
            or not environment["blockers"]
            or not environment["hazards"]
        ):
            _fail("E1_ENVIRONMENT_CAPABILITY_INCOMPLETE", environment["id"])

    topology = {item["id"]: item for item in model["environment_topology"]}
    if len(topology) != len(model["environment_topology"]):
        _fail("E1_ID_DUPLICATE", "topology IDs repeat")
    for edge in topology.values():
        if edge["from_id"] not in environments or edge["to_id"] not in environments:
            _fail("E1_TOPOLOGY_DANGLING", edge["id"])
    if not _reachable(set(environments), list(topology.values())):
        _fail("E1_TOPOLOGY_UNREACHABLE", "environment graph is disconnected")
    for environment in environments.values():
        expected_connections = {
            edge["id"]
            for edge in topology.values()
            if environment["id"] in (edge["from_id"], edge["to_id"])
        }
        if set(environment["connections"]) != expected_connections:
            _fail("E1_TOPOLOGY_CONNECTION_MISMATCH", environment["id"])

    assignments = {
        item["id"]: item for item in model["access_and_authority"]
    }
    channels = {
        item["id"]: item
        for item in model["resource_and_information_channels"]
    }
    hazards = {item["id"]: item for item in model["hazards_and_failure_modes"]}
    if any(
        len(values) != len(source)
        for values, source in (
            (assignments, model["access_and_authority"]),
            (channels, model["resource_and_information_channels"]),
            (hazards, model["hazards_and_failure_modes"]),
        )
    ):
        _fail("E1_ID_DUPLICATE", "environment interface IDs repeat")
    environment_or_zone = set(environments) | set(zones)
    for assignment in assignments.values():
        if assignment["subject_id"] not in environment_or_zone:
            _fail("E1_AUTHORITY_DANGLING", assignment["id"])
        if not set(assignment["evidence_ids"]).issubset(world_entities):
            _fail("E1_WORLD_RULE_CONFLICT", assignment["id"])
    for channel in channels.values():
        if (
            channel["from_id"] not in environment_or_zone
            or channel["to_id"] not in environment_or_zone
        ):
            _fail("E1_CHANNEL_DANGLING", channel["id"])
    for hazard in hazards.values():
        if hazard["environment_id"] not in environments:
            _fail("E1_HAZARD_DANGLING", hazard["id"])
    for environment_id in environments:
        if not any(
            assignment["subject_id"] == environment_id
            for assignment in assignments.values()
        ):
            _fail("E1_AUTHORITY_COVERAGE_MISMATCH", environment_id)
        if not any(
            environment_id in (channel["from_id"], channel["to_id"])
            for channel in channels.values()
        ):
            _fail("E1_CHANNEL_COVERAGE_MISMATCH", environment_id)
        if not any(
            hazard["environment_id"] == environment_id
            for hazard in hazards.values()
        ):
            _fail("E1_HAZARD_COVERAGE_MISMATCH", environment_id)

    hosting_by_demand: dict[str, Mapping[str, Any]] = {}
    hosting_by_storyline_requirement: dict[str, Mapping[str, Any]] = {}
    for record in model["storyline_hosting_ledger"]:
        source_ids = set(record["source_ids"])
        demand_ids = source_ids & set(demands_by_id)
        storyline_requirement_ids = (
            source_ids & set(storyline_environment_requirements_by_id)
        )
        if len(demand_ids) != 1 or len(storyline_requirement_ids) != 1:
            _fail("E1_HOSTING_COVERAGE_MISMATCH", record["id"])
        demand_id = next(iter(demand_ids))
        storyline_requirement_id = next(iter(storyline_requirement_ids))
        if source_ids != {demand_id, storyline_requirement_id}:
            _fail("E1_HOSTING_COVERAGE_MISMATCH", record["id"])
        if (
            demand_id in hosting_by_demand
            or storyline_requirement_id in hosting_by_storyline_requirement
        ):
            _fail("E1_HOSTING_COVERAGE_MISMATCH", demand_id)
        if (
            demand_line[demand_id]
            != storyline_environment_requirement_line[storyline_requirement_id]
        ):
            _fail("E1_HOSTING_LINE_MISMATCH", record["id"])
        if not set(record["realization_ids"]).issubset(environments):
            _fail("E1_HOSTING_ENVIRONMENT_DANGLING", record["id"])
        marker = demands_by_id[demand_id]["responsibility"]
        storyline_marker = storyline_environment_requirements_by_id[
            storyline_requirement_id
        ]["responsibility"]
        hosted_text = rt.canonical_json(
            [environments[item] for item in record["realization_ids"]]
        )
        if (
            marker not in hosted_text
            or marker not in record["evidence"]
            or storyline_marker not in hosted_text
            or storyline_marker not in record["evidence"]
        ):
            _fail("E1_SOURCE_MEANING_UNBOUND", demand_id)
        for environment_id in record["realization_ids"]:
            environment = environments[environment_id]
            required_stage_ids = {
                demand_line[demand_id],
                demand_id,
                storyline_requirement_id,
            }
            if not required_stage_ids.issubset(environment["storyline_stage_ids"]):
                _fail("E1_HOSTING_COVERAGE_MISMATCH", demand_id)
            demand = demands_by_id[demand_id]
            storyline_requirement = storyline_environment_requirements_by_id[
                storyline_requirement_id
            ]
            if not all(
                constraint in environment["access_rules"]
                for constraint in {
                    *demand["constraints"],
                    *storyline_requirement["constraints"],
                }
            ):
                _fail("E1_WORLD_RULE_CONFLICT", environment_id)
            relevant_assignments = [
                item
                for item in assignments.values()
                if item["subject_id"] == environment_id
            ]
            if not any(
                set(demand_support[demand_id]).issubset(item["evidence_ids"])
                for item in relevant_assignments
            ):
                _fail("E1_WORLD_RULE_CONFLICT", environment_id)
        hosting_by_demand[demand_id] = record
        hosting_by_storyline_requirement[storyline_requirement_id] = record
    if set(hosting_by_demand) != set(demands_by_id):
        _fail(
            "E1_HOSTING_COVERAGE_MISMATCH",
            "every W1 environment demand must be hosted exactly once",
        )
    if set(hosting_by_storyline_requirement) != set(
        storyline_environment_requirements_by_id
    ):
        _fail(
            "E1_HOSTING_COVERAGE_MISMATCH",
            "every S1 environment requirement must be hosted exactly once",
        )
    hosted_demands_by_environment: dict[str, set[str]] = {
        environment_id: set() for environment_id in environments
    }
    for demand_id, record in hosting_by_demand.items():
        for environment_id in record["realization_ids"]:
            hosted_demands_by_environment[environment_id].add(demand_id)
    hosted_lines_by_environment = {
        environment_id: {
            demand_line[demand_id] for demand_id in hosted_demand_ids
        }
        for environment_id, hosted_demand_ids in hosted_demands_by_environment.items()
    }

    world_rule_ids = {
        item["id"] for item in world["world_facts"] if item["kind"] == "rule"
    }
    world_system_ids = {item["id"] for item in world["systems"]}
    world_institution_ids = {item["id"] for item in world["institutions"]}
    for channel in channels.values():
        environment_endpoints = [
            item
            for item in (channel["from_id"], channel["to_id"])
            if item in environments
        ]
        zone_endpoints = [
            item
            for item in (channel["from_id"], channel["to_id"])
            if item in zones
        ]
        if (
            len(environment_endpoints) != 1
            or len(zone_endpoints) != 1
            or zones[zone_endpoints[0]]["environment_id"]
            != environment_endpoints[0]
        ):
            _fail("E1_CHANNEL_SEMANTICS_INCOMPLETE", channel["id"])
        environment_id = environment_endpoints[0]
        hosted_demand_ids = hosted_demands_by_environment[environment_id]
        if not hosted_demand_ids:
            _fail("E1_CHANNEL_SEMANTICS_INCOMPLETE", channel["id"])
        demand_tokens = _channel_tokens(channel, "DEMAND")
        support_tokens = _channel_tokens(channel, "SUPPORT")
        marker_tokens = _channel_tokens(channel, "MARKER_SHA256")
        action_tokens = _channel_tokens(channel, "ACTION_SHA256")
        expected_support_ids = {
            support_id
            for demand_id in hosted_demand_ids
            for support_id in demand_support[demand_id]
        }
        expected_marker_hashes = {
            rt.canonical_sha256(demands_by_id[demand_id]["responsibility"])
            for demand_id in hosted_demand_ids
        }
        expected_action_hashes = {
            rt.canonical_sha256(action)
            for action in environments[environment_id]["allowed_actions"]
        }
        if (
            demand_tokens != hosted_demand_ids
            or support_tokens != expected_support_ids
            or marker_tokens != expected_marker_hashes
            or not action_tokens
            or not action_tokens.issubset(expected_action_hashes)
            or not expected_support_ids & world_rule_ids
            or not expected_support_ids & world_system_ids
            or not expected_support_ids & world_institution_ids
        ):
            _fail("E1_CHANNEL_SEMANTICS_INCOMPLETE", channel["id"])

    affordances = {
        item["id"]: item for item in model["event_affordance_catalog"]
    }
    if len(affordances) != len(model["event_affordance_catalog"]):
        _fail("E1_ID_DUPLICATE", "affordance IDs repeat")
    observed_event_requirements: list[str] = []
    for affordance in affordances.values():
        environment = environments.get(affordance["environment_id"])
        if environment is None:
            _fail("E1_AFFORDANCE_ENVIRONMENT_DANGLING", affordance["id"])
        if not affordance["allowed_actions"]:
            _fail("E1_ACTION_INTERFACE_MISSING", affordance["id"])
        if not any(
            action in environment["allowed_actions"]
            for action in affordance["allowed_actions"]
        ):
            _fail("E1_ACTION_INTERFACE_MISSING", affordance["id"])
        for requirement_id in affordance["event_requirement_ids"]:
            if requirement_id not in event_requirements:
                _fail("E1_EVENT_REQUIREMENT_DANGLING", affordance["id"])
            if event_requirement_line[requirement_id] not in (
                hosted_lines_by_environment[environment["id"]]
            ):
                _fail("E1_AFFORDANCE_LINE_MISMATCH", affordance["id"])
            observed_event_requirements.append(requirement_id)
        demand_ids = set(environment["storyline_stage_ids"]) & set(demands_by_id)
        storyline_requirement_ids = set(
            environment["storyline_stage_ids"]
        ) & set(storyline_environment_requirements_by_id)
        required_constraints = {
            constraint
            for demand_id in demand_ids
            for constraint in demands_by_id[demand_id]["constraints"]
        } | {
            constraint
            for requirement_id in storyline_requirement_ids
            for constraint in storyline_environment_requirements_by_id[
                requirement_id
            ]["constraints"]
        }
        if not required_constraints.issubset(affordance["constraints"]):
            _fail("E1_WORLD_RULE_CONFLICT", affordance["id"])
    if (
        set(observed_event_requirements) != set(event_requirements)
        or len(observed_event_requirements)
        != len(set(observed_event_requirements))
    ):
        _fail(
            "E1_ACTION_INTERFACE_MISSING",
            "every S1 event requirement needs one affordance",
        )

    transitions = {
        item["id"]: item for item in model["transition_contracts"]
    }
    if len(transitions) != len(model["transition_contracts"]):
        _fail("E1_ID_DUPLICATE", "transition IDs repeat")
    for transition in transitions.values():
        environment = environments.get(transition["subject_id"])
        if environment is None:
            _fail("E1_TRANSITION_SUBJECT_DANGLING", transition["id"])
        if (
            transition["from_state"] not in environment["state_vocabulary"]
            or transition["to_state"] not in environment["state_vocabulary"]
        ):
            _fail("E1_TRANSITION_STATE_INVALID", transition["id"])
        if not set(transition["trigger_ids"]).issubset(affordances):
            _fail("E1_TRANSITION_TRIGGER_INVALID", transition["id"])
        if any(
            affordances[trigger_id]["environment_id"] != transition["subject_id"]
            for trigger_id in transition["trigger_ids"]
        ):
            _fail("E1_TRANSITION_ENVIRONMENT_MISMATCH", transition["id"])
        allowed = set(assignments) | set(world_entities)
        if not set(transition["allowed_by_ids"]).issubset(allowed):
            _fail("E1_WORLD_RULE_CONFLICT", transition["id"])
    for environment in environments.values():
        expected_transitions = {
            item["id"]
            for item in transitions.values()
            if item["subject_id"] == environment["id"]
        }
        if (
            set(environment["allowed_transitions"]) != expected_transitions
            or not expected_transitions
        ):
            _fail("E1_TRANSITION_COVERAGE_MISMATCH", environment["id"])

    locked = {
        item["id"]
        for item in baseline["control_registry"]
        if item["hardness"] == "author_locked"
    }
    author_open = {
        item["id"]
        for item in baseline["control_registry"]
        if item["hardness"] == "author_open"
    }
    owned_entities: dict[str, Mapping[str, Any]] = {
        **environments,
        **zones,
        **topology,
        **assignments,
        **channels,
        **hazards,
        **{
            item["id"]: item for item in model["storyline_hosting_ledger"]
        },
        **affordances,
        **transitions,
    }
    decisions = {item["id"]: item for item in model["design_decisions"]}
    if set(partition["author_locked"]) != locked:
        _fail("E1_AUTHORITY_PARTITION_MISMATCH", "author_locked differs from B0")
    if set(partition["author_open"]) != author_open:
        _fail("E1_AUTHORITY_PARTITION_MISMATCH", "author_open differs from B0")
    if set(partition["autonomous_owned"]) != set(owned_entities) | set(decisions):
        _fail("E1_AUTHORITY_PARTITION_MISMATCH", "E1 owned set is not exact")
    if set(partition["downstream_freedom"]) != set(event_requirements):
        _fail("E1_AUTHORITY_PARTITION_MISMATCH", "T1 handoff set is not exact")
    for decision in decisions.values():
        if (
            decision["owner"] != "E1"
            or decision["selection"] not in decision["options"]
            or not set(decision["projection_ids"]).issubset(owned_entities)
        ):
            _fail("E1_DECISION_INVALID", decision["id"])
    for claim in model["derivation_claims"]:
        if len(claim["projection_ids"]) == 1:
            projection = owned_entities.get(claim["projection_ids"][0])
            if projection is None or claim["value_sha256"] != rt.canonical_sha256(
                projection
            ):
                _fail("E1_DERIVATION_STALE", claim["id"])
    claimed = {
        item["projection_ids"][0]
        for item in model["derivation_claims"]
        if len(item["projection_ids"]) == 1
    }
    if not set(environments).issubset(claimed) or not set(affordances).issubset(
        claimed
    ):
        _fail(
            "E1_DERIVATION_INCOMPLETE",
            "each environment and action interface needs derivation evidence",
        )
    actual_open = {
        source_id
        for item in model["open_items"]
        for source_id in item["source_ids"]
    }
    if actual_open != author_open:
        _fail("E1_OPEN_ITEMS_MISMATCH", "author-open controls changed")
    if expected_gate is not None and model["input_gate"] != expected_gate:
        _fail("E1_GATE_REFERENCE_MISMATCH", "model gate is not stored gate")
    if expected_sources is not None and model["source_artifacts"] != list(
        expected_sources
    ):
        _fail(
            "E1_SOURCE_ARTIFACT_MISMATCH",
            "model does not bind exact B0/S1/W1 sources",
        )


def start_e1_session(
    workspace: str | Path,
    *,
    baseline_package: str | Path,
    storyline_package: str | Path,
    world_package: str | Path,
    input_gate: Any,
    runtime: Any | None = None,
) -> dict[str, Any]:
    root = Path(workspace).resolve()
    if root.exists():
        _fail("E1_SESSION_EXISTS", str(root))
    thread_id = os.environ.get("CODEX_THREAD_ID", "").strip()
    if not thread_id:
        _fail("E1_THREAD_REQUIRED", "CODEX_THREAD_ID is required")
    contract_runtime = runtime or rt.ContractRuntime()
    (
        b0_root,
        s1_root,
        w1_root,
        baseline,
        storyline,
        world,
        controls,
        b0_ref,
        s1_ref,
        w1_ref,
    ) = _session_context(
        baseline_package=baseline_package,
        storyline_package=storyline_package,
        world_package=world_package,
        input_gate=input_gate,
        runtime=contract_runtime,
    )
    session = {
        "schema_version": "2.0",
        "run_id": baseline["run_id"],
        "stage": "E1",
        "session_id": _session_id(
            thread_id, input_gate.reference, b0_ref, s1_ref, w1_ref
        ),
        "thread_id": thread_id,
        "input_gate": copy.deepcopy(input_gate.reference),
        "state_before": copy.deepcopy(input_gate.data["run_state"]),
        "baseline_completion": b0_ref,
        "upstream_completions": [s1_ref, w1_ref],
        "source_artifacts": _source_artifacts(b0_root, s1_root, w1_root),
        "control_bindings": _control_bindings(controls),
        "storyline_bindings": _object_bindings(
            storyline["storylines"], extra="type"
        ),
        "storyline_environment_requirement_bindings": _object_bindings(
            storyline["environment_requirements"], extra="target_stage"
        ),
        "event_requirement_bindings": _object_bindings(
            storyline["event_requirements"], extra="target_stage"
        ),
        "world_rule_bindings": _object_bindings(world["world_facts"], extra="kind"),
        "environment_demand_bindings": _object_bindings(
            world["environment_demands"], extra="target_stage"
        ),
        "phases": list(PHASES),
    }
    root.mkdir(parents=True)
    _write(root / "generation-session.json", session)
    return copy.deepcopy(session)


def _validated_session(
    workspace: Path,
    *,
    baseline_package: str | Path,
    storyline_package: str | Path,
    world_package: str | Path,
    input_gate: Any,
    runtime: Any,
    full_validation: bool = True,
) -> tuple[
    dict[str, Any],
    dict[str, Any],
    dict[str, Any],
    dict[str, Any],
    list[dict[str, Any]],
]:
    session = _read(workspace / "generation-session.json", "E1_SESSION_INVALID")
    (
        b0_root,
        s1_root,
        w1_root,
        baseline,
        storyline,
        world,
        controls,
        b0_ref,
        s1_ref,
        w1_ref,
    ) = _session_context(
        baseline_package=baseline_package,
        storyline_package=storyline_package,
        world_package=world_package,
        input_gate=input_gate,
        runtime=runtime,
        full_validation=full_validation,
    )
    thread_id = os.environ.get("CODEX_THREAD_ID", "").strip()
    expected = {
        "schema_version": "2.0",
        "run_id": baseline["run_id"],
        "stage": "E1",
        "session_id": _session_id(
            thread_id, input_gate.reference, b0_ref, s1_ref, w1_ref
        ),
        "thread_id": thread_id,
        "input_gate": copy.deepcopy(input_gate.reference),
        "state_before": copy.deepcopy(input_gate.data["run_state"]),
        "baseline_completion": b0_ref,
        "upstream_completions": [s1_ref, w1_ref],
        "source_artifacts": _source_artifacts(b0_root, s1_root, w1_root),
        "control_bindings": _control_bindings(controls),
        "storyline_bindings": _object_bindings(
            storyline["storylines"], extra="type"
        ),
        "storyline_environment_requirement_bindings": _object_bindings(
            storyline["environment_requirements"], extra="target_stage"
        ),
        "event_requirement_bindings": _object_bindings(
            storyline["event_requirements"], extra="target_stage"
        ),
        "world_rule_bindings": _object_bindings(world["world_facts"], extra="kind"),
        "environment_demand_bindings": _object_bindings(
            world["environment_demands"], extra="target_stage"
        ),
        "phases": list(PHASES),
    }
    if not thread_id or session != expected:
        _fail("E1_SESSION_INVALID", "session no longer binds B0/S1/W1/gate/thread")
    return session, baseline, storyline, world, controls


def submit_e1_phase(
    workspace: str | Path,
    *,
    baseline_package: str | Path,
    storyline_package: str | Path,
    world_package: str | Path,
    input_gate: Any,
    phase: str,
    payload: Mapping[str, Any],
    runtime: Any | None = None,
) -> dict[str, str]:
    root = Path(workspace).resolve()
    contract_runtime = runtime or rt.ContractRuntime()
    session, baseline, storyline, world, controls = _validated_session(
        root,
        baseline_package=baseline_package,
        storyline_package=storyline_package,
        world_package=world_package,
        input_gate=input_gate,
        runtime=contract_runtime,
        full_validation=False,
    )
    completed: list[str] = []
    for index, item in enumerate(PHASES, 1):
        if (
            root / "generation-evidence" / f"{index:02d}-{item}.json"
        ).is_file():
            completed.append(item)
        else:
            break
    if len(completed) >= len(PHASES):
        _fail("E1_PHASE_ORDER_INVALID", "all phases already sealed")
    if phase not in PHASES or phase != PHASES[len(completed)]:
        _fail("E1_PHASE_ORDER_INVALID", f"next phase is {PHASES[len(completed)]}")
    body = copy.deepcopy(dict(payload))
    if set(body) != set(PHASE_FIELDS[phase]):
        _fail(
            "E1_PHASE_PAYLOAD_INVALID",
            f"{phase} must contain exactly {list(PHASE_FIELDS[phase])}",
        )
    if phase == "final-environment-model":
        model = body.get("model")
        if not isinstance(model, Mapping):
            _fail("E1_PHASE_PAYLOAD_INVALID", "final model missing")
        _validate_model(
            model,
            baseline,
            storyline,
            world,
            controls,
            contract_runtime,
            expected_gate=input_gate.reference,
            expected_sources=session["source_artifacts"],
        )
    previous = None
    if completed:
        previous = rt.sha256_file(
            root
            / "generation-evidence"
            / f"{len(completed):02d}-{completed[-1]}.json"
        )
    evidence = {
        "schema_version": "2.0",
        **{
            key: copy.deepcopy(session[key])
            for key in (
                "run_id",
                "session_id",
                "thread_id",
                "input_gate",
                "state_before",
                "baseline_completion",
                "upstream_completions",
                "source_artifacts",
                "control_bindings",
                "storyline_bindings",
                "storyline_environment_requirement_bindings",
                "event_requirement_bindings",
                "world_rule_bindings",
                "environment_demand_bindings",
            )
        },
        "stage": "E1",
        "phase": phase,
        "sequence": len(completed) + 1,
        "previous_evidence_sha256": previous,
        "payload": body,
        "payload_sha256": rt.canonical_sha256(body),
    }
    path = (
        root
        / "generation-evidence"
        / f"{len(completed)+1:02d}-{phase}.json"
    )
    _write(path, evidence)
    return rt.artifact_reference(path, root=root)


def _validate_phase_chain(
    evidence_root: Path,
    *,
    session: Mapping[str, Any],
    model: Mapping[str, Any],
) -> list[Path]:
    paths: list[Path] = []
    previous = None
    shared = (
        "run_id",
        "session_id",
        "thread_id",
        "input_gate",
        "state_before",
        "baseline_completion",
        "upstream_completions",
        "source_artifacts",
        "control_bindings",
        "storyline_bindings",
        "storyline_environment_requirement_bindings",
        "event_requirement_bindings",
        "world_rule_bindings",
        "environment_demand_bindings",
    )
    for index, phase in enumerate(PHASES, 1):
        path = evidence_root / f"{index:02d}-{phase}.json"
        evidence = _read(path, "E1_EVIDENCE_MISSING")
        payload = evidence.get("payload")
        if not isinstance(payload, Mapping):
            _fail("E1_EVIDENCE_INVALID", phase)
        expected = {
            "schema_version": "2.0",
            **{key: copy.deepcopy(session[key]) for key in shared},
            "stage": "E1",
            "phase": phase,
            "sequence": index,
            "previous_evidence_sha256": previous,
            "payload": dict(payload),
            "payload_sha256": rt.canonical_sha256(payload),
        }
        if evidence != expected or set(payload) != set(PHASE_FIELDS[phase]):
            _fail("E1_EVIDENCE_INVALID", phase)
        if phase == "final-environment-model":
            if payload["model"] != model:
                _fail("E1_EVIDENCE_MODEL_MISMATCH", phase)
        else:
            for field in PHASE_FIELDS[phase]:
                if payload[field] != model[field]:
                    _fail("E1_EVIDENCE_MODEL_MISMATCH", f"{phase}.{field}")
        previous = rt.sha256_file(path)
        paths.append(path)
    return paths


def _validation(run_id: str) -> dict[str, Any]:
    return {
        "schema_version": "2.0",
        "run_id": run_id,
        "stage": "E1",
        "verdict": "ready",
        "checks": [
            "schema",
            "B0/S1/W1/gate-lineage",
            "environment-demand-exact-projection",
            "hosting-exact-cover",
            "zone-and-topology-closure",
            "access-resource-information-closure",
            "affordance-and-transition-closure",
            "world-rule-consistency",
            "downstream-boundary",
            "completion-binding",
        ],
        "errors": [],
    }


def _check_package_boundary(root: Path) -> None:
    allowed_evidence = {
        f"generation-evidence/{index:02d}-{phase}.json"
        for index, phase in enumerate(PHASES, 1)
    }
    allowed_implementation = {
        f"implementation/{identity}"
        for identity in _implementation_paths()
    }
    for path in root.rglob("*"):
        if not path.is_file():
            continue
        relative = path.relative_to(root).as_posix()
        if relative in _ALLOWED_ROOT_FILES:
            continue
        if relative in allowed_evidence or relative in allowed_implementation:
            continue
        if any(relative.startswith(prefix) for prefix in _ALLOWED_SOURCE_PREFIXES):
            continue
        _fail("E1_BOUNDARY_VIOLATION", relative)


def validate_e1_package(
    package_root: str | Path,
    *,
    runtime: Any | None = None,
    require_completion: bool = True,
) -> dict[str, Any]:
    root = Path(package_root).resolve()
    contract_runtime = runtime or rt.ContractRuntime()
    _check_package_boundary(root)
    model = _read(root / "environment-system.json", "E1_MODEL_MISSING")
    manifest = _read(root / "package-manifest.json", "E1_MANIFEST_INVALID")
    stored = _read(root / "validation.json", "E1_VALIDATION_MISSING")
    try:
        contract_runtime.validate(manifest, "package-manifest.schema.json")
        rt.verify_manifest_integrity(manifest, root=root)
    except Exception as error:
        _fail("E1_MANIFEST_INVALID", str(error))
    b0 = root / "sources" / "B0"
    s1 = root / "sources" / "S1"
    w1 = root / "sources" / "W1"
    try:
        rt.validate_baseline_package(b0, runtime=contract_runtime)
        s1_runtime.validate_s1_package(s1, runtime=contract_runtime)
        w1_runtime.validate_w1_package(w1, runtime=contract_runtime)
    except Exception as error:
        _fail("E1_UPSTREAM_INVALID", str(error))
    baseline = _read(b0 / "author-control-baseline.json", "E1_B0_INVALID")
    storyline = _read(s1 / "storyline-architecture.json", "E1_S1_INVALID")
    world = _read(w1 / "world-model.json", "E1_W1_INVALID")
    controls = _controls(b0, baseline)
    gate = _read(root / "input-gate.json", "E1_GATE_MISSING")
    try:
        contract_runtime.validate(gate, "input-gate.schema.json")
    except Exception as error:
        _fail("E1_GATE_INVALID", str(error))
    gate_ref = {
        "path": model["input_gate"]["path"],
        "sha256": rt.sha256_file(root / "input-gate.json"),
    }
    if not gate_ref["path"].endswith("/input-gate.json"):
        _fail("E1_GATE_REFERENCE_MISMATCH", "gate path not package-qualified")
    b0_ref = _stage_reference(b0, "B0")
    s1_ref = _stage_reference(s1, "S1")
    w1_ref = _stage_reference(w1, "W1")
    if (
        gate.get("target_stage") != "E1"
        or gate.get("run_id") != model["run_id"]
        or gate.get("baseline_completion") != b0_ref
        or gate.get("upstream_completions") != [s1_ref, w1_ref]
    ):
        _fail("E1_GATE_INVALID", "stored E1 topology is invalid")
    expected_sources = _source_artifacts(b0, s1, w1)
    _validate_model(
        model,
        baseline,
        storyline,
        world,
        controls,
        contract_runtime,
        expected_gate=gate_ref,
        expected_sources=expected_sources,
    )
    if manifest["artifact_roles"]["canonical"] != rt.artifact_reference(
        root / "environment-system.json", root=root
    ):
        _fail("E1_MANIFEST_INVALID", "canonical role is stale")
    execution = _read(root / "execution-record.json", "E1_EXECUTION_INVALID")
    if (
        execution.get("input_gate") != gate_ref
        or execution.get("baseline_completion") != b0_ref
        or execution.get("upstream_completions") != [s1_ref, w1_ref]
        or execution.get("output_sha256") != rt.canonical_sha256(model)
    ):
        _fail("E1_EXECUTION_INVALID", "execution lineage is stale")
    session = _read(root / "generation-session.json", "E1_SESSION_INVALID")
    thread = session.get("thread_id")
    if not isinstance(thread, str) or not thread.strip():
        _fail("E1_SESSION_INVALID", "thread is missing")
    expected_session = {
        "schema_version": "2.0",
        "run_id": model["run_id"],
        "stage": "E1",
        "session_id": _session_id(thread, gate_ref, b0_ref, s1_ref, w1_ref),
        "thread_id": thread,
        "input_gate": gate_ref,
        "state_before": gate.get("run_state"),
        "baseline_completion": b0_ref,
        "upstream_completions": [s1_ref, w1_ref],
        "source_artifacts": expected_sources,
        "control_bindings": _control_bindings(controls),
        "storyline_bindings": _object_bindings(
            storyline["storylines"], extra="type"
        ),
        "storyline_environment_requirement_bindings": _object_bindings(
            storyline["environment_requirements"], extra="target_stage"
        ),
        "event_requirement_bindings": _object_bindings(
            storyline["event_requirements"], extra="target_stage"
        ),
        "world_rule_bindings": _object_bindings(world["world_facts"], extra="kind"),
        "environment_demand_bindings": _object_bindings(
            world["environment_demands"], extra="target_stage"
        ),
        "phases": list(PHASES),
    }
    if session != expected_session:
        _fail("E1_SESSION_INVALID", "session differs from current inputs")
    if execution.get("session_id") != session["session_id"]:
        _fail("E1_SESSION_INVALID", "execution session differs")
    evidence_paths = _validate_phase_chain(
        root / "generation-evidence", session=session, model=model
    )
    evidence_index = _read(
        root / "generation-evidence-index.json", "E1_EVIDENCE_INVALID"
    )
    if evidence_index != {
        "schema_version": "2.0",
        "run_id": model["run_id"],
        "stage": "E1",
        "session_id": session["session_id"],
        "phases": list(PHASES),
        "evidence": [
            rt.artifact_reference(path, root=root) for path in evidence_paths
        ],
    }:
        _fail("E1_EVIDENCE_INVALID", "evidence index is stale")
    catalog = {
        item["identity"]: item["artifact"]
        for item in execution.get("implementation_catalog", [])
    }
    expected_implementation_refs = {
        rt.canonical_json(
            rt.artifact_reference(
                root / "implementation" / identity,
                root=root,
            )
        )
        for identity in _implementation_paths()
    }
    if (
        set(catalog) != set(_implementation_paths())
        or {
            rt.canonical_json(item)
            for item in execution.get("implementation", [])
        }
        != expected_implementation_refs
        or {
            rt.canonical_json(item) for item in manifest.get("implementation", [])
        }
        != expected_implementation_refs
        or {
            rt.canonical_json(item) for item in catalog.values()
        }
        != expected_implementation_refs
    ):
        _fail(
            "E1_IMPLEMENTATION_STALE",
            "implementation files, catalog, execution, and manifest differ",
        )
    for identity, current in _implementation_paths().items():
        reference = catalog.get(identity)
        if reference is None:
            _fail("E1_IMPLEMENTATION_STALE", identity)
        try:
            rt.verify_artifact_reference(reference, root=root)
        except Exception as error:
            _fail("E1_IMPLEMENTATION_STALE", str(error))
        if reference["sha256"] != rt.sha256_file(current):
            _fail("E1_IMPLEMENTATION_STALE", identity)
    if require_completion:
        completion = _read(
            root / "stage-completion.json", "E1_COMPLETION_MISSING"
        )
        try:
            contract_runtime.validate(completion, "stage-completion.schema.json")
        except Exception as error:
            _fail("E1_COMPLETION_INVALID", str(error))
        manifest_ref = completion.get("manifest")
        manifest_path = (
            manifest_ref.get("path") if isinstance(manifest_ref, Mapping) else ""
        )
        prefix = PurePosixPath(manifest_path).parent.as_posix()
        if (
            not (prefix == "E1" or prefix.startswith("E1/"))
            or completion.get("run_id") != model["run_id"]
            or completion.get("stage") != "E1"
            or completion.get("status") != "ready"
            or completion.get("session_id") != session["session_id"]
            or completion.get("manifest")
            != {
                "path": _logical(prefix, "package-manifest.json"),
                "sha256": rt.sha256_file(root / "package-manifest.json"),
            }
            or completion.get("validation")
            != {
                "path": _logical(prefix, "validation.json"),
                "sha256": rt.sha256_file(root / "validation.json"),
            }
            or completion.get("input_gate") != gate_ref
            or completion.get("state_before") != gate.get("run_state")
            or completion.get("previous_stage_completions") != [s1_ref, w1_ref]
            or completion.get("return_binding") != gate.get("return_binding")
        ):
            _fail("E1_COMPLETION_BINDING_MISMATCH", "completion lineage is stale")
    expected_validation = _validation(model["run_id"])
    if stored != expected_validation:
        _fail("E1_VALIDATION_STALE", "stored validation differs")
    return expected_validation


def run_e1(
    package_root: str | Path,
    *,
    baseline_package: str | Path,
    storyline_package: str | Path,
    world_package: str | Path,
    coordinator: Any,
    input_gate: Any,
    controlled_workspace: str | Path,
    logical_package_path: str = "E1",
    next_state_path: str,
    active_return_request: Any | None = None,
    runtime: Any | None = None,
) -> E1RunReceipt:
    destination = Path(package_root).resolve()
    if destination.exists():
        _fail("E1_OUTPUT_EXISTS", str(destination))
    if not os.environ.get("CODEX_THREAD_ID", "").strip():
        _fail("E1_THREAD_REQUIRED", "CODEX_THREAD_ID is required")
    contract_runtime = runtime or rt.ContractRuntime()
    workspace = Path(controlled_workspace).resolve()
    session, baseline, storyline, world, controls = _validated_session(
        workspace,
        baseline_package=baseline_package,
        storyline_package=storyline_package,
        world_package=world_package,
        input_gate=input_gate,
        runtime=contract_runtime,
    )
    final = _read(
        workspace
        / "generation-evidence"
        / f"{len(PHASES):02d}-{PHASES[-1]}.json",
        "E1_EVIDENCE_MISSING",
    )
    payload = final.get("payload")
    if not isinstance(payload, Mapping) or not isinstance(
        payload.get("model"), Mapping
    ):
        _fail("E1_EVIDENCE_INVALID", "final model missing")
    model = copy.deepcopy(dict(payload["model"]))
    _validate_phase_chain(
        workspace / "generation-evidence", session=session, model=model
    )
    _validate_model(
        model,
        baseline,
        storyline,
        world,
        controls,
        contract_runtime,
        expected_gate=input_gate.reference,
        expected_sources=session["source_artifacts"],
    )

    destination.parent.mkdir(parents=True, exist_ok=True)
    temp_parent = Path(
        tempfile.mkdtemp(prefix=f".{destination.name}.", dir=destination.parent)
    )
    staging = temp_parent / "package"
    staging.mkdir()
    try:
        for stage, source in (
            ("B0", Path(baseline_package).resolve()),
            ("S1", Path(storyline_package).resolve()),
            ("W1", Path(world_package).resolve()),
        ):
            shutil.copytree(source, staging / "sources" / stage)
        _write(staging / "input-gate.json", input_gate.data)
        if _source_artifacts(
            staging / "sources" / "B0",
            staging / "sources" / "S1",
            staging / "sources" / "W1",
        ) != session["source_artifacts"]:
            _fail("E1_SOURCE_ARTIFACT_MISMATCH", "staged inputs changed")
        _write(staging / "environment-system.json", model)
        evidence_refs = []
        for index, phase in enumerate(PHASES, 1):
            source = (
                workspace / "generation-evidence" / f"{index:02d}-{phase}.json"
            )
            target = staging / "generation-evidence" / source.name
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(source, target)
            evidence_refs.append(rt.artifact_reference(target, root=staging))
        _write(
            staging / "generation-evidence-index.json",
            {
                "schema_version": "2.0",
                "run_id": baseline["run_id"],
                "stage": "E1",
                "session_id": session["session_id"],
                "phases": list(PHASES),
                "evidence": evidence_refs,
            },
        )
        _write(staging / "generation-session.json", session)
        implementation_refs = []
        implementation_catalog = []
        for identity, source in sorted(_implementation_paths().items()):
            target = staging / "implementation" / identity
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(source, target)
            reference = rt.artifact_reference(target, root=staging)
            implementation_refs.append(reference)
            implementation_catalog.append(
                {"identity": identity, "artifact": reference}
            )
        execution = {
            "schema_version": "2.0",
            "run_id": baseline["run_id"],
            "stage": "E1",
            "operation": "controlled-environment-system-generation",
            "session_id": session["session_id"],
            "input_gate": copy.deepcopy(input_gate.reference),
            "baseline_completion": session["baseline_completion"],
            "upstream_completions": session["upstream_completions"],
            "implementation": implementation_refs,
            "implementation_catalog": implementation_catalog,
            "output_sha256": rt.canonical_sha256(model),
        }
        _write(staging / "execution-record.json", execution)
        (staging / "environment-preview.md").write_text(
            "# Environment system\n\n"
            + "\n".join(
                f"- **{item['id']}**: {item['narrative_responsibility']}"
                for item in model["environments"]
            )
            + "\n",
            encoding="utf-8",
            newline="",
        )
        validation = _validation(baseline["run_id"])
        _write(staging / "validation.json", validation)
        files = [
            rt.artifact_reference(path, root=staging)
            for path in sorted(staging.rglob("*"), key=lambda item: item.as_posix())
            if path.is_file()
        ]
        by_path = {item["path"]: item for item in files}
        manifest = {
            "schema_version": "2.0",
            "run_id": baseline["run_id"],
            "stage": "E1",
            "package_profile": "generated-model",
            "verdict": "ready",
            "files": files,
            "artifact_roles": {
                "canonical": by_path["environment-system.json"],
                "generation_session": by_path["generation-session.json"],
                "generation_evidence_index": by_path[
                    "generation-evidence-index.json"
                ],
                "execution_record": by_path["execution-record.json"],
                "preview": by_path["environment-preview.md"],
            },
            "validation": by_path["validation.json"],
            "implementation": implementation_refs,
        }
        contract_runtime.validate(manifest, "package-manifest.schema.json")
        rt.verify_manifest_integrity(manifest, root=staging)
        _write(staging / "package-manifest.json", manifest)
        validate_e1_package(
            staging, runtime=contract_runtime, require_completion=False
        )
        completion_data = {
            "schema_version": "2.0",
            "run_id": baseline["run_id"],
            "stage": "E1",
            "status": "ready",
            "session_id": session["session_id"],
            "manifest": {
                "path": _logical(logical_package_path, "package-manifest.json"),
                "sha256": rt.sha256_file(staging / "package-manifest.json"),
            },
            "validation": {
                "path": _logical(logical_package_path, "validation.json"),
                "sha256": rt.sha256_file(staging / "validation.json"),
            },
            "input_gate": copy.deepcopy(input_gate.reference),
            "state_before": copy.deepcopy(input_gate.data["run_state"]),
            "previous_stage_completions": copy.deepcopy(
                input_gate.data["upstream_completions"]
            ),
            "return_binding": copy.deepcopy(input_gate.data["return_binding"]),
        }
        contract_runtime.validate(
            completion_data, "stage-completion.schema.json"
        )
        sealed = rt.seal_stage_document(
            completion_data,
            "E1",
            _logical(logical_package_path, "stage-completion.json"),
        )
        _write(staging / "stage-completion.json", sealed.data)
        validate_e1_package(staging, runtime=contract_runtime)
        transition = coordinator.accept_stage_completion(
            gate=input_gate,
            completion=sealed,
            next_state_path=next_state_path,
            active_return_request=active_return_request,
        )
        staging.replace(destination)
    except Exception:
        shutil.rmtree(temp_parent, ignore_errors=True)
        raise
    shutil.rmtree(temp_parent, ignore_errors=True)
    return E1RunReceipt(
        package_root=destination,
        model=copy.deepcopy(model),
        manifest=copy.deepcopy(manifest),
        completion=sealed,
        transition=transition,
    )


__all__ = [
    "PHASES",
    "PHASE_FIELDS",
    "E1Error",
    "E1RunReceipt",
    "run_e1",
    "start_e1_session",
    "submit_e1_phase",
    "validate_e1_package",
]
