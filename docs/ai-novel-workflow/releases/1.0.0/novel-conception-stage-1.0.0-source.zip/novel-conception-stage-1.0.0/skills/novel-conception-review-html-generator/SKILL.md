---
name: novel-conception-review-html-generator
description: 将正式 H1 人审内容模型确定性渲染为离线、安全、可访问、可打印且面向作者或编辑的小说构思 HTML 报告。用于呈现世界设定、故事线设计、角色定义和样章；不用于修改构思、重写片段、公开机器审计证据或记录作者决定。
---

# 小说构思人审 HTML 生成

## 目标

把 H1-A 组装的内容呈现成一份像编辑提案、而不是系统审计日志的离线 HTML。读者应先理解小说，再作判断；不需要理解 Agent、阶段、来源绑定或迁移过程。

## 输入

一次运行必须接收同一 run/session 的正式 P1、H1-A plan、H1-B fragments、H1-A assembly、assembled workspace 和 coordinator。先调用正式 `validate_assembly_package()`，任何 lineage、状态或 TOCTOU 失败都必须停止。

## 固定页面结构

1. 封面：作品名、一句话故事、阅读承诺。
2. 世界：时代与现实背景、国家／组织关系、核心活动、运行规则、逐项具体环境和边界。
3. 故事：故事主体、多线关系、关键事件、悬念冲突与结局边界。
4. 人物：逐人呈现故事位置、活动参与和个体画像，再呈现关系变化和职责覆盖。
5. 样章：只呈现标题与小说正文。
6. 结论：用自然语言提示批准、修改或否决；不在页面内记录决定。

导航只显示前四个内容维度。结论区是末尾操作，不作为第五维导航项。

## 人类语言与信息层级

- 首屏必须先讲故事，禁止先展示评审路径、预算算法或范围契约。
- 标题使用模块的人类标题，禁止使用 `MOD-*`、`VIS-*` 等内部 ID。
- 卡片只呈现人类标题与结论；关键边界在板块末尾集中呈现，模块级职责和审计约束不逐卡展开。
- 图形只显示读者需要的节点、关系和一段自然语言图注。
- 每个主要环境以独立卡片呈现：默认显示可单独判断的环境概要，原位展开后显示完整
  空间、物件、权限和风险；展开内容属于人类报告，不得出现机器证据。
- 每个角色以独立卡片呈现：默认显示一句故事定位，原位展开后按故事位置、参与活动、外貌、性格、背景、日常、社交圈和具身/接口边界分组显示完整定义；不得用关系图或角色群摘要代替。
- 样章不得显示 `review_purpose`、control binding 或来源。
- 页脚只说明证据由工作流保存，不显示 run、session、路径或哈希。

## 不得公开

以下内容必须留在 JSON、manifest、validation 或执行记录中，不能进入人类可见正文：

- 来源 ID、source coverage、reduction ledger、drilldown index
- SHA256、JSON Pointer、input gate、workspace 状态
- Decision controls、presentation bindings、图形逐值信息
- 迁移评审、兼容性评审或 Agent 推理过程
- 英文审计术语及 `controls=`、`run=` 等运行标记

`validate_html_document()` 必须 fail-closed 检查以上泄漏。

## 图形与可访问性

- 使用内联 SVG；不得加载外部资源。
- 主要事件时间线必须按共同时间阶段对齐节点，以泳道区分并行故事线；用图例与节点文字同时标明埋点、探针、转折、高潮、回收等叙事功能，不能只靠颜色表达。
- 保留每个图的语义角色、标题、描述和自然语言图注。
- 保留 skip link、键盘焦点、响应式布局、打印布局和 reduced-motion 支持。
- 禁止脚本、表单、外链、下载、URL-bearing 属性和远程字体。

## 执行

使用 [scripts/run_v2.py](scripts/run_v2.py)：

- `run(...)` 生成正式 H1-C package 并申请 `assembled -> rendered`。
- `render_html(report)` 只做确定性投影，不推断新小说事实。
- `validate_html_document(document, report)` 检查内容、可访问性和安全性。
- `validate_html_package(...)` 验证完整 package、manifest、快照和 lineage。

## 边界

- 不修改 P1、plan、fragments 或 assembly。
- 不编写或润色样章。
- 不新增、删改或裁决构思事实。
- 不生成 H1 completion，不替作者批准构思。

## 验收

- 唯一 `<title>` 与 `<h1>` 等于报告标题。
- 页面只有四个内容入口，末尾另有结论操作区。
- 五个 SVG 与其自然语言图注完整绑定。
- 人类正文不含机器审计信息。
- HTML 离线、安全、可访问、响应式、可打印且字节确定。
- 正式 H1-C validator 返回 ready 后才可交付。
