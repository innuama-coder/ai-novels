# S1 V2 runtime contract

`scripts/run_v2.py` is the sole production runtime for S1. Python controls
lineage, order, validation, sealing, and publication; the Agent authors every
semantic design field. The runtime must not synthesize storylines or silently
repair an Agent submission.

## Controlled generation protocol

1. Call `start_s1_session()` with the current B0 package and coordinator-issued
   S1 gate. It requires `CODEX_THREAD_ID` and freezes the exact gate, B0
   completion, run state, B0 source hashes, and each control's ID, domain,
   heading, and value hash.
2. Let the Agent read the frozen inputs and call `submit_s1_phase()` exactly
   once, in order, for `demand-scan`, `line-design`,
   `topology-and-consistency`, `downstream-requirements`, and
   `final-storyline-model`.
3. Each phase accepts only its declared fields. Its evidence binds the session,
   thread, gate, pre-stage state, B0 completion, complete control bindings,
   previous evidence hash, and payload hash.
4. Call `run_s1()` with that controlled workspace. It reads the final model from
   the fifth evidence record, verifies that all earlier payloads equal the
   corresponding final-model projections, validates the package, seals the
   completion, asks the coordinator to accept it, and only then publishes it.

A one-shot candidate model is not a production input. Evidence may not be
backfilled after generating a model. Changing a source control value requires a
new frozen session and new Agent-authored phase payloads.

## Ready guarantees

- every B0 control has exactly one demand, and the demand carries its exact
  heading and value;
- every demand is realized exactly once and exactly one main line exists;
- every non-optional structural line reaches the main line through a directed
  path containing only structural lines and `causal` connections; a structural
  line may converge through another structural line and need not connect
  directly to the main line;
- every `optional_melody` has at least one `associative` attachment to a
  structural line, has no causal cross-line connection, and is excluded from
  structural causal closure; this also prevents author-open optional material
  from becoming a required causal predecessor;
- every connection declares `relation=causal|associative`; its state text and
  zero-based state index identify the same state on the declared owner line,
  and both endpoint lines list the connection exactly once;
- `temporal_architecture` provides one shared time spine for the complete
  multi-line design. Phases are strictly ordered, milestones cannot regress in
  phase or in any line's state index, every structural line reaches both its
  declared start and end, and every cross-line connection is realized by
  exactly one milestone binding both endpoint states;
- every milestone carries at least one narrative marker. The marker vocabulary
  is fixed to `opening`, `setup`, `probe`, `turning_point`, `reveal`, `climax`,
  `payoff`, and `aftermath`. A ready package contains at least one setup,
  probe, turning point, climax, and payoff; probes expose a concrete reader
  question and observable signal, payoffs refer back to an earlier setup, and
  a climax converges at least two structural lines;
- `architecture.line_order` contains every line exactly once and is
  topological for causal connections only; associations impose no causal or
  temporal order;
- cross-line consistency contains exactly one structured record for each of
  `time`, `causality`, `information`, `authority`, `state`, and `theme`;
  every record witnesses every storyline and carries a concrete claim plus a
  distinct failure condition;
- witness IDs are checked against dimension-specific object sets. Causality
  accepts only storyline IDs and connections whose declared relation is
  `causal`; an associative connection can never be used as causal evidence.
  Unknown witnesses, incomplete line coverage, duplicate/missing dimensions,
  and placeholder claims or failure conditions fail closed;
- the relevant source value participates in its line and in each W1/E1/T1/C1
  requirement;
- every downstream requirement set covers every line and its assigned demands
  exactly once, targets the correct stage, and equals the downstream authority
  partition;
- the local authority partition is pairwise-disjoint and exact:
  `author_locked`/`author_open` equal B0, `autonomous_owned` equals S1
  decisions plus storylines, and `downstream_freedom` equals the union of all
  W1/E1/T1/C1 requirement IDs;
- author-open controls remain open; derivation hashes are current;
- model, session, evidence chain, execution record, implementation snapshots,
  manifest, validation, stage completion, and coordinator transition bind the
  same run, gate, B0 completion, and pre-stage state.

`validate_s1_package()` is read-only. It rereads and schema-validates the copied
B0 package, stored gate, model, manifest, and stage completion; recomputes
semantic set equalities, topology, source-value participation, hashes, session
identity, evidence chain, implementation freshness, and completion lineage.
Deleting or resealing declarations cannot replace these checks. A package
without a valid `stage-completion.json` is not ready.

## Boundary

S1 defines storyline obligations, lines, causal topology, non-causal
associations, state transitions, the shared multi-line temporal spine,
narrative markers, and downstream requirements. An association is coverage and
resonance, never a causal predecessor. S1 milestones are abstract story beats:
they say what develops and changes, not where a scene occurs or how it is
dramatized. S1 does not define world rules, concrete environments, event
records, character profiles, chapters, scenes, or POV schedules.
Downstream requirements state obligations and acceptance checks, not downstream
answers. Published output paths are immutable.
