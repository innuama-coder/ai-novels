---
name: novel-storyline-architecture-designer
description: 将已批准的小说访谈控制基线设计为完整的多线故事架构，先建立统一时间主轴，再定义各故事线的职责、状态推进、连接点、关键转折、高潮、埋点、探针与回收，以及交给世界、环境、事件和角色阶段的硬需求。用于自主构思 V2 的 S1 阶段；不定义具体世界系统、环境、事件或人物档案。
---

# 小说故事线架构设计

## 目标

让不同角度、方向和时间层的故事线共同还原同一个故事主体，并为后续四个设计阶段提供可验收的需求接口。

先建立全书共享的时间阶段，再把所有故事线的重要状态变化放进跨线里程碑。每个里程碑必须说明故事怎样发展、改变了什么，并标注其叙事功能。探针必须说明它在试探什么以及读者能观察到什么；回收必须指回较早的埋点；高潮必须由至少两条结构线汇合形成。

## 权威契约

完整读取：

- [自主构思工作流](../../docs/ai-novel-workflow/conception-autonomous-workflow-v2.md)的第 3、4、14、15 节；
- [S1 Schema](../../docs/ai-novel-workflow/contracts/autonomous-v2/storyline-architecture.schema.json)；
- [公共 canonical Schema](../../docs/ai-novel-workflow/contracts/autonomous-v2/canonical-common.schema.json)；
- [S1 唯一运行契约](references/runtime-contract.md)。

## 唯一生产运行路径

只允许使用 `scripts/run_v2.py`。在同一 `CODEX_THREAD_ID` 中依次调用
`start_s1_session()`、按契约顺序调用 `submit_s1_phase()`、最后调用
`run_s1()`。不得跳过受控会话、倒填阶段证据、传入会话外的一次性完整候选稿，
也不得手写 validation、manifest 或 completion。`validate_s1_package()` 只用于
只读复验，不能替代上述生产调用。

## 输入硬准入

只接受同一 run 的当前 B0 completion、B0 manifest、`author-control-baseline.json`、
S1 `input-gate.json` 和执行前 autonomous run-state。输入门必须为合法 `forward`，
或绑定唯一 active return 且 `resume_stage=S1` 的 `return_resolution`。

任一输入缺失、哈希失配、基线未覆盖 I0–I5、存在未处置结构性事实或 return 不匹配时停止；
不得生成候选模型。

## 职责

1. 将作者控制点转化为故事线需求，不遗漏因果义务。
2. 定义前置线、主体线、支持线、背景线及可选旋律线的独立职责。
3. 定义每条线的行动者槽、目标、压力、起始状态、状态变化和终态。
4. 定义汇流、分叉、交接、碰撞、揭示与同步连接点，并明确每个连接是
   `causal`（承担因果闭包）还是 `associative`（只表达呼应、并置或余韵）。
5. 以六条结构化记录分别检查跨线时间、因果、信息、权限、状态和主题一致性；
   每条记录必须列出证据对象、可证伪主张和失败条件，并覆盖全部故事线。
6. 分别生成 W1、E1、T1、C1 的语义化需求对象；每项包含来源、责任、所需能力、
   约束、验收条件和下游自由。

## 边界

- 时间推进属于 S1，但只到抽象故事节拍，不展开为场景或章节。
- 世界、环境、事件和角色均须从故事线及其时间架构取得设计需求；后续阶段可以具体化实现方式，但不得改变已定义的先后、状态变化、跨线连接或标记功能。
- 不定义具体地点、摆设、事件执行记录、人物档案、视角排期或成品叙事文本。

- 不创建具体世界规则、环境、事件或人物档案。
- 不以固定故事线数量或固定叙事模板替代完整性判断。
- 每条非可选结构线必须仅沿结构线和 `causal` 连接抵达主体线；允许多跳汇入，
  不要求直接连接主体线。
- 可选旋律线至少关联一条结构线，但其跨线连接必须全部为 `associative`；
  它不能弥补主体因果缺口，删除后主体故事仍须成立。
- 不改变作者锁定项，不回答作者开放项。

## 交付与验收

交付 `storyline-architecture.json`、生成证据、`validation.json`、
`package-manifest.json` 和 `stage-completion.json`。只有模型通过 S1 Schema、
设计决策语义检查、需求覆盖集合相等检查、引用闭合检查和 return 绑定检查时，
才可写入 `ready` completion。不得手写或绕过验证器生成 completion。

每个连接还必须用状态索引和完整状态文本双重绑定两端；索引、文本或所属故事线
任一不一致均不得交付。`line_order` 只需对 `causal` 连接构成拓扑序，
`associative` 连接不伪造时间或因果先后。

六维一致性记录必须恰好各一条。`causality` 的证据只能引用故事线和
`relation=causal` 的连接；关联连接可以支持时间、信息、状态或主题判断，
但绝不能冒充因果证据。未知引用、缺线覆盖以及 claim/failure condition
中的占位文本均阻断交付。
