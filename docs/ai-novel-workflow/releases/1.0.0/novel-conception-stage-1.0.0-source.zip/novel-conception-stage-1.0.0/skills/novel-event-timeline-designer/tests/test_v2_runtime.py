from __future__ import annotations

import copy
import importlib
import json
import os
import shutil
import tempfile
import unittest
from pathlib import Path
from unittest import mock


runtime = importlib.import_module("harnesses.novel-conception-autonomous.runtime")
t1 = importlib.import_module(
    "skills.novel-event-timeline-designer.scripts.run_v2"
)
e1 = importlib.import_module(
    "skills.novel-environment-system-designer.scripts.run_v2"
)
e1_test = importlib.import_module(
    "skills.novel-environment-system-designer.tests.test_v2_runtime"
)


ROLES = (
    ("background", "setup"),
    ("trigger",),
    ("development",),
    ("turn_or_crisis",),
    ("result", "aftermath"),
)


def agent_event_proposal(
    *,
    run_id: str,
    gate_reference: dict[str, str],
    source_artifacts: list[dict[str, str]],
    baseline: dict[str, object],
    storyline: dict[str, object],
    world: dict[str, object],
    environment: dict[str, object],
) -> dict[str, object]:
    """A test Agent's authored event model; production Python never authors it."""

    lines = list(storyline["storylines"])
    requirements = list(storyline["event_requirements"])
    requirement_by_line = {
        next(source for source in item["source_ids"] if str(source).startswith("SL-")): item
        for item in requirements
    }
    affordances = list(environment["event_affordance_catalog"])
    affordance_by_line = {}
    for affordance in affordances:
        for requirement_id in affordance["event_requirement_ids"]:
            requirement = next(item for item in requirements if item["id"] == requirement_id)
            line_id = next(
                source for source in requirement["source_ids"]
                if str(source).startswith("SL-")
            )
            affordance_by_line[line_id] = affordance
    resource_ids = [item["id"] for item in world["resource_flows"]]
    authority_ids = [item["id"] for item in environment["access_and_authority"]]
    access_by_environment = {
        item["subject_id"]: item["id"]
        for item in environment["access_and_authority"]
    }

    events = []
    placements = []
    ledgers = []
    sequences = []
    coverage = []
    causal_edges = []
    timing = []
    event_by_line_role = {}
    for line_index, line in enumerate(lines):
        line_id = line["id"]
        is_main = line_id == "SL-MAIN"
        base = 100 if is_main else (line_index + 1) * 10
        event_ids = []
        states = [
            line["start_state"],
            *line["state_changes"],
            line["end_state"],
        ]
        transition_count = len(states) - 1
        if transition_count > len(ROLES):
            raise AssertionError(
                "test Agent needs more responsibility events"
            )
        transition_positions = (
            [len(ROLES) - 1]
            if transition_count == 1
            else [
                round(
                    index
                    * (len(ROLES) - 1)
                    / (transition_count - 1)
                )
                for index in range(transition_count)
            ]
        )
        transition_by_position = {
            position: index
            for index, position in enumerate(transition_positions)
        }
        non_transition_index = 0
        affordance = affordance_by_line[line_id]
        environment_id = affordance["environment_id"]
        for role_index, roles in enumerate(ROLES):
            event_id = f"EV-{line_id[3:]}-{role_index + 1:02d}"
            event_ids.append(event_id)
            event_by_line_role[(line_id, roles[0])] = event_id
            if role_index in transition_by_position:
                transition_index = transition_by_position[role_index]
                subject_id = line_id
                before = states[transition_index]
                after = states[transition_index + 1]
                kind = "state"
            elif non_transition_index % 2 == 0:
                subject_id = resource_ids[line_index % len(resource_ids)]
                before = f"{subject_id}:available"
                after = f"{subject_id}:committed"
                kind = "resource"
                non_transition_index += 1
            else:
                subject_id = authority_ids[line_index % len(authority_ids)]
                before = f"{subject_id}:withheld"
                after = f"{subject_id}:granted"
                kind = "authority"
                non_transition_index += 1
            predecessors = [] if role_index == 0 else [event_ids[-2]]
            role_text = "".join(f"[RESP:{role}]" for role in roles)
            event = {
                "id": event_id,
                "responsibility": (
                    f"{role_text} Agent event for {requirement_by_line[line_id]['responsibility']}"
                ),
                "world_time": f"[WT:{base + role_index:06d}]",
                "storyline_ids": [line_id],
                "environment_id": environment_id,
                "participant_slot_ids": list(line["actor_slot_ids"]),
                "initiator_slot_id": line["actor_slot_ids"][0],
                "counter_slot_ids": [],
                "preconditions": list(affordance["prerequisites"]),
                "initiating_action": affordance["allowed_actions"][0],
                "complication": "[NO_COUNTER:systemic constraint is the opposing force]",
                "decisive_change": f"{subject_id} changes from {before} to {after}.",
                "direct_result": f"{event_id} produces a concrete downstream condition.",
                "before_state": {subject_id: before},
                "after_state": {subject_id: after},
                "next_pressure": f"{event_id} leaves the next responsibility unresolved.",
                "information_changes": [],
                "predecessor_event_ids": predecessors,
            }
            events.append(event)
            placements.append(
                {
                    "event_id": event_id,
                    "environment_id": environment_id,
                    "affordance_ids": [affordance["id"]],
                    "fit_evidence": (
                        f"{affordance['id']} permits {event['initiating_action']} "
                        f"for {line_id} in {environment_id}."
                    ),
                }
            )
            ledgers.append(
                {
                    "id": f"ST-{event_id[3:]}",
                    "subject_id": subject_id,
                    "from_state": before,
                    "trigger_ids": [event_id],
                    "to_state": after,
                    "allowed_by_ids": [access_by_environment[environment_id]],
                    "consequence": f"[KIND:{kind}] {event['direct_result']}",
                }
            )
            if predecessors:
                causal_edges.append(
                    {
                        "id": f"CE-{predecessors[0][3:]}-{event_id[3:]}",
                        "from_event_id": predecessors[0],
                        "to_event_id": event_id,
                        "mechanism": (
                            "[CAUSE_RESULT_SHA256:"
                            f"{runtime.canonical_sha256(events[-2]['direct_result'])}]"
                            "[CAUSE_PRESSURE_SHA256:"
                            f"{runtime.canonical_sha256(events[-2]['next_pressure'])}] "
                            f"{events[-2]['next_pressure']} causes {event_id}."
                        ),
                        "necessary_condition": (
                            "[PRECONDITION_SHA256:"
                            f"{runtime.canonical_sha256(event['preconditions'][0])}] "
                            f"{event['preconditions'][0]} is required."
                        ),
                    }
                )
        sequences.append(
            {
                "id": f"SEQ-{line_id[3:]}",
                "storyline_id": line_id,
                "event_ids": event_ids,
                "entry_state": line["start_state"],
                "exit_state": line["end_state"],
                "status": "complete",
            }
        )
        coverage.append(
            {
                "id": f"COV-EVD-{line_id[3:]}",
                "source_ids": [requirement_by_line[line_id]["id"]],
                "realization_ids": event_ids,
                "status": "covered",
                "evidence": (
                    f"{requirement_by_line[line_id]['responsibility']} is realized "
                    f"from background through aftermath."
                ),
            }
        )
        timing.append(
            {
                "id": f"TIME-ROOT-{line_id[3:]}",
                "event_ids": [event_ids[0]],
                "constraint": "[REL:independent-root] This line begins from an existing condition.",
                "story_effect": "The root is explicit and can run concurrently with other roots.",
            }
        )

    event_index = {item["id"]: item for item in events}
    transition_ledgers_by_line = {
        line["id"]: [
            ledger
            for event_id in next(
                sequence["event_ids"]
                for sequence in sequences
                if sequence["storyline_id"] == line["id"]
            )
            for ledger in ledgers
            if ledger["subject_id"] == line["id"]
            and ledger["trigger_ids"] == [event_id]
        ]
        for line in lines
    }

    def anchor(line_id: str, state_index: int) -> dict[str, object]:
        line = next(item for item in lines if item["id"] == line_id)
        states = [
            line["start_state"],
            *line["state_changes"],
            line["end_state"],
        ]
        transition_ledgers = transition_ledgers_by_line[line_id]
        if state_index == 0:
            return {
                "event_id": transition_ledgers[0]["trigger_ids"][0],
                "storyline_id": line_id,
                "state_index": 0,
                "state": states[0],
                "side": "before",
            }
        return {
            "event_id": transition_ledgers[state_index - 1][
                "trigger_ids"
            ][0],
            "storyline_id": line_id,
            "state_index": state_index,
            "state": states[state_index],
            "side": "after",
        }

    connection_records = []
    for connection in storyline["connections"]:
        source_id = connection["from_storyline_id"]
        target_id = connection["to_storyline_id"]
        source_anchor = anchor(
            source_id, connection["from_state_index"]
        )
        target_anchor = anchor(
            target_id, connection["to_state_index"]
        )
        source_event = source_anchor["event_id"]
        target_event = target_anchor["event_id"]
        edge_ids = []
        timing_relation = (
            "convergence"
            if connection["relation"] == "causal"
            else "association"
        )
        if connection["relation"] == "causal":
            edge_id = f"CE-SLC-{connection['id'][4:]}"
            edge_ids = [edge_id]
            event_index[target_event][
                "predecessor_event_ids"
            ].append(source_event)
            causal_edges.append(
                {
                    "id": edge_id,
                    "from_event_id": source_event,
                    "to_event_id": target_event,
                    "mechanism": (
                        "[CAUSE_RESULT_SHA256:"
                        f"{runtime.canonical_sha256(event_index[source_event]['direct_result'])}]"
                        "[CAUSE_PRESSURE_SHA256:"
                        f"{runtime.canonical_sha256(event_index[source_event]['next_pressure'])}] "
                        f"{connection['id']} transfers its consequence."
                    ),
                    "necessary_condition": (
                        "[PRECONDITION_SHA256:"
                        f"{runtime.canonical_sha256(event_index[target_event]['preconditions'][0])}] "
                        f"{event_index[target_event]['preconditions'][0]} is required."
                    ),
                }
            )
        timing_id = f"TIME-SLC-{connection['id'][4:]}"
        connection_records.append(
            {
                "id": f"CR-{connection['id'][4:]}",
                "connection_id": connection["id"],
                "relation": connection["relation"],
                "realization_kind": (
                    "causal_handoff"
                    if connection["relation"] == "causal"
                    else "associative_alignment"
                ),
                "source_anchor": source_anchor,
                "target_anchor": target_anchor,
                "causal_edge_ids": edge_ids,
                "timing_constraint_ids": [timing_id],
            }
        )
        timing.append(
            {
                "id": timing_id,
                "event_ids": [source_event, target_event],
                "constraint": (
                    f"[REL:{timing_relation}] "
                    + (
                        "Source resolves before target changes."
                        if connection["relation"] == "causal"
                        else "The two anchored states are compared without causal transfer."
                    )
                ),
                "story_effect": (
                    "The supporting line changes the main-line pressure."
                    if connection["relation"] == "causal"
                    else "The lines resonate without entering the causal DAG."
                ),
            }
        )

    decisions = [
        {
            "id": "DEC-T1-001",
            "gap": "Choose a world-time scale for event ordering.",
            "options": ["Abstract monotonic ticks.", "Calendar dates."],
            "selection": "Abstract monotonic ticks.",
            "owner": "T1",
            "authority_basis": "T1 owns event-level timing control.",
            "compatibility": "Preserves all S1 states and E1 affordances.",
            "impact_ids": [events[0]["id"]],
            "cost": "Exact calendar dates remain downstream.",
            "reversibility": "reversible",
            "downstream_freedom": "Scene duration and prose pacing remain open.",
            "projection_ids": [events[0]["id"]],
        }
    ]
    owned = [
        *[item["id"] for item in events],
        *[item["id"] for item in causal_edges],
        *[item["id"] for item in sequences],
        *[item["id"] for item in timing],
        *[item["id"] for item in ledgers],
        *[item["id"] for item in connection_records],
        *[item["id"] for item in coverage],
        *[item["id"] for item in decisions],
    ]
    claims = []
    for index, item in enumerate([*events, *sequences], 1):
        claims.append(
            {
                "id": f"DRV-T1-{index:03d}",
                "value_sha256": runtime.canonical_sha256(item),
                "source_ids": [
                    item["storyline_ids"][0]
                    if "storyline_ids" in item
                    else item["storyline_id"]
                ],
                "decision_ids": ["DEC-T1-001"],
                "projection_ids": [item["id"]],
            }
        )
    locked = [
        item["id"] for item in baseline["control_registry"]
        if item["hardness"] == "author_locked"
    ]
    author_open = [
        item["id"] for item in baseline["control_registry"]
        if item["hardness"] == "author_open"
    ]
    semantic_marker = runtime.canonical_sha256(
        [item["responsibility"] for item in requirements]
    )
    return {
        "schema_version": "2.0",
        "skill": "novel-event-timeline-designer",
        "stage": "T1",
        "run_id": run_id,
        "status": "ready",
        "input_gate": copy.deepcopy(gate_reference),
        "source_artifacts": copy.deepcopy(source_artifacts),
        "authority_partition": {
            "author_locked": locked,
            "autonomous_owned": owned,
            "downstream_freedom": sorted(
                {
                    slot
                    for line in lines
                    for slot in line["actor_slot_ids"]
                }
            ),
            "author_open": author_open,
        },
        "design_decisions": decisions,
        "derivation_claims": claims,
        "event_demands": copy.deepcopy(requirements),
        "event_span": {
            "start": min(item["world_time"] for item in events),
            "end": max(item["world_time"] for item in events),
            "granularity": f"abstract tick; upstream-semantics={semantic_marker}",
            "calendar_rules": ["Ticks are monotonic within causal edges."],
        },
        "timeline_axes": {
            "world_time_basis": f"Abstract world ticks; upstream-semantics={semantic_marker}",
            "narrative_time_strategy": "Disclosure order is independently constrained.",
            "axes": [
                "world_time",
                "background_time",
                "event_time",
                "narrative_disclosure",
            ],
        },
        "major_events": events,
        "causal_edges": causal_edges,
        "storyline_event_sequences": sequences,
        "connection_realization": connection_records,
        "environment_placement": placements,
        "state_ledger": ledgers,
        "information_changes": [],
        "event_coverage_ledger": coverage,
        "narrative_timing_constraints": timing,
        "open_items": [
            {
                "id": f"OPEN-T1-{index:03d}",
                "question": f"Preserve author-open control {control['id']}.",
                "source_ids": [control["id"]],
                "status": "author_open",
            }
            for index, control in enumerate(
                [
                    item for item in baseline["control_registry"]
                    if item["hardness"] == "author_open"
                ],
                1,
            )
        ],
    }


class T1PureContractTests(unittest.TestCase):
    """Low-cost production-validator attacks with no upstream package build."""

    @staticmethod
    def _anchors() -> dict[tuple[str, int], dict[str, object]]:
        output = {}
        output.update(
            t1._state_anchors_for_line(
                "SL-A",
                ["repeat", "middle", "repeat"],
                [
                    {"trigger_ids": ["EV-A0"]},
                    {"trigger_ids": ["EV-A1"]},
                ],
            )
        )
        output.update(
            t1._state_anchors_for_line(
                "SL-B",
                ["b0", "b1", "b2"],
                [
                    {"trigger_ids": ["EV-B0"]},
                    {"trigger_ids": ["EV-B1"]},
                ],
            )
        )
        return output

    @classmethod
    def _causal_case(cls) -> dict[str, object]:
        anchors = cls._anchors()
        events = {
            "EV-A0": {"storyline_ids": ["SL-A"]},
            "EV-A1": {"storyline_ids": ["SL-A"]},
            "EV-B0": {"storyline_ids": ["SL-B"]},
            "EV-B1": {"storyline_ids": ["SL-B"]},
        }
        edge = {
            "id": "CE-AB",
            "from_event_id": "EV-A1",
            "to_event_id": "EV-B1",
        }
        return {
            "realizations": [
                {
                    "id": "CR-AB",
                    "connection_id": "SLC-AB",
                    "relation": "causal",
                    "realization_kind": "causal_handoff",
                    "source_anchor": copy.deepcopy(
                        anchors[("SL-A", 2)]
                    ),
                    "target_anchor": copy.deepcopy(
                        anchors[("SL-B", 2)]
                    ),
                    "causal_edge_ids": ["CE-AB"],
                    "timing_constraint_ids": ["TIME-AB"],
                }
            ],
            "connections": {
                "SLC-AB": {
                    "id": "SLC-AB",
                    "relation": "causal",
                    "from_storyline_id": "SL-A",
                    "from_state_index": 2,
                    "from_state": "repeat",
                    "to_storyline_id": "SL-B",
                    "to_state_index": 2,
                    "to_state": "b2",
                }
            },
            "anchors": anchors,
            "events": events,
            "edges": {"CE-AB": edge},
            "edge_pairs": {("EV-A1", "EV-B1")},
            "timing": {
                "TIME-AB": {
                    "id": "TIME-AB",
                    "event_ids": ["EV-A1", "EV-B1"],
                }
            },
            "timing_relations": {"TIME-AB": "convergence"},
        }

    @classmethod
    def _associative_case(cls) -> dict[str, object]:
        case = cls._causal_case()
        case["connections"]["SLC-AB"]["relation"] = "associative"
        case["realizations"][0].update(
            {
                "relation": "associative",
                "realization_kind": "associative_alignment",
                "causal_edge_ids": [],
            }
        )
        case["edges"] = {}
        case["edge_pairs"] = set()
        case["timing_relations"]["TIME-AB"] = "association"
        return case

    def _validate_case(self, case: dict[str, object]) -> None:
        t1._validate_connection_realizations(
            case["realizations"],
            case["connections"],
            case["anchors"],
            case["events"],
            case["edges"],
            case["edge_pairs"],
            case["timing"],
            case["timing_relations"],
        )

    def test_state_anchor_index_contract_is_exact(self) -> None:
        two = t1._state_anchors_for_line(
            "SL-TWO",
            ["same", "same"],
            [{"trigger_ids": ["EV-TWO"]}],
        )
        self.assertEqual(
            ("EV-TWO", 0, "same", "before"),
            tuple(
                two[("SL-TWO", 0)][field]
                for field in ("event_id", "state_index", "state", "side")
            ),
        )
        self.assertEqual(
            ("EV-TWO", 1, "same", "after"),
            tuple(
                two[("SL-TWO", 1)][field]
                for field in ("event_id", "state_index", "state", "side")
            ),
        )
        multi = self._anchors()
        self.assertEqual("EV-A0", multi[("SL-A", 0)]["event_id"])
        self.assertEqual("EV-A0", multi[("SL-A", 1)]["event_id"])
        self.assertEqual("EV-A1", multi[("SL-A", 2)]["event_id"])
        self.assertNotEqual(
            multi[("SL-A", 0)],
            multi[("SL-A", 2)],
        )

    def test_responsibility_progression_and_terminal_event(self) -> None:
        event_ids = [f"EV-LONG-{index:02d}" for index in range(1, 11)]
        roles = {
            event_ids[0]: ["background", "setup"],
            event_ids[1]: ["setup"],
            event_ids[2]: ["trigger"],
            event_ids[3]: ["trigger"],
            event_ids[4]: ["development"],
            event_ids[5]: ["development"],
            event_ids[6]: ["turn_or_crisis"],
            event_ids[7]: ["turn_or_crisis"],
            event_ids[8]: ["result"],
            event_ids[9]: ["result", "aftermath"],
        }
        t1._validate_storyline_responsibility_progression(
            "SL-LONG", event_ids, roles
        )
        broken = copy.deepcopy(roles)
        broken[event_ids[9]] = ["result", "setup", "aftermath"]
        with self.assertRaisesRegex(
            t1.T1Error, "T1_STORYLINE_CHAIN_INCOMPLETE"
        ):
            t1._validate_storyline_responsibility_progression(
                "SL-LONG", event_ids, broken
            )
        ledgers = [
            {"trigger_ids": [event_ids[2]]},
            {"trigger_ids": [event_ids[-1]]},
        ]
        t1._validate_terminal_state_event(
            "SL-LONG", "main", ledgers, event_ids
        )
        with self.assertRaisesRegex(
            t1.T1Error,
            "T1_STORYLINE_TERMINAL_STATE_EVENT_MISMATCH",
        ):
            t1._validate_terminal_state_event(
                "SL-LONG",
                "main",
                ledgers[:-1],
                event_ids,
            )
        t1._validate_terminal_state_event(
            "SL-LONG",
            "optional_melody",
            ledgers[:-1],
            event_ids,
        )

    def test_causal_connection_happy_path(self) -> None:
        self._validate_case(self._causal_case())

    def test_connection_realization_schema_branches_are_hard(self) -> None:
        from jsonschema import Draft202012Validator

        contract = json.loads(
            Path(
                "docs/ai-novel-workflow/contracts/autonomous-v2/"
                "event-timeline.schema.json"
            ).read_text(encoding="utf-8")
        )
        schema = {
            "$schema": "https://json-schema.org/draft/2020-12/schema",
            "$ref": "#/$defs/connectionRealization",
            "$defs": contract["$defs"],
        }
        Draft202012Validator.check_schema(schema)
        validator = Draft202012Validator(schema)
        causal = self._causal_case()["realizations"][0]
        self.assertFalse(list(validator.iter_errors(causal)))
        causal["causal_edge_ids"] = []
        self.assertTrue(list(validator.iter_errors(causal)))
        associative = self._associative_case()["realizations"][0]
        self.assertFalse(list(validator.iter_errors(associative)))
        associative["causal_edge_ids"] = ["CE-AB"]
        self.assertTrue(list(validator.iter_errors(associative)))

    def test_relation_and_anchor_attacks(self) -> None:
        relation = self._causal_case()
        relation["realizations"][0]["relation"] = "associative"
        with self.assertRaisesRegex(
            t1.T1Error, "T1_CONNECTION_RELATION_MISMATCH"
        ):
            self._validate_case(relation)
        for field, value in (
            ("event_id", "EV-A0"),
            ("state_index", 1),
            ("side", "before"),
        ):
            case = self._causal_case()
            case["realizations"][0]["source_anchor"][field] = value
            with (
                self.subTest(field=field),
                self.assertRaisesRegex(
                    t1.T1Error,
                    "T1_CONNECTION_SOURCE_ANCHOR_MISMATCH",
                ),
            ):
                self._validate_case(case)
        target = self._causal_case()
        target["realizations"][0]["target_anchor"]["event_id"] = "EV-B0"
        with self.assertRaisesRegex(
            t1.T1Error, "T1_CONNECTION_TARGET_ANCHOR_MISMATCH"
        ):
            self._validate_case(target)

    def test_causal_edge_path_and_timing_attacks(self) -> None:
        missing = self._causal_case()
        missing["realizations"][0]["causal_edge_ids"] = []
        with self.assertRaisesRegex(
            t1.T1Error, "T1_CONNECTION_CAUSAL_PATH_MISMATCH"
        ):
            self._validate_case(missing)
        dangling = self._causal_case()
        dangling["realizations"][0]["causal_edge_ids"] = ["CE-MISSING"]
        with self.assertRaisesRegex(
            t1.T1Error, "T1_CONNECTION_CAUSAL_EDGE_MISMATCH"
        ):
            self._validate_case(dangling)
        wrong_path = self._causal_case()
        wrong_path["edges"]["CE-WRONG"] = {
            "id": "CE-WRONG",
            "from_event_id": "EV-A0",
            "to_event_id": "EV-B1",
        }
        wrong_path["edge_pairs"].add(("EV-A0", "EV-B1"))
        wrong_path["realizations"][0]["causal_edge_ids"] = ["CE-WRONG"]
        with self.assertRaisesRegex(
            t1.T1Error, "T1_CONNECTION_CAUSAL_PATH_MISMATCH"
        ):
            self._validate_case(wrong_path)
        for mutation in ("missing", "relation", "anchor"):
            case = self._causal_case()
            if mutation == "missing":
                case["realizations"][0]["timing_constraint_ids"] = []
            elif mutation == "relation":
                case["timing_relations"]["TIME-AB"] = "association"
            else:
                case["timing"]["TIME-AB"]["event_ids"] = ["EV-A1"]
            with (
                self.subTest(timing=mutation),
                self.assertRaisesRegex(
                    t1.T1Error, "T1_CONNECTION_TIMING_MISMATCH"
                ),
            ):
                self._validate_case(case)

    def test_associative_contract_and_dag_attacks(self) -> None:
        self._validate_case(self._associative_case())
        claimed = self._associative_case()
        claimed["realizations"][0]["causal_edge_ids"] = ["CE-AB"]
        with self.assertRaisesRegex(
            t1.T1Error, "T1_CONNECTION_ASSOCIATIVE_CAUSAL_CLAIM"
        ):
            self._validate_case(claimed)
        predecessor = self._associative_case()
        predecessor["edge_pairs"].add(("EV-A1", "EV-B1"))
        with self.assertRaisesRegex(
            t1.T1Error, "T1_CONNECTION_ASSOCIATIVE_PREDECESSOR"
        ):
            self._validate_case(predecessor)
        indirect = self._associative_case()
        indirect["events"]["EV-X"] = {"storyline_ids": ["SL-A"]}
        indirect["edge_pairs"].update(
            {("EV-A1", "EV-X"), ("EV-X", "EV-B1")}
        )
        with self.assertRaisesRegex(
            t1.T1Error, "T1_CONNECTION_ASSOCIATIVE_PREDECESSOR"
        ):
            self._validate_case(indirect)
        timing = self._associative_case()
        timing["timing_relations"]["TIME-AB"] = "convergence"
        with self.assertRaisesRegex(
            t1.T1Error, "T1_CONNECTION_TIMING_MISMATCH"
        ):
            self._validate_case(timing)

    def test_cross_line_edges_have_exactly_one_owner(self) -> None:
        unowned = self._causal_case()
        unowned["edges"]["CE-HIDDEN"] = {
            "id": "CE-HIDDEN",
            "from_event_id": "EV-A0",
            "to_event_id": "EV-B0",
        }
        unowned["edge_pairs"].add(("EV-A0", "EV-B0"))
        with self.assertRaisesRegex(
            t1.T1Error,
            "T1_CROSS_LINE_CAUSAL_EDGE_OWNERSHIP_MISMATCH",
        ):
            self._validate_case(unowned)
        missing = self._causal_case()
        missing["realizations"] = []
        with self.assertRaisesRegex(
            t1.T1Error, "T1_CONNECTION_REALIZATION_MISMATCH"
        ):
            self._validate_case(missing)


class T1RuntimeTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        e1_test.E1RuntimeTests.setUpClass()
        upstream = e1_test.E1RuntimeTests
        cls.shared = upstream.shared
        cls.b0 = upstream.shared_b0
        cls.s1 = upstream.shared_s1
        cls.w1 = upstream.shared_w1
        cls.coordinator = runtime.AutonomousCoordinator.from_snapshot(
            upstream.coordinator_state, upstream.coordinator_reference
        )
        cls.e1 = cls.shared / "run" / "E1-for-T1"
        workspace = cls.shared / "workspace" / "E1-for-T1"
        gate = cls.coordinator.build_input_gate("E1", "E1/input-gate.json")
        baseline = cls._read(cls.b0 / "author-control-baseline.json")
        storyline = cls._read(cls.s1 / "storyline-architecture.json")
        world = cls._read(cls.w1 / "world-model.json")
        proposal = e1_test.agent_environment_proposal(
            run_id=baseline["run_id"],
            gate_reference=gate.reference,
            source_artifacts=e1._source_artifacts(cls.b0, cls.s1, cls.w1),
            baseline=baseline,
            storyline=storyline,
            world=world,
        )
        with mock.patch.dict(
            os.environ, {"CODEX_THREAD_ID": "thread-shared-e1-for-t1"}, clear=False
        ):
            e1.start_e1_session(
                workspace,
                baseline_package=cls.b0,
                storyline_package=cls.s1,
                world_package=cls.w1,
                input_gate=gate,
            )
            cls._submit_module(
                e1,
                workspace,
                gate,
                proposal,
                {
                    "baseline_package": cls.b0,
                    "storyline_package": cls.s1,
                    "world_package": cls.w1,
                },
            )
            e1.run_e1(
                cls.e1,
                baseline_package=cls.b0,
                storyline_package=cls.s1,
                world_package=cls.w1,
                coordinator=cls.coordinator,
                input_gate=gate,
                controlled_workspace=workspace,
                logical_package_path="E1",
                next_state_path="state/revision-004.json",
            )
        cls.coordinator_state = cls.coordinator.state
        cls.coordinator_reference = cls.coordinator.state_reference

    @classmethod
    def tearDownClass(cls) -> None:
        e1_test.E1RuntimeTests.tearDownClass()

    @staticmethod
    def _read(path: Path) -> dict[str, object]:
        return json.loads(path.read_text(encoding="utf-8"))

    @staticmethod
    def _submit_module(module, workspace, gate, model, inputs) -> None:
        for phase in module.PHASES:
            payload = (
                {"model": model}
                if phase == module.PHASES[-1]
                else {
                    field: model[field]
                    for field in module.PHASE_FIELDS[phase]
                }
            )
            submit = module.submit_e1_phase if module is e1 else module.submit_t1_phase
            submit(
                workspace,
                **inputs,
                input_gate=gate,
                phase=phase,
                payload=payload,
            )

    def setUp(self) -> None:
        self.temp = tempfile.TemporaryDirectory()
        self.work = Path(self.temp.name)
        self.input_roots = {}
        for stage, source in (
            ("B0", self.b0),
            ("S1", self.s1),
            ("W1", self.w1),
            ("E1", self.e1),
        ):
            target = self.work / "run" / stage
            shutil.copytree(source, target)
            self.input_roots[stage] = target
        self.coordinator = runtime.AutonomousCoordinator.from_snapshot(
            self.coordinator_state, self.coordinator_reference
        )
        self.gate = self.coordinator.build_input_gate("T1", "T1/input-gate.json")
        self.package = self.work / "run" / "T1"
        self.workspace = self.work / "workspace" / "T1"
        self.baseline = self._read(
            self.input_roots["B0"] / "author-control-baseline.json"
        )
        self.storyline = self._read(
            self.input_roots["S1"] / "storyline-architecture.json"
        )
        self.world = self._read(self.input_roots["W1"] / "world-model.json")
        self.environment = self._read(
            self.input_roots["E1"] / "environment-system.json"
        )
        self.inputs = {
            "baseline_package": self.input_roots["B0"],
            "storyline_package": self.input_roots["S1"],
            "world_package": self.input_roots["W1"],
            "environment_package": self.input_roots["E1"],
        }
        self.proposal = agent_event_proposal(
            run_id=self.baseline["run_id"],
            gate_reference=self.gate.reference,
            source_artifacts=t1._source_artifacts(
                self.input_roots["B0"],
                self.input_roots["S1"],
                self.input_roots["W1"],
                self.input_roots["E1"],
            ),
            baseline=self.baseline,
            storyline=self.storyline,
            world=self.world,
            environment=self.environment,
        )

    def tearDown(self) -> None:
        self.temp.cleanup()

    def _validate(self, model=None, *, storyline=None) -> None:
        t1._validate_model(
            model or self.proposal,
            self.baseline,
            storyline or self.storyline,
            self.world,
            self.environment,
            t1._controls(self.input_roots["B0"], self.baseline),
            runtime.ContractRuntime(),
            expected_gate=self.gate.reference,
            expected_sources=t1._source_artifacts(
                self.input_roots["B0"],
                self.input_roots["S1"],
                self.input_roots["W1"],
                self.input_roots["E1"],
            ),
        )

    @staticmethod
    def _append_causal_edge(
        model: dict[str, object],
        *,
        edge_id: str,
        from_event_id: str,
        to_event_id: str,
    ) -> None:
        events = {
            item["id"]: item for item in model["major_events"]
        }
        source = events[from_event_id]
        target = events[to_event_id]
        target["predecessor_event_ids"].append(from_event_id)
        model["causal_edges"].append(
            {
                "id": edge_id,
                "from_event_id": from_event_id,
                "to_event_id": to_event_id,
                "mechanism": (
                    "[CAUSE_RESULT_SHA256:"
                    f"{runtime.canonical_sha256(source['direct_result'])}]"
                    "[CAUSE_PRESSURE_SHA256:"
                    f"{runtime.canonical_sha256(source['next_pressure'])}] "
                    "The source result creates this tested dependency."
                ),
                "necessary_condition": (
                    "[PRECONDITION_SHA256:"
                    f"{runtime.canonical_sha256(target['preconditions'][0])}] "
                    f"{target['preconditions'][0]} remains necessary."
                ),
            }
        )

    def _connection_record(
        self,
        relation: str,
        *,
        model: dict[str, object] | None = None,
        storyline: dict[str, object] | None = None,
    ) -> tuple[dict[str, object], dict[str, object]]:
        candidate = model or self.proposal
        source_storyline = storyline or self.storyline
        connection = next(
            item
            for item in source_storyline["connections"]
            if item["relation"] == relation
        )
        record = next(
            item
            for item in candidate["connection_realization"]
            if item["connection_id"] == connection["id"]
        )
        return connection, record

    def _associative_case(
        self,
    ) -> tuple[dict[str, object], dict[str, object]]:
        storyline = copy.deepcopy(self.storyline)
        model = copy.deepcopy(self.proposal)
        connection = storyline["connections"][0]
        connection["relation"] = "associative"
        record = next(
            item
            for item in model["connection_realization"]
            if item["connection_id"] == connection["id"]
        )
        edge_ids = set(record["causal_edge_ids"])
        self.assertTrue(
            edge_ids,
            "associative fixture requires a causal connection to convert",
        )
        removed_edges = [
            item
            for item in model["causal_edges"]
            if item["id"] in edge_ids
        ]
        self.assertEqual(
            edge_ids,
            {item["id"] for item in removed_edges},
            "every claimed causal edge must exist exactly once",
        )
        model["causal_edges"] = [
            item
            for item in model["causal_edges"]
            if item["id"] not in edge_ids
        ]
        changed_targets = {}
        for edge in removed_edges:
            targets = [
                item
                for item in model["major_events"]
                if item["id"] == edge["to_event_id"]
            ]
            self.assertEqual(
                1,
                len(targets),
                "each removed edge must have exactly one target event",
            )
            target = targets[0]
            self.assertEqual(
                1,
                target["predecessor_event_ids"].count(
                    edge["from_event_id"]
                ),
                "the removed edge must have exactly one predecessor projection",
            )
            target["predecessor_event_ids"].remove(
                edge["from_event_id"]
            )
            changed_targets[target["id"]] = target
        owned = model["authority_partition"]["autonomous_owned"]
        for edge_id in sorted(edge_ids):
            self.assertEqual(
                1,
                owned.count(edge_id),
                "each removed edge must have exactly one authority entry",
            )
        model["authority_partition"]["autonomous_owned"] = [
            item for item in owned if item not in edge_ids
        ]
        for event_id, target in changed_targets.items():
            claims = [
                item
                for item in model["derivation_claims"]
                if item["projection_ids"] == [event_id]
            ]
            self.assertEqual(
                1,
                len(claims),
                "each changed target event must have one derivation claim",
            )
            claims[0]["value_sha256"] = runtime.canonical_sha256(target)
        record.update(
            {
                "relation": "associative",
                "realization_kind": "associative_alignment",
                "causal_edge_ids": [],
            }
        )
        timing = next(
            item
            for item in model["narrative_timing_constraints"]
            if item["id"] == record["timing_constraint_ids"][0]
        )
        timing["constraint"] = (
            "[REL:association] The anchors align without causal order."
        )
        return storyline, model

    def test_state_anchor_index_contract_handles_two_multi_and_repeated(
        self,
    ) -> None:
        two = t1._state_anchors_for_line(
            "SL-TWO",
            ["same", "same"],
            [{"trigger_ids": ["EV-TWO-01"]}],
        )
        self.assertEqual(
            ("EV-TWO-01", "before", 0, "same"),
            (
                two[("SL-TWO", 0)]["event_id"],
                two[("SL-TWO", 0)]["side"],
                two[("SL-TWO", 0)]["state_index"],
                two[("SL-TWO", 0)]["state"],
            ),
        )
        self.assertEqual(
            ("EV-TWO-01", "after", 1, "same"),
            (
                two[("SL-TWO", 1)]["event_id"],
                two[("SL-TWO", 1)]["side"],
                two[("SL-TWO", 1)]["state_index"],
                two[("SL-TWO", 1)]["state"],
            ),
        )
        multi = t1._state_anchors_for_line(
            "SL-MULTI",
            ["repeat", "middle", "repeat", "end"],
            [
                {"trigger_ids": ["EV-MULTI-01"]},
                {"trigger_ids": ["EV-MULTI-02"]},
                {"trigger_ids": ["EV-MULTI-03"]},
            ],
        )
        self.assertEqual(
            ["before", "after", "after", "after"],
            [
                multi[("SL-MULTI", index)]["side"]
                for index in range(4)
            ],
        )
        self.assertEqual(
            ["EV-MULTI-01", "EV-MULTI-01", "EV-MULTI-02", "EV-MULTI-03"],
            [
                multi[("SL-MULTI", index)]["event_id"]
                for index in range(4)
            ],
        )
        self.assertNotEqual(
            multi[("SL-MULTI", 0)],
            multi[("SL-MULTI", 2)],
        )

    def test_long_responsibility_chain_is_monotonic_and_terminal(
        self,
    ) -> None:
        event_ids = [
            "EV-LONG-01",
            "EV-LONG-02",
            *[f"EV-LONG-{index:02d}" for index in range(3, 12)],
            "EV-LONG-12",
            "EV-LONG-13",
        ]
        roles = {
            event_ids[0]: ["background", "setup"],
            event_ids[1]: ["trigger"],
            **{
                event_id: ["development"]
                for event_id in event_ids[2:-2]
            },
            event_ids[-2]: ["turn_or_crisis"],
            event_ids[-1]: ["result", "aftermath"],
        }
        t1._validate_storyline_responsibility_progression(
            "SL-LONG", event_ids, roles
        )
        looped = copy.deepcopy(roles)
        looped[event_ids[-1]] = ["result", "aftermath"]
        looped[event_ids[-2]] = ["result"]
        looped[event_ids[-1]] = ["background", "result", "aftermath"]
        with self.assertRaisesRegex(
            t1.T1Error, "T1_STORYLINE_CHAIN_INCOMPLETE"
        ):
            t1._validate_storyline_responsibility_progression(
                "SL-LONG", event_ids, looped
            )

        terminal = copy.deepcopy(self.proposal)
        sequence = terminal["storyline_event_sequences"][0]
        final_event_id = sequence["event_ids"][-1]
        prior_event_id = sequence["event_ids"][-2]
        final_line_ledger = next(
            item
            for item in terminal["state_ledger"]
            if item["subject_id"] == sequence["storyline_id"]
            and item["trigger_ids"] == [final_event_id]
        )
        prior_ledger = next(
            item
            for item in terminal["state_ledger"]
            if item["trigger_ids"] == [prior_event_id]
        )
        final_line_ledger["trigger_ids"] = [prior_event_id]
        prior_ledger["trigger_ids"] = [final_event_id]
        event_by_id = {
            item["id"]: item for item in terminal["major_events"]
        }
        for field in ("before_state", "after_state"):
            (
                event_by_id[final_event_id][field],
                event_by_id[prior_event_id][field],
            ) = (
                event_by_id[prior_event_id][field],
                event_by_id[final_event_id][field],
            )
        with self.assertRaisesRegex(
            t1.T1Error,
            "T1_STORYLINE_TERMINAL_STATE_EVENT_MISMATCH",
        ):
            self._validate(terminal)

    def test_connection_anchor_relation_and_causal_contract_fail_closed(
        self,
    ) -> None:
        for field, value, code in (
            ("state_index", 999, "T1_CONNECTION_SOURCE_ANCHOR_MISMATCH"),
            ("side", "before", "T1_CONNECTION_SOURCE_ANCHOR_MISMATCH"),
            ("event_id", "EV-NOT-THE-ANCHOR", "T1_CONNECTION_SOURCE_ANCHOR_MISMATCH"),
        ):
            model = copy.deepcopy(self.proposal)
            _, record = self._connection_record("causal", model=model)
            record["source_anchor"][field] = value
            with self.subTest(field=field), self.assertRaisesRegex(
                t1.T1Error, code
            ):
                self._validate(model)

        relation = copy.deepcopy(self.proposal)
        _, record = self._connection_record("causal", model=relation)
        record.update(
            {
                "relation": "associative",
                "realization_kind": "associative_alignment",
                "causal_edge_ids": [],
            }
        )
        with self.assertRaisesRegex(
            t1.T1Error, "T1_CONNECTION_RELATION_MISMATCH"
        ):
            self._validate(relation)

        missing_edge = copy.deepcopy(self.proposal)
        _, record = self._connection_record(
            "causal", model=missing_edge
        )
        record["causal_edge_ids"] = []
        with self.assertRaisesRegex(
            t1.T1Error, "T1_MODEL_SCHEMA_INVALID"
        ):
            self._validate(missing_edge)

        wrong_path = copy.deepcopy(self.proposal)
        _, record = self._connection_record(
            "causal", model=wrong_path
        )
        record["causal_edge_ids"] = [
            next(
                edge["id"]
                for edge in wrong_path["causal_edges"]
                if edge["id"] not in record["causal_edge_ids"]
            )
        ]
        with self.assertRaisesRegex(
            t1.T1Error, "T1_CONNECTION_CAUSAL_PATH_MISMATCH"
        ):
            self._validate(wrong_path)

        wrong_timing = copy.deepcopy(self.proposal)
        _, record = self._connection_record(
            "causal", model=wrong_timing
        )
        record["timing_constraint_ids"] = [
            next(
                item["id"]
                for item in wrong_timing[
                    "narrative_timing_constraints"
                ]
                if "[REL:independent-root]" in item["constraint"]
            )
        ]
        with self.assertRaisesRegex(
            t1.T1Error, "T1_CONNECTION_TIMING_MISMATCH"
        ):
            self._validate(wrong_timing)

        missing_predecessor = copy.deepcopy(self.proposal)
        _, record = self._connection_record(
            "causal", model=missing_predecessor
        )
        edge_id = record["causal_edge_ids"][0]
        edge = next(
            item
            for item in missing_predecessor["causal_edges"]
            if item["id"] == edge_id
        )
        target = next(
            item
            for item in missing_predecessor["major_events"]
            if item["id"] == edge["to_event_id"]
        )
        target["predecessor_event_ids"].remove(
            edge["from_event_id"]
        )
        with self.assertRaisesRegex(
            t1.T1Error, "T1_CAUSAL_PREDECESSOR_MISMATCH"
        ):
            self._validate(missing_predecessor)

    def test_associative_and_cross_line_edge_ownership_fail_closed(
        self,
    ) -> None:
        associative_storyline, associative = self._associative_case()
        self._validate(
            associative,
            storyline=associative_storyline,
        )

        with_edge = copy.deepcopy(associative)
        _, record = self._connection_record(
            "associative",
            model=with_edge,
            storyline=associative_storyline,
        )
        record["causal_edge_ids"] = [
            with_edge["causal_edges"][0]["id"]
        ]
        with self.assertRaisesRegex(
            t1.T1Error, "T1_MODEL_SCHEMA_INVALID"
        ):
            self._validate(
                with_edge,
                storyline=associative_storyline,
            )

        wrong_timing = copy.deepcopy(associative)
        _, record = self._connection_record(
            "associative",
            model=wrong_timing,
            storyline=associative_storyline,
        )
        timing = next(
            item
            for item in wrong_timing[
                "narrative_timing_constraints"
            ]
            if item["id"] == record["timing_constraint_ids"][0]
        )
        timing["constraint"] = (
            "[REL:convergence] Incorrectly makes association causal."
        )
        with self.assertRaisesRegex(
            t1.T1Error, "T1_CONNECTION_TIMING_MISMATCH"
        ):
            self._validate(
                wrong_timing,
                storyline=associative_storyline,
            )

        predecessor = copy.deepcopy(associative)
        _, record = self._connection_record(
            "associative",
            model=predecessor,
            storyline=associative_storyline,
        )
        self._append_causal_edge(
            predecessor,
            edge_id="CE-ASSOCIATIVE-FORBIDDEN",
            from_event_id=record["source_anchor"]["event_id"],
            to_event_id=record["target_anchor"]["event_id"],
        )
        with self.assertRaisesRegex(
            t1.T1Error, "T1_CONNECTION_ASSOCIATIVE_PREDECESSOR"
        ):
            self._validate(
                predecessor,
                storyline=associative_storyline,
            )

        hidden = copy.deepcopy(self.proposal)
        lines = {}
        for event in hidden["major_events"]:
            lines.setdefault(
                event["storyline_ids"][0], []
            ).append(event)
        ordered_lines = sorted(
            lines,
            key=lambda line_id: min(
                int(event["world_time"][4:10])
                for event in lines[line_id]
            ),
        )
        source = min(
            lines[ordered_lines[0]],
            key=lambda item: item["world_time"],
        )
        target = max(
            lines[ordered_lines[-1]],
            key=lambda item: item["world_time"],
        )
        self._append_causal_edge(
            hidden,
            edge_id="CE-HIDDEN-CROSS-LINE",
            from_event_id=source["id"],
            to_event_id=target["id"],
        )
        with self.assertRaisesRegex(
            t1.T1Error,
            "T1_CROSS_LINE_CAUSAL_EDGE_OWNERSHIP_MISMATCH",
        ):
            self._validate(hidden)

    def test_authority_partition_rejects_overlap_before_deep_validation(self) -> None:
        model = copy.deepcopy(self.proposal)
        model["authority_partition"]["downstream_freedom"].append(
            model["authority_partition"]["autonomous_owned"][0]
        )
        with self.assertRaisesRegex(
            t1.T1Error, "T1_AUTHORITY_PARTITION_OVERLAP"
        ):
            self._validate(model)

    def test_authority_partition_requires_all_four_exact_sets(self) -> None:
        model = copy.deepcopy(self.proposal)
        model["authority_partition"]["autonomous_owned"].pop()
        with self.assertRaisesRegex(
            t1.T1Error, "T1_AUTHORITY_PARTITION_MISMATCH"
        ):
            self._validate(model)

    def _seal_workspace(self) -> None:
        with mock.patch.dict(
            os.environ, {"CODEX_THREAD_ID": "thread-t1-runtime"}, clear=False
        ):
            t1.start_t1_session(
                self.workspace, **self.inputs, input_gate=self.gate
            )
            self._submit_module(
                t1, self.workspace, self.gate, self.proposal, self.inputs
            )

    def _run_package(self) -> None:
        self._seal_workspace()
        with mock.patch.dict(
            os.environ, {"CODEX_THREAD_ID": "thread-t1-runtime"}, clear=False
        ):
            t1.run_t1(
                self.package,
                **self.inputs,
                coordinator=self.coordinator,
                input_gate=self.gate,
                controlled_workspace=self.workspace,
                logical_package_path="T1",
                next_state_path="state/revision-005.json",
            )

    def test_happy_path_and_exact_package(self) -> None:
        self._run_package()
        result = t1.validate_t1_package(self.package)
        self.assertEqual(result["verdict"], "ready")
        self.assertTrue(
            any("[KIND:resource]" in item["consequence"] for item in self.proposal["state_ledger"])
        )
        self.assertTrue(
            any("[KIND:authority]" in item["consequence"] for item in self.proposal["state_ledger"])
        )

    def test_causal_break_cycle_and_time_contradiction(self) -> None:
        broken = copy.deepcopy(self.proposal)
        broken["causal_edges"].pop()
        with self.assertRaises(t1.T1Error):
            self._validate(broken)
        cyclic = copy.deepcopy(self.proposal)
        root = cyclic["major_events"][0]["id"]
        end = cyclic["major_events"][4]["id"]
        cyclic["major_events"][0]["predecessor_event_ids"].append(end)
        event_index = {item["id"]: item for item in cyclic["major_events"]}
        cyclic["causal_edges"].append(
            {
                "id": "CE-CYCLE",
                "from_event_id": end,
                "to_event_id": root,
                "mechanism": (
                    "[CAUSE_RESULT_SHA256:"
                    f"{runtime.canonical_sha256(event_index[end]['direct_result'])}]"
                    "[CAUSE_PRESSURE_SHA256:"
                    f"{runtime.canonical_sha256(event_index[end]['next_pressure'])}] "
                    "The final pressure incorrectly loops to the root."
                ),
                "necessary_condition": (
                    "[PRECONDITION_SHA256:"
                    f"{runtime.canonical_sha256(event_index[root]['preconditions'][0])}] "
                    "The root precondition is incorrectly reused."
                ),
            }
        )
        with self.assertRaisesRegex(t1.T1Error, "T1_CAUSAL_CYCLE"):
            self._validate(cyclic)
        reversed_time = copy.deepcopy(self.proposal)
        reversed_time["major_events"][1]["world_time"] = "[WT:000001]"
        with self.assertRaises(t1.T1Error):
            self._validate(reversed_time)

    def test_environment_affordance_and_no_consequence(self) -> None:
        mismatch = copy.deepcopy(self.proposal)
        placement = mismatch["environment_placement"][0]
        placement["affordance_ids"] = [
            next(
                item["id"] for item in self.environment["event_affordance_catalog"]
                if item["environment_id"] != placement["environment_id"]
            )
        ]
        with self.assertRaisesRegex(t1.T1Error, "T1_AFFORDANCE_ENVIRONMENT_MISMATCH"):
            self._validate(mismatch)
        empty = copy.deepcopy(self.proposal)
        empty["major_events"][0]["direct_result"] = "none"
        with self.assertRaisesRegex(t1.T1Error, "T1_EVENT_CONSEQUENCE_MISSING"):
            self._validate(empty)

    def test_slc_state_information_resource_and_authority_failures(self) -> None:
        missing_slc = copy.deepcopy(self.proposal)
        missing_slc["connection_realization"].pop()
        with self.assertRaisesRegex(t1.T1Error, "T1_CONNECTION_REALIZATION_MISMATCH"):
            self._validate(missing_slc)
        state_break = copy.deepcopy(self.proposal)
        line_ledger = next(
            item for item in state_break["state_ledger"]
            if item["subject_id"].startswith("SL-")
        )
        line_ledger["to_state"] = "broken"
        with self.assertRaises(t1.T1Error):
            self._validate(state_break)
        resource_missing = copy.deepcopy(self.proposal)
        resource_event = next(
            event for event in resource_missing["major_events"]
            if next(iter(event["before_state"])) in {
                item["id"] for item in self.world["resource_flows"]
            }
        )
        resource_missing["state_ledger"] = [
            item for item in resource_missing["state_ledger"]
            if item["trigger_ids"] != [resource_event["id"]]
        ]
        with self.assertRaisesRegex(t1.T1Error, "T1_EVENT_LEDGER_BIDIRECTIONAL_MISMATCH"):
            self._validate(resource_missing)
        authority_bad = copy.deepcopy(self.proposal)
        authority_ledger = next(
            item for item in authority_bad["state_ledger"]
            if "[KIND:authority]" in item["consequence"]
        )
        authority_ledger["consequence"] = authority_ledger["consequence"].replace(
            "[KIND:authority]", "[KIND:state]"
        )
        with self.assertRaisesRegex(t1.T1Error, "T1_LEDGER_KIND_INVALID"):
            self._validate(authority_bad)
        information_bad = copy.deepcopy(self.proposal)
        event = information_bad["major_events"][0]
        event["information_changes"] = ["INFO-001"]
        with self.assertRaisesRegex(t1.T1Error, "T1_INFORMATION_BIDIRECTIONAL_MISMATCH"):
            self._validate(information_bad)

    def test_slc_causal_and_provider_semantic_bridges(self) -> None:
        slc_without_state = copy.deepcopy(self.proposal)
        connection = self.storyline["connections"][0]
        record = next(
            item for item in slc_without_state["connection_realization"]
            if item["connection_id"] == connection["id"]
        )
        original_event_id = record["source_anchor"]["event_id"]
        replacement_event_ids = sorted(
            event["id"]
            for event in slc_without_state["major_events"]
            if connection["from_storyline_id"]
            in event["storyline_ids"]
            and event["id"] != original_event_id
        )
        self.assertTrue(
            replacement_event_ids,
            "source-anchor fixture requires another real event on the source line",
        )
        replacement_event_id = replacement_event_ids[0]
        self.assertNotEqual(
            original_event_id,
            replacement_event_id,
            "source-anchor attack must change the event id",
        )
        record["source_anchor"]["event_id"] = replacement_event_id
        with self.assertRaisesRegex(
            t1.T1Error, "T1_CONNECTION_SOURCE_ANCHOR_MISMATCH"
        ):
            self._validate(slc_without_state)

        causal_junk = copy.deepcopy(self.proposal)
        causal_junk["causal_edges"][0]["mechanism"] = "arbitrary junk"
        with self.assertRaisesRegex(
            t1.T1Error, "T1_CAUSAL_SEMANTIC_BINDING_INVALID"
        ):
            self._validate(causal_junk)
        wrong_condition = copy.deepcopy(self.proposal)
        wrong_condition["causal_edges"][0]["necessary_condition"] = (
            "[PRECONDITION_SHA256:" + "0" * 64 + "] readable but wrong binding"
        )
        with self.assertRaisesRegex(
            t1.T1Error, "T1_CAUSAL_SEMANTIC_BINDING_INVALID"
        ):
            self._validate(wrong_condition)

        slot_provider = copy.deepcopy(self.proposal)
        slot_provider["state_ledger"][0]["allowed_by_ids"] = [
            slot_provider["major_events"][0]["initiator_slot_id"]
        ]
        with self.assertRaisesRegex(
            t1.T1Error, "T1_LEDGER_PROVIDER_INVALID"
        ):
            self._validate(slot_provider)
        foreign_provider = copy.deepcopy(self.proposal)
        first_event = foreign_provider["major_events"][0]
        foreign_provider["state_ledger"][0]["allowed_by_ids"] = [
            next(
                item["id"]
                for item in self.environment["access_and_authority"]
                if item["subject_id"] != first_event["environment_id"]
            )
        ]
        with self.assertRaisesRegex(
            t1.T1Error, "T1_LEDGER_PROVIDER_INVALID"
        ):
            self._validate(foreign_provider)

    def test_fake_gate_missing_completion_and_boundary_prose(self) -> None:
        fake_gate = copy.deepcopy(self.proposal)
        fake_gate["input_gate"]["sha256"] = "0" * 64
        with self.assertRaisesRegex(t1.T1Error, "T1_GATE_REFERENCE_MISMATCH"):
            self._validate(fake_gate)
        self._run_package()
        (self.package / "stage-completion.json").unlink()
        with self.assertRaises(t1.T1Error):
            t1.validate_t1_package(self.package)
        (self.package / "scene-draft.md").write_text("forbidden prose", encoding="utf-8")
        with self.assertRaisesRegex(t1.T1Error, "T1_BOUNDARY_VIOLATION"):
            t1.validate_t1_package(self.package)

    def test_opposite_upstream_semantics_change_all_five_phase_payloads(self) -> None:
        changed_storyline = copy.deepcopy(self.storyline)
        changed_storyline["event_requirements"][0]["responsibility"] = (
            "Opposite approved upstream responsibility."
        )
        changed = agent_event_proposal(
            run_id=self.baseline["run_id"],
            gate_reference=self.gate.reference,
            source_artifacts=self.proposal["source_artifacts"],
            baseline=self.baseline,
            storyline=changed_storyline,
            world=self.world,
            environment=self.environment,
        )
        for phase in t1.PHASES:
            left = (
                {"model": self.proposal}
                if phase == t1.PHASES[-1]
                else {field: self.proposal[field] for field in t1.PHASE_FIELDS[phase]}
            )
            right = (
                {"model": changed}
                if phase == t1.PHASES[-1]
                else {field: changed[field] for field in t1.PHASE_FIELDS[phase]}
            )
            self.assertNotEqual(
                runtime.canonical_sha256(left),
                runtime.canonical_sha256(right),
                phase,
            )


if __name__ == "__main__":
    unittest.main()
