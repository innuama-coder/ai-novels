---
name: novel-event-timeline-designer
description: 将全部故事线状态变化放入世界时间和具体环境，形成因果闭合的主要事件链、时间线、信息变化和叙述时序约束。用于自主构思 V2 的 T1 阶段；不撰写场景正文、不决定人物心理或改写上游故事线。
---

# 小说事件时间线设计

## 目标

把故事线架构落实为一组足以形成完整小说的主要事件，使每次变化都有前提、行动、
阻力、决定性变化、结果和下一压力。

## 权威契约

完整读取工作流第 3、7、14、15 节，以及：

- [T1 Schema](../../docs/ai-novel-workflow/contracts/autonomous-v2/event-timeline.schema.json)；
- [T1 唯一运行契约](references/runtime-contract.md)。

## 唯一生产运行路径

只允许使用 `scripts/run_v2.py`。在同一 `CODEX_THREAD_ID` 中依次调用
`start_t1_session()`、按契约顺序调用 `submit_t1_phase()`、最后调用
`run_t1()`。不得跳过受控会话、倒填阶段证据、传入会话外的一次性完整候选稿，
也不得手写 validation、manifest 或 completion。`validate_t1_package()` 只用于
只读复验，不能替代上述生产调用。

## 输入硬准入

只接受当前 B0、S1、W1、E1 completion、manifest、canonical 模型、T1 input gate 和
执行前 run-state。T1 `event_demands` ID 集必须与 S1 `event_requirements` 精确相等。

## 职责

1. 定义世界时间跨度、时间轴和叙述披露约束。
2. 定义全部主要事件及其前置状态、发起行动、复杂化、决定性变化和后果。
3. 建立事件因果边、故事线事件序列和连接点实现。
4. 把每个事件放入 E1 环境并引用允许的 affordance。
5. 记录状态、信息、资源和权限变化。
6. 输出角色槽的事件责任，不决定具体人物心理。

## 边界

- 不写场景、章节、对白或动作细节。
- 不修改 S1 故事线、W1 规则或 E1 环境。
- 不以偶然或未授权能力弥补因果缺口。
- 不把 S1 associative 连接改写为因果边或 predecessor。
- 人物只以 slot-level requirement 表达；具体角色由 C1 解析。

## 交付与验收

交付 `event-timeline.json`、证据、validation、manifest 和 T1 completion。ready 必须证明：
全部结构故事线有完整事件序列；因果无断链；环境、时间、信息和状态引用闭合；
每个事件都有后果和后续压力；全部参与槽可交给 C1。每个 S1 connection 必须以
专用 `connection_realization` 精确绑定 relation、按 state index 定位的事件侧锚点、
timing 和（仅 causal）有向 causal-edge path；跨线 causal edge 必须且只能归属一个
causal SLC。非 optional 故事线职责只可单调推进，最后事件同时承担
result/aftermath 并完成 end-state 转换。
