"""Production T1 runner for autonomous novel-conception V2."""

from __future__ import annotations

import copy
import importlib
import json
import os
import re
import shutil
import tempfile
from dataclasses import dataclass
from pathlib import Path, PurePosixPath
from typing import Any, Mapping, Sequence


rt = importlib.import_module("harnesses.novel-conception-autonomous.runtime")
s1_runtime = importlib.import_module(
    "skills.novel-storyline-architecture-designer.scripts.run_v2"
)
w1_runtime = importlib.import_module(
    "skills.novel-world-model-designer.scripts.run_v2"
)
e1_runtime = importlib.import_module(
    "skills.novel-environment-system-designer.scripts.run_v2"
)
_HERE = Path(__file__).resolve()
_REPO = _HERE.parents[3]
_SKILL = _HERE.parents[1]
_S1_SKILL = _REPO / "skills" / "novel-storyline-architecture-designer"
_W1_SKILL = _REPO / "skills" / "novel-world-model-designer"
_E1_SKILL = _REPO / "skills" / "novel-environment-system-designer"
_SCHEMAS = _REPO / "docs" / "ai-novel-workflow" / "contracts" / "autonomous-v2"

PHASES = (
    "event-demand-scan",
    "global-timeline",
    "event-and-causality-model",
    "cross-line-state-test",
    "final-event-model",
)
PHASE_FIELDS = {
    "event-demand-scan": ("event_demands",),
    "global-timeline": (
        "design_decisions",
        "event_span",
        "timeline_axes",
        "narrative_timing_constraints",
    ),
    "event-and-causality-model": (
        "major_events",
        "causal_edges",
        "environment_placement",
    ),
    "cross-line-state-test": (
        "storyline_event_sequences",
        "connection_realization",
        "state_ledger",
        "information_changes",
        "event_coverage_ledger",
        "authority_partition",
        "derivation_claims",
        "open_items",
    ),
    "final-event-model": ("model",),
}
_FORBIDDEN_MODEL_KEYS = {
    "storylines",
    "world_model",
    "environment_system",
    "characters",
    "character_profiles",
    "scenes",
    "scene_text",
    "prose",
}
_FORBIDDEN_NESTED_KEYS = {
    "psychology",
    "inner_monologue",
    "scene_text",
    "dialogue",
    "camera",
    "chapter",
    "chapter_plan",
}
_ALLOWED_ROOT_FILES = {
    "input-gate.json",
    "event-timeline.json",
    "generation-session.json",
    "generation-evidence-index.json",
    "execution-record.json",
    "event-preview.md",
    "validation.json",
    "package-manifest.json",
    "stage-completion.json",
}
_ALLOWED_SOURCE_PREFIXES = (
    "sources/B0/",
    "sources/S1/",
    "sources/W1/",
    "sources/E1/",
)

_RESPONSIBILITY_ORDER = (
    "background",
    "setup",
    "trigger",
    "development",
    "turn_or_crisis",
    "result",
    "aftermath",
)
_RESPONSIBILITY_TOKEN = re.compile(
    r"\[RESP:(background|setup|trigger|development|turn_or_crisis|result|aftermath)\]"
)
_WORLD_TIME_TOKEN = re.compile(r"\[WT:(\d{6})\]")
_TIMING_TOKEN = re.compile(
    r"\[REL:(linear|concurrent|memory|analepsis|convergence|association|independent-root)\]"
)
_LEDGER_KIND_TOKEN = re.compile(r"\[KIND:(state|resource|authority)\]")
_CAUSAL_MECHANISM = re.compile(
    r"^\[CAUSE_RESULT_SHA256:([0-9a-f]{64})\]"
    r"\[CAUSE_PRESSURE_SHA256:([0-9a-f]{64})\]\s+(.+)$"
)
_CAUSAL_CONDITION = re.compile(
    r"^\[PRECONDITION_SHA256:([0-9a-f]{64})\]\s+(.+)$"
)


class T1Error(ValueError):
    def __init__(self, code: str, message: str):
        self.code = code
        super().__init__(f"{code}: {message}")


@dataclass(frozen=True)
class T1RunReceipt:
    package_root: Path
    model: dict[str, Any]
    manifest: dict[str, Any]
    completion: Any
    transition: Any


def _fail(code: str, message: str) -> None:
    raise T1Error(code, message)


def _validate_authority_disjoint(partition: Mapping[str, Any]) -> None:
    names = (
        "author_locked",
        "autonomous_owned",
        "downstream_freedom",
        "author_open",
    )
    values = {name: set(partition[name]) for name in names}
    for index, left in enumerate(names):
        for right in names[index + 1 :]:
            overlap = sorted(values[left] & values[right])
            if overlap:
                _fail(
                    "T1_AUTHORITY_PARTITION_OVERLAP",
                    f"{left}/{right}: {overlap}",
                )


def _read(path: Path, code: str) -> dict[str, Any]:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, UnicodeError, json.JSONDecodeError) as error:
        _fail(code, f"{path}: {error}")
    if not isinstance(value, dict):
        _fail(code, f"{path} root must be an object")
    return value


def _write(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(rt.canonical_json(value), encoding="utf-8", newline="")


def _logical(prefix: str, name: str) -> str:
    value = PurePosixPath(prefix, name).as_posix() if prefix else name
    if value.startswith("/") or ".." in PurePosixPath(value).parts:
        _fail("T1_PATH_INVALID", value)
    return value


def _implementation_paths() -> dict[str, Path]:
    runtime_dir = _REPO / "harnesses" / "novel-conception-autonomous" / "runtime"
    values = {
        "skill/run_v2.py": _HERE,
        "skill/SKILL.md": _SKILL / "SKILL.md",
        "skill/runtime-contract.md": _SKILL / "references" / "runtime-contract.md",
        "upstream/S1-run_v2.py": _S1_SKILL / "scripts" / "run_v2.py",
        "upstream/S1-runtime-contract.md": (
            _S1_SKILL / "references" / "runtime-contract.md"
        ),
        "upstream/W1-run_v2.py": _W1_SKILL / "scripts" / "run_v2.py",
        "upstream/W1-runtime-contract.md": (
            _W1_SKILL / "references" / "runtime-contract.md"
        ),
        "upstream/E1-run_v2.py": _E1_SKILL / "scripts" / "run_v2.py",
        "upstream/E1-runtime-contract.md": (
            _E1_SKILL / "references" / "runtime-contract.md"
        ),
    }
    for name in (
        "canonical.py",
        "contracts.py",
        "coordinator.py",
        "baseline.py",
        "b0_completion.py",
    ):
        values[f"runtime/{name}"] = runtime_dir / name
    for name in (
        "event-timeline.schema.json",
        "environment-system.schema.json",
        "world-model.schema.json",
        "storyline-architecture.schema.json",
        "author-control-baseline.schema.json",
        "canonical-common.schema.json",
        "common-defs.schema.json",
        "input-gate.schema.json",
        "package-manifest.schema.json",
        "stage-completion.schema.json",
    ):
        values[f"schemas/{name}"] = _SCHEMAS / name
    return values


def _stage_reference(root: Path, stage: str) -> dict[str, str]:
    path = root / "stage-completion.json"
    _read(path, f"T1_{stage}_INVALID")
    return {
        "stage": stage,
        "path": f"{stage}/stage-completion.json",
        "sha256": rt.sha256_file(path),
    }


def _source_artifacts(
    b0_root: Path, s1_root: Path, w1_root: Path, e1_root: Path
) -> list[dict[str, str]]:
    selected = {
        "B0": (
            b0_root,
            (
                "author-control-baseline.json",
                "package-manifest.json",
                "stage-completion.json",
            ),
        ),
        "S1": (
            s1_root,
            (
                "storyline-architecture.json",
                "package-manifest.json",
                "stage-completion.json",
            ),
        ),
        "W1": (
            w1_root,
            (
                "world-model.json",
                "package-manifest.json",
                "stage-completion.json",
            ),
        ),
        "E1": (
            e1_root,
            (
                "environment-system.json",
                "package-manifest.json",
                "stage-completion.json",
            ),
        ),
    }
    return [
        {
            "path": f"sources/{stage}/{name}",
            "sha256": rt.sha256_file(root / name),
        }
        for stage, (root, names) in selected.items()
        for name in names
    ]


def _controls(
    b0_root: Path, baseline: Mapping[str, Any]
) -> list[dict[str, Any]]:
    found: list[dict[str, Any]] = []
    for entry in baseline["design_artifacts"]:
        source = rt.verify_artifact_reference(entry["artifact"], root=b0_root)
        for value in rt.extract_controls(source, entry["domain"]):
            found.append({**value, "domain": entry["domain"]})
    found.sort(key=lambda item: item["id"])
    return found


def _object_bindings(
    values: Sequence[Mapping[str, Any]], *, extra: str | None = None
) -> list[dict[str, str]]:
    return [
        {
            "id": item["id"],
            **({extra: str(item[extra])} if extra is not None else {}),
            "value_sha256": rt.canonical_sha256(item),
        }
        for item in values
    ]


def _control_bindings(
    controls: Sequence[Mapping[str, Any]],
) -> list[dict[str, str]]:
    return [
        {
            "id": item["id"],
            "domain": item["domain"],
            "heading": item["heading"],
            "value_sha256": rt.canonical_sha256(item["value"]),
        }
        for item in controls
    ]


def _session_id(
    thread_id: str,
    gate: Mapping[str, str],
    b0: Mapping[str, str],
    s1: Mapping[str, str],
    w1: Mapping[str, str],
    e1: Mapping[str, str],
) -> str:
    return "T1-" + rt.canonical_sha256([thread_id, gate, b0, s1, w1, e1])[:20]


def _session_context(
    *,
    baseline_package: str | Path,
    storyline_package: str | Path,
    world_package: str | Path,
    environment_package: str | Path,
    input_gate: Any,
    runtime: Any,
    full_validation: bool = True,
) -> tuple[
    Path,
    Path,
    Path,
    Path,
    dict[str, Any],
    dict[str, Any],
    dict[str, Any],
    dict[str, Any],
    list[dict[str, Any]],
    dict[str, str],
    dict[str, str],
    dict[str, str],
    dict[str, str],
]:
    b0_root = Path(baseline_package).resolve()
    s1_root = Path(storyline_package).resolve()
    w1_root = Path(world_package).resolve()
    e1_root = Path(environment_package).resolve()
    if full_validation:
        try:
            rt.validate_baseline_package(b0_root, runtime=runtime)
        except Exception as error:
            _fail("T1_B0_INVALID", str(error))
        try:
            s1_runtime.validate_s1_package(s1_root, runtime=runtime)
        except Exception as error:
            _fail("T1_S1_INVALID", str(error))
        try:
            w1_runtime.validate_w1_package(w1_root, runtime=runtime)
        except Exception as error:
            _fail("T1_W1_INVALID", str(error))
        try:
            e1_runtime.validate_e1_package(e1_root, runtime=runtime)
        except Exception as error:
            _fail("T1_E1_INVALID", str(error))
    baseline = _read(
        b0_root / "author-control-baseline.json", "T1_B0_INVALID"
    )
    storyline = _read(
        s1_root / "storyline-architecture.json", "T1_S1_INVALID"
    )
    world = _read(w1_root / "world-model.json", "T1_W1_INVALID")
    environment = _read(
        e1_root / "environment-system.json", "T1_E1_INVALID"
    )
    if {
        baseline["run_id"],
        storyline["run_id"],
        world["run_id"],
        environment["run_id"],
    } != {
        baseline["run_id"]
    }:
        _fail("T1_RUN_ID_MISMATCH", "B0/S1/W1/E1 runs differ")
    b0_ref = _stage_reference(b0_root, "B0")
    s1_ref = _stage_reference(s1_root, "S1")
    w1_ref = _stage_reference(w1_root, "W1")
    e1_ref = _stage_reference(e1_root, "E1")
    if (
        rt.sha256_file(s1_root / "sources" / "B0" / "stage-completion.json")
        != b0_ref["sha256"]
        or rt.sha256_file(
            w1_root / "sources" / "B0" / "stage-completion.json"
        )
        != b0_ref["sha256"]
        or rt.sha256_file(
            w1_root / "sources" / "S1" / "stage-completion.json"
        )
        != s1_ref["sha256"]
        or rt.sha256_file(
            e1_root / "sources" / "B0" / "stage-completion.json"
        )
        != b0_ref["sha256"]
        or rt.sha256_file(
            e1_root / "sources" / "S1" / "stage-completion.json"
        )
        != s1_ref["sha256"]
        or rt.sha256_file(
            e1_root / "sources" / "W1" / "stage-completion.json"
        )
        != w1_ref["sha256"]
    ):
        _fail(
            "T1_UPSTREAM_LINEAGE_MISMATCH",
            "S1/W1/E1 do not share the exact B0/S1/W1 lineage",
        )
    try:
        runtime.validate(input_gate.data, "input-gate.schema.json")
    except Exception as error:
        _fail("T1_GATE_INVALID", str(error))
    if (
        input_gate.data.get("target_stage") != "T1"
        or input_gate.data.get("run_id") != baseline["run_id"]
        or input_gate.data.get("baseline_completion") != b0_ref
        or input_gate.data.get("upstream_completions")
        != [s1_ref, w1_ref, e1_ref]
        or rt.canonical_sha256(input_gate.data)
        != input_gate.reference.get("sha256")
    ):
        _fail("T1_GATE_INVALID", "gate is not the exact T1/B0/S1/W1/E1 gate")
    return (
        b0_root,
        s1_root,
        w1_root,
        e1_root,
        baseline,
        storyline,
        world,
        environment,
        _controls(b0_root, baseline),
        b0_ref,
        s1_ref,
        w1_ref,
        e1_ref,
    )


def _nested_forbidden(value: Any) -> str | None:
    if isinstance(value, Mapping):
        for key, child in value.items():
            if key in _FORBIDDEN_NESTED_KEYS:
                return key
            found = _nested_forbidden(child)
            if found is not None:
                return found
    elif isinstance(value, list):
        for child in value:
            found = _nested_forbidden(child)
            if found is not None:
                return found
    return None


def _boundary_check(model: Mapping[str, Any]) -> None:
    forbidden = sorted(set(model) & _FORBIDDEN_MODEL_KEYS)
    if forbidden:
        _fail("T1_BOUNDARY_VIOLATION", f"forbidden top-level fields: {forbidden}")
    nested = _nested_forbidden(model)
    if nested is not None:
        _fail("T1_BOUNDARY_VIOLATION", f"forbidden event/prose field: {nested}")


def _unique_by_id(values: Sequence[Mapping[str, Any]], code: str) -> dict[str, Mapping[str, Any]]:
    indexed = {item["id"]: item for item in values}
    if len(indexed) != len(values):
        _fail(code, "IDs repeat")
    return indexed


def _world_time(value: str, event_id: str) -> int:
    match = _WORLD_TIME_TOKEN.fullmatch(value)
    if match is None:
        _fail("T1_WORLD_TIME_INVALID", event_id)
    return int(match.group(1))


def _responsibilities(event: Mapping[str, Any]) -> list[str]:
    roles = _RESPONSIBILITY_TOKEN.findall(event["responsibility"])
    if not roles or len(roles) != len(set(roles)):
        _fail("T1_EVENT_RESPONSIBILITY_INVALID", event["id"])
    indices = [_RESPONSIBILITY_ORDER.index(role) for role in roles]
    if indices != sorted(indices) or any(
        right - left > 1 for left, right in zip(indices, indices[1:])
    ):
        _fail("T1_EVENT_RESPONSIBILITY_INVALID", event["id"])
    return roles


def _timing_relation(item: Mapping[str, Any]) -> str:
    values = _TIMING_TOKEN.findall(item["constraint"])
    if len(values) != 1:
        _fail("T1_TIMING_CONSTRAINT_INVALID", item["id"])
    return values[0]


def _ledger_kind(item: Mapping[str, Any]) -> str:
    values = _LEDGER_KIND_TOKEN.findall(item["consequence"])
    if len(values) != 1:
        _fail("T1_LEDGER_KIND_INVALID", item["id"])
    return values[0]


def _non_placeholder(value: str) -> bool:
    return value.strip().lower() not in {
        "none",
        "n/a",
        "na",
        "unknown",
        "tbd",
        "placeholder",
        "无",
        "未知",
        "待定",
    }


def _event_line_for_requirement(
    requirement: Mapping[str, Any], lines: Mapping[str, Mapping[str, Any]]
) -> str:
    found = [source for source in requirement["source_ids"] if source in lines]
    if len(found) != 1:
        _fail("T1_EVENT_REQUIREMENT_DANGLING", requirement["id"])
    return found[0]


def _is_acyclic(events: set[str], pairs: set[tuple[str, str]]) -> bool:
    incoming = {event_id: 0 for event_id in events}
    adjacency = {event_id: set() for event_id in events}
    for left, right in pairs:
        if right not in adjacency[left]:
            adjacency[left].add(right)
            incoming[right] += 1
    queue = [item for item, count in incoming.items() if count == 0]
    visited = 0
    while queue:
        current = queue.pop()
        visited += 1
        for target in adjacency[current]:
            incoming[target] -= 1
            if incoming[target] == 0:
                queue.append(target)
    return visited == len(events)


def _state_anchors_for_line(
    line_id: str,
    required_states: Sequence[str],
    transition_ledgers: Sequence[Mapping[str, Any]],
) -> dict[tuple[str, int], dict[str, Any]]:
    """Map canonical state positions to exact transition-event sides."""

    if (
        len(required_states) < 2
        or len(transition_ledgers) != len(required_states) - 1
    ):
        _fail(
            "T1_STORYLINE_STATE_PROGRESSION_MISMATCH",
            line_id,
        )
    output = {
        (line_id, 0): {
            "event_id": transition_ledgers[0]["trigger_ids"][0],
            "storyline_id": line_id,
            "state_index": 0,
            "state": required_states[0],
            "side": "before",
        }
    }
    for state_index, state in enumerate(required_states[1:], 1):
        output[(line_id, state_index)] = {
            "event_id": transition_ledgers[state_index - 1][
                "trigger_ids"
            ][0],
            "storyline_id": line_id,
            "state_index": state_index,
            "state": state,
            "side": "after",
        }
    return output


def _validate_storyline_responsibility_progression(
    line_id: str,
    event_ids: Sequence[str],
    event_roles: Mapping[str, Sequence[str]],
) -> None:
    observed: list[str] = []
    responsibility_indices: list[int] = []
    for event_id in event_ids:
        for role in event_roles[event_id]:
            responsibility_indices.append(
                _RESPONSIBILITY_ORDER.index(role)
            )
            if role not in observed:
                observed.append(role)
    terminal_roles = set(event_roles[event_ids[-1]])
    if (
        observed != list(_RESPONSIBILITY_ORDER)
        or any(
            left > right
            for left, right in zip(
                responsibility_indices,
                responsibility_indices[1:],
            )
        )
        or not {"result", "aftermath"}.issubset(terminal_roles)
    ):
        _fail("T1_STORYLINE_CHAIN_INCOMPLETE", line_id)


def _validate_terminal_state_event(
    line_id: str,
    line_type: str,
    transition_ledgers: Sequence[Mapping[str, Any]],
    event_ids: Sequence[str],
) -> None:
    """Require the terminal nonoptional event to perform the end-state transition."""

    if (
        line_type != "optional_melody"
        and (
            not transition_ledgers
            or transition_ledgers[-1]["trigger_ids"][0] != event_ids[-1]
        )
    ):
        _fail(
            "T1_STORYLINE_TERMINAL_STATE_EVENT_MISMATCH",
            line_id,
        )


def _validate_connection_realizations(
    realization_records: Sequence[Mapping[str, Any]],
    connections: Mapping[str, Mapping[str, Any]],
    state_anchor_by_line_index: Mapping[
        tuple[str, int], Mapping[str, Any]
    ],
    events: Mapping[str, Mapping[str, Any]],
    edges: Mapping[str, Mapping[str, Any]],
    edge_pairs: set[tuple[str, str]],
    timing: Mapping[str, Mapping[str, Any]],
    timing_relations: Mapping[str, str],
) -> None:
    """Validate exact S1 connection realization and cross-line edge ownership."""

    realizations = _unique_by_id(
        realization_records,
        "T1_CONNECTION_REALIZATION_DUPLICATE",
    )
    realization_by_connection: dict[str, Mapping[str, Any]] = {}
    cross_line_edge_claims: dict[str, list[str]] = {}

    def is_cross_line_edge(edge: Mapping[str, Any]) -> bool:
        return set(
            events[edge["from_event_id"]]["storyline_ids"]
        ).isdisjoint(
            events[edge["to_event_id"]]["storyline_ids"]
        )

    def has_causal_path(source_id: str, target_id: str) -> bool:
        frontier = [source_id]
        visited: set[str] = set()
        while frontier:
            current = frontier.pop()
            if current in visited:
                continue
            visited.add(current)
            for left, right in edge_pairs:
                if left != current:
                    continue
                if right == target_id:
                    return True
                if right not in visited:
                    frontier.append(right)
        return False

    for record in realizations.values():
        connection_id = record["connection_id"]
        connection = connections.get(connection_id)
        if (
            connection is None
            or connection_id in realization_by_connection
        ):
            _fail(
                "T1_CONNECTION_REALIZATION_MISMATCH",
                connection_id,
            )
        if record["relation"] != connection["relation"]:
            _fail(
                "T1_CONNECTION_RELATION_MISMATCH",
                connection_id,
            )
        expected_source_anchor = state_anchor_by_line_index.get(
            (
                connection["from_storyline_id"],
                connection["from_state_index"],
            )
        )
        expected_target_anchor = state_anchor_by_line_index.get(
            (
                connection["to_storyline_id"],
                connection["to_state_index"],
            )
        )
        if (
            expected_source_anchor is None
            or expected_target_anchor is None
            or expected_source_anchor["state"]
            != connection["from_state"]
            or expected_target_anchor["state"]
            != connection["to_state"]
        ):
            _fail(
                "T1_CONNECTION_CANONICAL_ANCHOR_INVALID",
                connection_id,
            )
        if record["source_anchor"] != expected_source_anchor:
            _fail(
                "T1_CONNECTION_SOURCE_ANCHOR_MISMATCH",
                connection_id,
            )
        if record["target_anchor"] != expected_target_anchor:
            _fail(
                "T1_CONNECTION_TARGET_ANCHOR_MISMATCH",
                connection_id,
            )
        timing_ids = record["timing_constraint_ids"]
        if (
            not timing_ids
            or any(item not in timing for item in timing_ids)
        ):
            _fail(
                "T1_CONNECTION_TIMING_MISMATCH",
                connection_id,
            )
        source_event_id = expected_source_anchor["event_id"]
        target_event_id = expected_target_anchor["event_id"]
        expected_relation = (
            "convergence"
            if connection["relation"] == "causal"
            else "association"
        )
        for timing_id in timing_ids:
            timing_record = timing[timing_id]
            if (
                timing_relations[timing_id] != expected_relation
                or not {
                    source_event_id,
                    target_event_id,
                }.issubset(timing_record["event_ids"])
            ):
                _fail(
                    "T1_CONNECTION_TIMING_MISMATCH",
                    connection_id,
                )

        if connection["relation"] == "causal":
            edge_ids = record["causal_edge_ids"]
            if record["realization_kind"] != "causal_handoff":
                _fail(
                    "T1_CONNECTION_REALIZATION_KIND_MISMATCH",
                    connection_id,
                )
            if any(edge_id not in edges for edge_id in edge_ids):
                _fail(
                    "T1_CONNECTION_CAUSAL_EDGE_MISMATCH",
                    connection_id,
                )
            path_edges = [edges[edge_id] for edge_id in edge_ids]
            if (
                not path_edges
                or path_edges[0]["from_event_id"]
                != source_event_id
                or path_edges[-1]["to_event_id"]
                != target_event_id
                or any(
                    left["to_event_id"] != right["from_event_id"]
                    for left, right in zip(
                        path_edges, path_edges[1:]
                    )
                )
                or any(
                    (
                        edge["from_event_id"],
                        edge["to_event_id"],
                    )
                    not in edge_pairs
                    for edge in path_edges
                )
            ):
                _fail(
                    "T1_CONNECTION_CAUSAL_PATH_MISMATCH",
                    connection_id,
                )
            path_event_ids = {
                source_event_id,
                *(edge["to_event_id"] for edge in path_edges),
            }
            if any(
                not path_event_ids.issubset(
                    timing[timing_id]["event_ids"]
                )
                for timing_id in timing_ids
            ):
                _fail(
                    "T1_CONNECTION_TIMING_MISMATCH",
                    connection_id,
                )
            owned_cross_line_edges = [
                edge
                for edge in path_edges
                if is_cross_line_edge(edge)
            ]
            if (
                not owned_cross_line_edges
                or any(
                    connection["from_storyline_id"]
                    not in events[edge["from_event_id"]][
                        "storyline_ids"
                    ]
                    or connection["to_storyline_id"]
                    not in events[edge["to_event_id"]][
                        "storyline_ids"
                    ]
                    for edge in owned_cross_line_edges
                )
            ):
                _fail(
                    "T1_CONNECTION_CROSS_LINE_EDGE_MISMATCH",
                    connection_id,
                )
            for edge in owned_cross_line_edges:
                cross_line_edge_claims.setdefault(
                    edge["id"], []
                ).append(connection_id)
        else:
            if (
                record["realization_kind"]
                != "associative_alignment"
                or record["causal_edge_ids"]
            ):
                _fail(
                    "T1_CONNECTION_ASSOCIATIVE_CAUSAL_CLAIM",
                    connection_id,
                )
            if (
                has_causal_path(source_event_id, target_event_id)
                or has_causal_path(target_event_id, source_event_id)
            ):
                _fail(
                    "T1_CONNECTION_ASSOCIATIVE_PREDECESSOR",
                    connection_id,
                )
        realization_by_connection[connection_id] = record

    if set(realization_by_connection) != set(connections):
        _fail(
            "T1_CONNECTION_REALIZATION_MISMATCH",
            "every SLC must be realized exactly once",
        )
    cross_line_edge_ids = {
        edge_id
        for edge_id, edge in edges.items()
        if is_cross_line_edge(edge)
    }
    if (
        set(cross_line_edge_claims) != cross_line_edge_ids
        or any(
            len(claims) != 1
            for claims in cross_line_edge_claims.values()
        )
    ):
        _fail(
            "T1_CROSS_LINE_CAUSAL_EDGE_OWNERSHIP_MISMATCH",
            "each cross-line causal edge requires exactly one causal SLC",
        )


def _validate_model(
    model: Mapping[str, Any],
    baseline: Mapping[str, Any],
    storyline: Mapping[str, Any],
    world: Mapping[str, Any],
    environment: Mapping[str, Any],
    controls: Sequence[Mapping[str, Any]],
    runtime: Any,
    *,
    expected_gate: Mapping[str, str] | None = None,
    expected_sources: Sequence[Mapping[str, str]] | None = None,
) -> None:
    _boundary_check(model)
    try:
        runtime.validate(model, "event-timeline.schema.json")
    except Exception as error:
        _fail("T1_MODEL_SCHEMA_INVALID", str(error))
    partition = model["authority_partition"]
    _validate_authority_disjoint(partition)
    if model["run_id"] != baseline["run_id"]:
        _fail("T1_RUN_ID_MISMATCH", "model belongs to another run")
    if model["event_demands"] != storyline["event_requirements"]:
        _fail(
            "T1_DEMAND_PROJECTION_MISMATCH",
            "T1 must consume exact S1 event requirements",
        )
    lines = _unique_by_id(storyline["storylines"], "T1_STORYLINE_DUPLICATE")
    requirements = _unique_by_id(
        storyline["event_requirements"], "T1_EVENT_REQUIREMENT_DUPLICATE"
    )
    requirement_line = {
        item_id: _event_line_for_requirement(item, lines)
        for item_id, item in requirements.items()
    }
    connections = _unique_by_id(
        storyline["connections"], "T1_CONNECTION_DUPLICATE"
    )
    environments = _unique_by_id(
        environment["environments"], "T1_ENVIRONMENT_DUPLICATE"
    )
    affordances = _unique_by_id(
        environment["event_affordance_catalog"], "T1_AFFORDANCE_DUPLICATE"
    )
    events = _unique_by_id(model["major_events"], "T1_EVENT_DUPLICATE")
    edges = _unique_by_id(model["causal_edges"], "T1_CAUSAL_EDGE_DUPLICATE")
    sequences = _unique_by_id(
        model["storyline_event_sequences"], "T1_SEQUENCE_DUPLICATE"
    )
    placements = {
        item["event_id"]: item for item in model["environment_placement"]
    }
    if len(placements) != len(model["environment_placement"]):
        _fail("T1_ENVIRONMENT_PLACEMENT_DUPLICATE", "event placement repeats")

    actor_slots = {
        slot for line in lines.values() for slot in line["actor_slot_ids"]
    }
    formal_objects: set[str] = set(lines) | actor_slots | set(environments)
    resource_subjects = {
        item["id"] for item in world["resource_flows"]
    }
    authority_subjects = {
        item["id"] for item in world["authority_flows"]
    } | {item["id"] for item in environment["access_and_authority"]}
    world_rule_providers = {
        item["id"]: item
        for item in world["world_facts"]
        if item["kind"] == "rule"
    }
    world_system_providers = {
        item["id"]: item for item in world["systems"]
    }
    world_institution_providers = {
        item["id"]: item for item in world["institutions"]
    }
    access_providers = {
        item["id"]: item for item in environment["access_and_authority"]
    }
    transition_providers = {
        item["id"]: item for item in environment["transition_contracts"]
    }
    for source, fields in (
        (
            world,
            (
                "world_facts",
                "history_pressures",
                "institutions",
                "systems",
                "resource_flows",
                "authority_flows",
                "information_flows",
                "rule_conflict_matrix",
                "storyline_support_ledger",
            ),
        ),
        (
            environment,
            (
                "functional_zones",
                "environment_topology",
                "access_and_authority",
                "resource_and_information_channels",
                "hazards_and_failure_modes",
                "transition_contracts",
                "storyline_hosting_ledger",
                "event_affordance_catalog",
            ),
        ),
    ):
        for field in fields:
            formal_objects.update(item["id"] for item in source[field])

    event_times: dict[str, int] = {}
    event_roles: dict[str, list[str]] = {}
    for event_id, event in events.items():
        event_times[event_id] = _world_time(event["world_time"], event_id)
        event_roles[event_id] = _responsibilities(event)
        if not set(event["storyline_ids"]).issubset(lines):
            _fail("T1_EVENT_STORYLINE_DANGLING", event_id)
        allowed_slots = {
            slot
            for line_id in event["storyline_ids"]
            for slot in lines[line_id]["actor_slot_ids"]
        }
        if (
            not set(event["participant_slot_ids"]).issubset(allowed_slots)
            or event["initiator_slot_id"] not in event["participant_slot_ids"]
            or not set(event["counter_slot_ids"]).issubset(
                event["participant_slot_ids"]
            )
        ):
            _fail("T1_EVENT_PARTICIPATION_INVALID", event_id)
        if (
            not event["counter_slot_ids"]
            and not event["complication"].startswith("[NO_COUNTER:")
        ):
            _fail("T1_COUNTER_RESPONSIBILITY_MISSING", event_id)
        if event["environment_id"] not in environments:
            _fail("T1_EVENT_ENVIRONMENT_DANGLING", event_id)
        if set(event["before_state"]) != set(event["after_state"]):
            _fail("T1_EVENT_STATE_SHAPE_MISMATCH", event_id)
        changed = [
            subject
            for subject in event["before_state"]
            if event["before_state"][subject] != event["after_state"][subject]
        ]
        if len(changed) != 1 or changed[0] not in formal_objects:
            _fail("T1_EVENT_DOMINANT_CHANGE_INVALID", event_id)
        for field in (
            "initiating_action",
            "complication",
            "decisive_change",
            "direct_result",
            "next_pressure",
        ):
            if not _non_placeholder(event[field]):
                _fail("T1_EVENT_CONSEQUENCE_MISSING", f"{event_id}.{field}")

    if set(placements) != set(events):
        _fail("T1_ENVIRONMENT_PLACEMENT_MISMATCH", "one placement per event required")
    for event_id, placement in placements.items():
        event = events[event_id]
        if placement["environment_id"] != event["environment_id"]:
            _fail("T1_ENVIRONMENT_PLACEMENT_MISMATCH", event_id)
        for affordance_id in placement["affordance_ids"]:
            affordance = affordances.get(affordance_id)
            if affordance is None or affordance["environment_id"] != event["environment_id"]:
                _fail("T1_AFFORDANCE_ENVIRONMENT_MISMATCH", event_id)
            allowed_lines = {
                requirement_line[item]
                for item in affordance["event_requirement_ids"]
                if item in requirement_line
            }
            if not allowed_lines & set(event["storyline_ids"]):
                _fail("T1_AFFORDANCE_STORYLINE_MISMATCH", event_id)
            if event["initiating_action"] not in affordance["allowed_actions"]:
                _fail("T1_AFFORDANCE_ACTION_MISMATCH", event_id)
            if not set(affordance["prerequisites"]).issubset(event["preconditions"]):
                _fail("T1_AFFORDANCE_PRECONDITION_MISMATCH", event_id)

    edge_pairs: set[tuple[str, str]] = set()
    for edge in edges.values():
        left, right = edge["from_event_id"], edge["to_event_id"]
        if left not in events or right not in events or left == right:
            _fail("T1_CAUSAL_EDGE_DANGLING", edge["id"])
        mechanism = _CAUSAL_MECHANISM.fullmatch(edge["mechanism"])
        condition = _CAUSAL_CONDITION.fullmatch(edge["necessary_condition"])
        if (
            mechanism is None
            or condition is None
            or mechanism.group(1)
            != rt.canonical_sha256(events[left]["direct_result"])
            or mechanism.group(2)
            != rt.canonical_sha256(events[left]["next_pressure"])
            or condition.group(1)
            not in {
                rt.canonical_sha256(item)
                for item in events[right]["preconditions"]
            }
            or not _non_placeholder(mechanism.group(3))
            or not _non_placeholder(condition.group(2))
        ):
            _fail("T1_CAUSAL_SEMANTIC_BINDING_INVALID", edge["id"])
        pair = (left, right)
        if pair in edge_pairs:
            _fail("T1_CAUSAL_EDGE_DUPLICATE", edge["id"])
        edge_pairs.add(pair)
    predecessor_pairs = {
        (predecessor, event_id)
        for event_id, event in events.items()
        for predecessor in event["predecessor_event_ids"]
    }
    if predecessor_pairs != edge_pairs:
        _fail("T1_CAUSAL_PREDECESSOR_MISMATCH", "edges and predecessors differ")
    if not _is_acyclic(set(events), edge_pairs):
        _fail("T1_CAUSAL_CYCLE", "event graph is cyclic")
    for left, right in edge_pairs:
        if event_times[left] >= event_times[right]:
            _fail("T1_CAUSAL_TIME_CONTRADICTION", f"{left}->{right}")

    timing = _unique_by_id(
        model["narrative_timing_constraints"], "T1_TIMING_DUPLICATE"
    )
    timing_relations: dict[str, str] = {}
    for item_id, item in timing.items():
        if not set(item["event_ids"]).issubset(events):
            _fail("T1_TIMING_EVENT_DANGLING", item_id)
        timing_relations[item_id] = _timing_relation(item)
    roots = {
        event_id for event_id, event in events.items()
        if not event["predecessor_event_ids"]
    }
    for root_id in roots:
        if "background" not in event_roles[root_id] or not any(
            root_id in item["event_ids"]
            and timing_relations[item_id] in {"concurrent", "independent-root"}
            for item_id, item in timing.items()
        ):
            _fail("T1_ROOT_EXPLANATION_MISSING", root_id)
    reachable = set(roots)
    changed = True
    while changed:
        changed = False
        for left, right in edge_pairs:
            if left in reachable and right not in reachable:
                reachable.add(right)
                changed = True
    if reachable != set(events):
        _fail("T1_CAUSAL_DISCONNECTED", "event not reachable from an explained root")

    sequence_by_line: dict[str, Mapping[str, Any]] = {}
    for sequence in sequences.values():
        line_id = sequence["storyline_id"]
        if line_id in sequence_by_line or line_id not in lines:
            _fail("T1_SEQUENCE_COVERAGE_MISMATCH", line_id)
        if (
            sequence["entry_state"] != lines[line_id]["start_state"]
            or sequence["exit_state"] != lines[line_id]["end_state"]
        ):
            _fail("T1_SEQUENCE_STATE_MISMATCH", line_id)
        event_ids = sequence["event_ids"]
        if any(item not in events for item in event_ids):
            _fail("T1_SEQUENCE_EVENT_DANGLING", line_id)
        if event_ids != sorted(event_ids, key=lambda item: event_times[item]):
            _fail("T1_SEQUENCE_TIME_CONTRADICTION", line_id)
        if any(line_id not in events[item]["storyline_ids"] for item in event_ids):
            _fail("T1_SEQUENCE_MEMBERSHIP_MISMATCH", line_id)
        sequence_by_line[line_id] = sequence
    if set(sequence_by_line) != set(lines):
        _fail("T1_SEQUENCE_COVERAGE_MISMATCH", "one sequence per storyline required")
    for event_id, event in events.items():
        for line_id in event["storyline_ids"]:
            if event_id not in sequence_by_line[line_id]["event_ids"]:
                _fail("T1_SEQUENCE_MEMBERSHIP_MISMATCH", event_id)

    for line_id, line in lines.items():
        if line["type"] == "optional_melody":
            continue
        _validate_storyline_responsibility_progression(
            line_id,
            sequence_by_line[line_id]["event_ids"],
            event_roles,
        )

    coverage_by_requirement: dict[str, Mapping[str, Any]] = {}
    for record in model["event_coverage_ledger"]:
        if len(record["source_ids"]) != 1:
            _fail("T1_EVENT_COVERAGE_MISMATCH", record["id"])
        requirement_id = record["source_ids"][0]
        if (
            requirement_id not in requirements
            or requirement_id in coverage_by_requirement
            or not set(record["realization_ids"]).issubset(events)
        ):
            _fail("T1_EVENT_COVERAGE_MISMATCH", requirement_id)
        line_id = requirement_line[requirement_id]
        if any(
            line_id not in events[event_id]["storyline_ids"]
            for event_id in record["realization_ids"]
        ):
            _fail("T1_EVENT_COVERAGE_MISMATCH", requirement_id)
        coverage_by_requirement[requirement_id] = record
    if set(coverage_by_requirement) != set(requirements):
        _fail("T1_EVENT_COVERAGE_MISMATCH", "every EVD must be covered exactly once")

    ledgers = _unique_by_id(model["state_ledger"], "T1_LEDGER_DUPLICATE")
    ledger_by_event_subject: dict[tuple[str, str], Mapping[str, Any]] = {}
    for ledger_id, ledger in ledgers.items():
        kind = _ledger_kind(ledger)
        subject = ledger["subject_id"]
        if subject not in formal_objects or len(ledger["trigger_ids"]) != 1:
            _fail("T1_LEDGER_SUBJECT_INVALID", ledger_id)
        trigger = ledger["trigger_ids"][0]
        if trigger not in events or subject not in events[trigger]["before_state"]:
            _fail("T1_LEDGER_EVENT_MISMATCH", ledger_id)
        expected_kind = (
            "resource"
            if subject in resource_subjects
            else "authority"
            if subject in authority_subjects
            else "state"
        )
        if kind != expected_kind:
            _fail("T1_LEDGER_KIND_INVALID", ledger_id)
        event = events[trigger]
        event_lines = set(event["storyline_ids"])
        placed_affordances = set(placements[trigger]["affordance_ids"])

        def provider_applies(provider_id: str) -> bool:
            if provider_id in world_rule_providers:
                return bool(
                    set(world_rule_providers[provider_id]["applies_to_ids"])
                    & event_lines
                )
            if provider_id in world_system_providers:
                return bool(
                    set(world_system_providers[provider_id]["storyline_ids"])
                    & event_lines
                )
            if provider_id in world_institution_providers:
                return bool(
                    set(world_institution_providers[provider_id]["storyline_ids"])
                    & event_lines
                )
            if provider_id in access_providers:
                return (
                    access_providers[provider_id]["subject_id"]
                    == event["environment_id"]
                )
            if provider_id in affordances:
                return provider_id in placed_affordances
            if provider_id in transition_providers:
                provider = transition_providers[provider_id]
                return (
                    provider["subject_id"] == event["environment_id"]
                    and bool(
                        set(provider["trigger_ids"]) & placed_affordances
                    )
                )
            return False

        if not all(
            provider_applies(provider_id)
            for provider_id in ledger["allowed_by_ids"]
        ):
            _fail("T1_LEDGER_PROVIDER_INVALID", ledger_id)
        if (
            ledger["from_state"] != events[trigger]["before_state"][subject]
            or ledger["to_state"] != events[trigger]["after_state"][subject]
            or ledger["from_state"] == ledger["to_state"]
        ):
            _fail("T1_LEDGER_EVENT_MISMATCH", ledger_id)
        key = (trigger, subject)
        if key in ledger_by_event_subject:
            _fail("T1_LEDGER_DUPLICATE", ledger_id)
        ledger_by_event_subject[key] = ledger
    for event_id, event in events.items():
        changed_subjects = [
            subject
            for subject in event["before_state"]
            if event["before_state"][subject] != event["after_state"][subject]
        ]
        if set(changed_subjects) != {
            subject for trigger, subject in ledger_by_event_subject if trigger == event_id
        }:
            _fail("T1_EVENT_LEDGER_BIDIRECTIONAL_MISMATCH", event_id)
    by_ledger_subject: dict[str, list[Mapping[str, Any]]] = {}
    for ledger in ledgers.values():
        by_ledger_subject.setdefault(ledger["subject_id"], []).append(ledger)
    for subject, subject_ledgers in by_ledger_subject.items():
        ordered = sorted(
            subject_ledgers,
            key=lambda item: event_times[item["trigger_ids"][0]],
        )
        if any(
            left["to_state"] != right["from_state"]
            for left, right in zip(ordered, ordered[1:])
        ):
            _fail("T1_LEDGER_CONTINUITY_BROKEN", subject)

    state_anchor_by_line_index: dict[
        tuple[str, int], dict[str, Any]
    ] = {}
    for line_id, line in lines.items():
        required_states = [
            line["start_state"],
            *line["state_changes"],
            line["end_state"],
        ]
        transition_ledgers = [
            ledger
            for event_id in sequence_by_line[line_id]["event_ids"]
            for ledger in ledgers.values()
            if ledger["subject_id"] == line_id
            and ledger["trigger_ids"] == [event_id]
        ]
        observed = [
            (ledger["from_state"], ledger["to_state"])
            for ledger in transition_ledgers
        ]
        expected = list(zip(required_states, required_states[1:]))
        if observed != expected:
            _fail("T1_STORYLINE_STATE_PROGRESSION_MISMATCH", line_id)
        _validate_terminal_state_event(
            line_id,
            line["type"],
            transition_ledgers,
            sequence_by_line[line_id]["event_ids"],
        )
        state_anchor_by_line_index.update(
            _state_anchors_for_line(
                line_id,
                required_states,
                transition_ledgers,
            )
        )

    _validate_connection_realizations(
        model["connection_realization"],
        connections,
        state_anchor_by_line_index,
        events,
        edges,
        edge_pairs,
        timing,
        timing_relations,
    )

    information = _unique_by_id(
        model["information_changes"], "T1_INFORMATION_DUPLICATE"
    )
    for info_id, change in information.items():
        if (
            change["subject_id"] not in formal_objects
            or not set(change["event_ids"]).issubset(events)
            or not set(change["visibility_ids"]).issubset(actor_slots)
            or change["before"] == change["after"]
        ):
            _fail("T1_INFORMATION_CHANGE_INVALID", info_id)
        for event_id in change["event_ids"]:
            if info_id not in events[event_id]["information_changes"]:
                _fail("T1_INFORMATION_BIDIRECTIONAL_MISMATCH", info_id)
    for event_id, event in events.items():
        expected_info = {
            info_id
            for info_id, change in information.items()
            if event_id in change["event_ids"]
        }
        if set(event["information_changes"]) != expected_info:
            _fail("T1_INFORMATION_BIDIRECTIONAL_MISMATCH", event_id)
    by_info_subject: dict[str, list[Mapping[str, Any]]] = {}
    for change in information.values():
        by_info_subject.setdefault(change["subject_id"], []).append(change)
    for subject, changes in by_info_subject.items():
        ordered = sorted(
            changes,
            key=lambda item: min(event_times[event_id] for event_id in item["event_ids"]),
        )
        if any(
            left["after"] != right["before"]
            for left, right in zip(ordered, ordered[1:])
        ):
            _fail("T1_INFORMATION_CONTINUITY_BROKEN", subject)

    span_start = _WORLD_TIME_TOKEN.fullmatch(model["event_span"]["start"])
    span_end = _WORLD_TIME_TOKEN.fullmatch(model["event_span"]["end"])
    if (
        span_start is None
        or span_end is None
        or int(span_start.group(1)) != min(event_times.values())
        or int(span_end.group(1)) != max(event_times.values())
    ):
        _fail("T1_EVENT_SPAN_MISMATCH", "span must equal event min/max")
    required_axes = {
        "world_time",
        "background_time",
        "event_time",
        "narrative_disclosure",
    }
    if set(model["timeline_axes"]["axes"]) != required_axes:
        _fail("T1_TIMELINE_AXES_INCOMPLETE", "four explicit axes required")

    locked = {
        item["id"]
        for item in baseline["control_registry"]
        if item["hardness"] == "author_locked"
    }
    author_open = {
        item["id"]
        for item in baseline["control_registry"]
        if item["hardness"] == "author_open"
    }
    owned_entities: dict[str, Mapping[str, Any]] = {
        **events,
        **edges,
        **sequences,
        **timing,
        **ledgers,
        **information,
        **{item["id"]: item for item in model["connection_realization"]},
        **{item["id"]: item for item in model["event_coverage_ledger"]},
    }
    decisions = {item["id"]: item for item in model["design_decisions"]}
    if set(partition["author_locked"]) != locked:
        _fail("T1_AUTHORITY_PARTITION_MISMATCH", "author_locked differs from B0")
    if set(partition["author_open"]) != author_open:
        _fail("T1_AUTHORITY_PARTITION_MISMATCH", "author_open differs from B0")
    if set(partition["autonomous_owned"]) != set(owned_entities) | set(decisions):
        _fail("T1_AUTHORITY_PARTITION_MISMATCH", "T1 owned set is not exact")
    if set(partition["downstream_freedom"]) != actor_slots:
        _fail("T1_AUTHORITY_PARTITION_MISMATCH", "T1 handoff set is not exact")
    for decision in decisions.values():
        if (
            decision["owner"] != "T1"
            or decision["selection"] not in decision["options"]
            or not set(decision["projection_ids"]).issubset(owned_entities)
        ):
            _fail("T1_DECISION_INVALID", decision["id"])
    for claim in model["derivation_claims"]:
        if len(claim["projection_ids"]) == 1:
            projection = owned_entities.get(claim["projection_ids"][0])
            if projection is None or claim["value_sha256"] != rt.canonical_sha256(
                projection
            ):
                _fail("T1_DERIVATION_STALE", claim["id"])
    claimed = {
        item["projection_ids"][0]
        for item in model["derivation_claims"]
        if len(item["projection_ids"]) == 1
    }
    if not set(events).issubset(claimed) or not set(sequences).issubset(claimed):
        _fail(
            "T1_DERIVATION_INCOMPLETE",
            "each event and storyline sequence needs derivation evidence",
        )
    actual_open = {
        source_id
        for item in model["open_items"]
        for source_id in item["source_ids"]
    }
    if actual_open != author_open:
        _fail("T1_OPEN_ITEMS_MISMATCH", "author-open controls changed")
    if expected_gate is not None and model["input_gate"] != expected_gate:
        _fail("T1_GATE_REFERENCE_MISMATCH", "model gate is not stored gate")
    if expected_sources is not None and model["source_artifacts"] != list(
        expected_sources
    ):
        _fail(
            "T1_SOURCE_ARTIFACT_MISMATCH",
            "model does not bind exact B0/S1/W1/E1 sources",
        )


def start_t1_session(
    workspace: str | Path,
    *,
    baseline_package: str | Path,
    storyline_package: str | Path,
    world_package: str | Path,
    environment_package: str | Path,
    input_gate: Any,
    runtime: Any | None = None,
) -> dict[str, Any]:
    root = Path(workspace).resolve()
    if root.exists():
        _fail("T1_SESSION_EXISTS", str(root))
    thread_id = os.environ.get("CODEX_THREAD_ID", "").strip()
    if not thread_id:
        _fail("T1_THREAD_REQUIRED", "CODEX_THREAD_ID is required")
    contract_runtime = runtime or rt.ContractRuntime()
    (
        b0_root,
        s1_root,
        w1_root,
        e1_root,
        baseline,
        storyline,
        world,
        environment,
        controls,
        b0_ref,
        s1_ref,
        w1_ref,
        e1_ref,
    ) = _session_context(
        baseline_package=baseline_package,
        storyline_package=storyline_package,
        world_package=world_package,
        environment_package=environment_package,
        input_gate=input_gate,
        runtime=contract_runtime,
    )
    session = {
        "schema_version": "2.0",
        "run_id": baseline["run_id"],
        "stage": "T1",
        "session_id": _session_id(
            thread_id, input_gate.reference, b0_ref, s1_ref, w1_ref, e1_ref
        ),
        "thread_id": thread_id,
        "input_gate": copy.deepcopy(input_gate.reference),
        "state_before": copy.deepcopy(input_gate.data["run_state"]),
        "baseline_completion": b0_ref,
        "upstream_completions": [s1_ref, w1_ref, e1_ref],
        "source_artifacts": _source_artifacts(
            b0_root, s1_root, w1_root, e1_root
        ),
        "control_bindings": _control_bindings(controls),
        "storyline_bindings": _object_bindings(
            storyline["storylines"], extra="type"
        ),
        "event_requirement_bindings": _object_bindings(
            storyline["event_requirements"], extra="target_stage"
        ),
        "storyline_connection_bindings": _object_bindings(
            storyline["connections"], extra="type"
        ),
        "storyline_state_bindings": [
            {
                "id": item["id"],
                "value_sha256": rt.canonical_sha256(
                    [
                        item["start_state"],
                        *item["state_changes"],
                        item["end_state"],
                    ]
                ),
            }
            for item in storyline["storylines"]
        ],
        "world_rule_bindings": _object_bindings(
            [
                *world["world_facts"],
                *world["systems"],
                *world["institutions"],
                *world["resource_flows"],
                *world["authority_flows"],
            ]
        ),
        "environment_bindings": _object_bindings(
            environment["environments"]
        ),
        "affordance_bindings": _object_bindings(
            environment["event_affordance_catalog"]
        ),
        "phases": list(PHASES),
    }
    root.mkdir(parents=True)
    _write(root / "generation-session.json", session)
    return copy.deepcopy(session)


def _validated_session(
    workspace: Path,
    *,
    baseline_package: str | Path,
    storyline_package: str | Path,
    world_package: str | Path,
    environment_package: str | Path,
    input_gate: Any,
    runtime: Any,
    full_validation: bool = True,
) -> tuple[
    dict[str, Any],
    dict[str, Any],
    dict[str, Any],
    dict[str, Any],
    dict[str, Any],
    list[dict[str, Any]],
]:
    session = _read(workspace / "generation-session.json", "T1_SESSION_INVALID")
    (
        b0_root,
        s1_root,
        w1_root,
        e1_root,
        baseline,
        storyline,
        world,
        environment,
        controls,
        b0_ref,
        s1_ref,
        w1_ref,
        e1_ref,
    ) = _session_context(
        baseline_package=baseline_package,
        storyline_package=storyline_package,
        world_package=world_package,
        environment_package=environment_package,
        input_gate=input_gate,
        runtime=runtime,
        full_validation=full_validation,
    )
    thread_id = os.environ.get("CODEX_THREAD_ID", "").strip()
    expected = {
        "schema_version": "2.0",
        "run_id": baseline["run_id"],
        "stage": "T1",
        "session_id": _session_id(
            thread_id, input_gate.reference, b0_ref, s1_ref, w1_ref, e1_ref
        ),
        "thread_id": thread_id,
        "input_gate": copy.deepcopy(input_gate.reference),
        "state_before": copy.deepcopy(input_gate.data["run_state"]),
        "baseline_completion": b0_ref,
        "upstream_completions": [s1_ref, w1_ref, e1_ref],
        "source_artifacts": _source_artifacts(
            b0_root, s1_root, w1_root, e1_root
        ),
        "control_bindings": _control_bindings(controls),
        "storyline_bindings": _object_bindings(
            storyline["storylines"], extra="type"
        ),
        "event_requirement_bindings": _object_bindings(
            storyline["event_requirements"], extra="target_stage"
        ),
        "storyline_connection_bindings": _object_bindings(
            storyline["connections"], extra="type"
        ),
        "storyline_state_bindings": [
            {
                "id": item["id"],
                "value_sha256": rt.canonical_sha256(
                    [
                        item["start_state"],
                        *item["state_changes"],
                        item["end_state"],
                    ]
                ),
            }
            for item in storyline["storylines"]
        ],
        "world_rule_bindings": _object_bindings(
            [
                *world["world_facts"],
                *world["systems"],
                *world["institutions"],
                *world["resource_flows"],
                *world["authority_flows"],
            ]
        ),
        "environment_bindings": _object_bindings(
            environment["environments"]
        ),
        "affordance_bindings": _object_bindings(
            environment["event_affordance_catalog"]
        ),
        "phases": list(PHASES),
    }
    if not thread_id or session != expected:
        _fail(
            "T1_SESSION_INVALID",
            "session no longer binds B0/S1/W1/E1/gate/thread",
        )
    return session, baseline, storyline, world, environment, controls


def submit_t1_phase(
    workspace: str | Path,
    *,
    baseline_package: str | Path,
    storyline_package: str | Path,
    world_package: str | Path,
    environment_package: str | Path,
    input_gate: Any,
    phase: str,
    payload: Mapping[str, Any],
    runtime: Any | None = None,
) -> dict[str, str]:
    root = Path(workspace).resolve()
    contract_runtime = runtime or rt.ContractRuntime()
    session, baseline, storyline, world, environment, controls = _validated_session(
        root,
        baseline_package=baseline_package,
        storyline_package=storyline_package,
        world_package=world_package,
        environment_package=environment_package,
        input_gate=input_gate,
        runtime=contract_runtime,
        full_validation=False,
    )
    completed: list[str] = []
    for index, item in enumerate(PHASES, 1):
        if (
            root / "generation-evidence" / f"{index:02d}-{item}.json"
        ).is_file():
            completed.append(item)
        else:
            break
    if len(completed) >= len(PHASES):
        _fail("T1_PHASE_ORDER_INVALID", "all phases already sealed")
    if phase not in PHASES or phase != PHASES[len(completed)]:
        _fail("T1_PHASE_ORDER_INVALID", f"next phase is {PHASES[len(completed)]}")
    body = copy.deepcopy(dict(payload))
    if set(body) != set(PHASE_FIELDS[phase]):
        _fail(
            "T1_PHASE_PAYLOAD_INVALID",
            f"{phase} must contain exactly {list(PHASE_FIELDS[phase])}",
        )
    if phase == "final-event-model":
        model = body.get("model")
        if not isinstance(model, Mapping):
            _fail("T1_PHASE_PAYLOAD_INVALID", "final model missing")
        _validate_model(
            model,
            baseline,
            storyline,
            world,
            environment,
            controls,
            contract_runtime,
            expected_gate=input_gate.reference,
            expected_sources=session["source_artifacts"],
        )
    previous = None
    if completed:
        previous = rt.sha256_file(
            root
            / "generation-evidence"
            / f"{len(completed):02d}-{completed[-1]}.json"
        )
    evidence = {
        "schema_version": "2.0",
        **{
            key: copy.deepcopy(session[key])
            for key in (
                "run_id",
                "session_id",
                "thread_id",
                "input_gate",
                "state_before",
                "baseline_completion",
                "upstream_completions",
                "source_artifacts",
                "control_bindings",
                "storyline_bindings",
                "event_requirement_bindings",
                "storyline_connection_bindings",
                "storyline_state_bindings",
                "world_rule_bindings",
                "environment_bindings",
                "affordance_bindings",
            )
        },
        "stage": "T1",
        "phase": phase,
        "sequence": len(completed) + 1,
        "previous_evidence_sha256": previous,
        "payload": body,
        "payload_sha256": rt.canonical_sha256(body),
    }
    path = (
        root
        / "generation-evidence"
        / f"{len(completed)+1:02d}-{phase}.json"
    )
    _write(path, evidence)
    return rt.artifact_reference(path, root=root)


def _validate_phase_chain(
    evidence_root: Path,
    *,
    session: Mapping[str, Any],
    model: Mapping[str, Any],
) -> list[Path]:
    paths: list[Path] = []
    previous = None
    shared = (
        "run_id",
        "session_id",
        "thread_id",
        "input_gate",
        "state_before",
        "baseline_completion",
        "upstream_completions",
        "source_artifacts",
        "control_bindings",
        "storyline_bindings",
        "event_requirement_bindings",
        "storyline_connection_bindings",
        "storyline_state_bindings",
        "world_rule_bindings",
        "environment_bindings",
        "affordance_bindings",
    )
    for index, phase in enumerate(PHASES, 1):
        path = evidence_root / f"{index:02d}-{phase}.json"
        evidence = _read(path, "T1_EVIDENCE_MISSING")
        payload = evidence.get("payload")
        if not isinstance(payload, Mapping):
            _fail("T1_EVIDENCE_INVALID", phase)
        expected = {
            "schema_version": "2.0",
            **{key: copy.deepcopy(session[key]) for key in shared},
            "stage": "T1",
            "phase": phase,
            "sequence": index,
            "previous_evidence_sha256": previous,
            "payload": dict(payload),
            "payload_sha256": rt.canonical_sha256(payload),
        }
        if evidence != expected or set(payload) != set(PHASE_FIELDS[phase]):
            _fail("T1_EVIDENCE_INVALID", phase)
        if phase == "final-event-model":
            if payload["model"] != model:
                _fail("T1_EVIDENCE_MODEL_MISMATCH", phase)
        else:
            for field in PHASE_FIELDS[phase]:
                if payload[field] != model[field]:
                    _fail("T1_EVIDENCE_MODEL_MISMATCH", f"{phase}.{field}")
        previous = rt.sha256_file(path)
        paths.append(path)
    return paths


def _validation(run_id: str) -> dict[str, Any]:
    return {
        "schema_version": "2.0",
        "run_id": run_id,
        "stage": "T1",
        "verdict": "ready",
        "checks": [
            "schema",
            "B0/S1/W1/E1/gate-lineage",
            "event-demand-exact-projection",
            "storyline-chain-and-state-closure",
            "causal-DAG-and-world-time-closure",
            "connection-and-timing-closure",
            "environment-affordance-closure",
            "state-resource-authority-information-ledgers",
            "downstream-boundary",
            "completion-binding",
        ],
        "errors": [],
    }


def _check_package_boundary(root: Path) -> None:
    allowed_evidence = {
        f"generation-evidence/{index:02d}-{phase}.json"
        for index, phase in enumerate(PHASES, 1)
    }
    allowed_implementation = {
        f"implementation/{identity}"
        for identity in _implementation_paths()
    }
    for path in root.rglob("*"):
        if not path.is_file():
            continue
        relative = path.relative_to(root).as_posix()
        if relative in _ALLOWED_ROOT_FILES:
            continue
        if relative in allowed_evidence or relative in allowed_implementation:
            continue
        if any(relative.startswith(prefix) for prefix in _ALLOWED_SOURCE_PREFIXES):
            continue
        _fail("T1_BOUNDARY_VIOLATION", relative)


def validate_t1_package(
    package_root: str | Path,
    *,
    runtime: Any | None = None,
    require_completion: bool = True,
) -> dict[str, Any]:
    root = Path(package_root).resolve()
    contract_runtime = runtime or rt.ContractRuntime()
    _check_package_boundary(root)
    model = _read(root / "event-timeline.json", "T1_MODEL_MISSING")
    manifest = _read(root / "package-manifest.json", "T1_MANIFEST_INVALID")
    stored = _read(root / "validation.json", "T1_VALIDATION_MISSING")
    try:
        contract_runtime.validate(manifest, "package-manifest.schema.json")
        rt.verify_manifest_integrity(manifest, root=root)
    except Exception as error:
        _fail("T1_MANIFEST_INVALID", str(error))
    b0 = root / "sources" / "B0"
    s1 = root / "sources" / "S1"
    w1 = root / "sources" / "W1"
    e1 = root / "sources" / "E1"
    try:
        rt.validate_baseline_package(b0, runtime=contract_runtime)
        s1_runtime.validate_s1_package(s1, runtime=contract_runtime)
        w1_runtime.validate_w1_package(w1, runtime=contract_runtime)
        e1_runtime.validate_e1_package(e1, runtime=contract_runtime)
    except Exception as error:
        _fail("T1_UPSTREAM_INVALID", str(error))
    baseline = _read(b0 / "author-control-baseline.json", "T1_B0_INVALID")
    storyline = _read(s1 / "storyline-architecture.json", "T1_S1_INVALID")
    world = _read(w1 / "world-model.json", "T1_W1_INVALID")
    environment = _read(e1 / "environment-system.json", "T1_E1_INVALID")
    controls = _controls(b0, baseline)
    gate = _read(root / "input-gate.json", "T1_GATE_MISSING")
    try:
        contract_runtime.validate(gate, "input-gate.schema.json")
    except Exception as error:
        _fail("T1_GATE_INVALID", str(error))
    gate_ref = {
        "path": model["input_gate"]["path"],
        "sha256": rt.sha256_file(root / "input-gate.json"),
    }
    if not gate_ref["path"].endswith("/input-gate.json"):
        _fail("T1_GATE_REFERENCE_MISMATCH", "gate path not package-qualified")
    b0_ref = _stage_reference(b0, "B0")
    s1_ref = _stage_reference(s1, "S1")
    w1_ref = _stage_reference(w1, "W1")
    e1_ref = _stage_reference(e1, "E1")
    if (
        gate.get("target_stage") != "T1"
        or gate.get("run_id") != model["run_id"]
        or gate.get("baseline_completion") != b0_ref
        or gate.get("upstream_completions") != [s1_ref, w1_ref, e1_ref]
    ):
        _fail("T1_GATE_INVALID", "stored T1 topology is invalid")
    expected_sources = _source_artifacts(b0, s1, w1, e1)
    _validate_model(
        model,
        baseline,
        storyline,
        world,
        environment,
        controls,
        contract_runtime,
        expected_gate=gate_ref,
        expected_sources=expected_sources,
    )
    if manifest["artifact_roles"]["canonical"] != rt.artifact_reference(
        root / "event-timeline.json", root=root
    ):
        _fail("T1_MANIFEST_INVALID", "canonical role is stale")
    execution = _read(root / "execution-record.json", "T1_EXECUTION_INVALID")
    if (
        execution.get("input_gate") != gate_ref
        or execution.get("baseline_completion") != b0_ref
        or execution.get("upstream_completions") != [s1_ref, w1_ref, e1_ref]
        or execution.get("output_sha256") != rt.canonical_sha256(model)
    ):
        _fail("T1_EXECUTION_INVALID", "execution lineage is stale")
    session = _read(root / "generation-session.json", "T1_SESSION_INVALID")
    thread = session.get("thread_id")
    if not isinstance(thread, str) or not thread.strip():
        _fail("T1_SESSION_INVALID", "thread is missing")
    expected_session = {
        "schema_version": "2.0",
        "run_id": model["run_id"],
        "stage": "T1",
        "session_id": _session_id(
            thread, gate_ref, b0_ref, s1_ref, w1_ref, e1_ref
        ),
        "thread_id": thread,
        "input_gate": gate_ref,
        "state_before": gate.get("run_state"),
        "baseline_completion": b0_ref,
        "upstream_completions": [s1_ref, w1_ref, e1_ref],
        "source_artifacts": expected_sources,
        "control_bindings": _control_bindings(controls),
        "storyline_bindings": _object_bindings(
            storyline["storylines"], extra="type"
        ),
        "event_requirement_bindings": _object_bindings(
            storyline["event_requirements"], extra="target_stage"
        ),
        "storyline_connection_bindings": _object_bindings(
            storyline["connections"], extra="type"
        ),
        "storyline_state_bindings": [
            {
                "id": item["id"],
                "value_sha256": rt.canonical_sha256(
                    [
                        item["start_state"],
                        *item["state_changes"],
                        item["end_state"],
                    ]
                ),
            }
            for item in storyline["storylines"]
        ],
        "world_rule_bindings": _object_bindings(
            [
                *world["world_facts"],
                *world["systems"],
                *world["institutions"],
                *world["resource_flows"],
                *world["authority_flows"],
            ]
        ),
        "environment_bindings": _object_bindings(
            environment["environments"]
        ),
        "affordance_bindings": _object_bindings(
            environment["event_affordance_catalog"]
        ),
        "phases": list(PHASES),
    }
    if session != expected_session:
        _fail("T1_SESSION_INVALID", "session differs from current inputs")
    if execution.get("session_id") != session["session_id"]:
        _fail("T1_SESSION_INVALID", "execution session differs")
    evidence_paths = _validate_phase_chain(
        root / "generation-evidence", session=session, model=model
    )
    evidence_index = _read(
        root / "generation-evidence-index.json", "T1_EVIDENCE_INVALID"
    )
    if evidence_index != {
        "schema_version": "2.0",
        "run_id": model["run_id"],
        "stage": "T1",
        "session_id": session["session_id"],
        "phases": list(PHASES),
        "evidence": [
            rt.artifact_reference(path, root=root) for path in evidence_paths
        ],
    }:
        _fail("T1_EVIDENCE_INVALID", "evidence index is stale")
    catalog = {
        item["identity"]: item["artifact"]
        for item in execution.get("implementation_catalog", [])
    }
    expected_implementation_refs = {
        rt.canonical_json(
            rt.artifact_reference(
                root / "implementation" / identity,
                root=root,
            )
        )
        for identity in _implementation_paths()
    }
    if (
        set(catalog) != set(_implementation_paths())
        or {
            rt.canonical_json(item)
            for item in execution.get("implementation", [])
        }
        != expected_implementation_refs
        or {
            rt.canonical_json(item) for item in manifest.get("implementation", [])
        }
        != expected_implementation_refs
        or {
            rt.canonical_json(item) for item in catalog.values()
        }
        != expected_implementation_refs
    ):
        _fail(
            "T1_IMPLEMENTATION_STALE",
            "implementation files, catalog, execution, and manifest differ",
        )
    for identity, current in _implementation_paths().items():
        reference = catalog.get(identity)
        if reference is None:
            _fail("T1_IMPLEMENTATION_STALE", identity)
        try:
            rt.verify_artifact_reference(reference, root=root)
        except Exception as error:
            _fail("T1_IMPLEMENTATION_STALE", str(error))
        if reference["sha256"] != rt.sha256_file(current):
            _fail("T1_IMPLEMENTATION_STALE", identity)
    if require_completion:
        completion = _read(
            root / "stage-completion.json", "T1_COMPLETION_MISSING"
        )
        try:
            contract_runtime.validate(completion, "stage-completion.schema.json")
        except Exception as error:
            _fail("T1_COMPLETION_INVALID", str(error))
        manifest_ref = completion.get("manifest")
        manifest_path = (
            manifest_ref.get("path") if isinstance(manifest_ref, Mapping) else ""
        )
        prefix = PurePosixPath(manifest_path).parent.as_posix()
        if (
            not (prefix == "T1" or prefix.startswith("T1/"))
            or completion.get("run_id") != model["run_id"]
            or completion.get("stage") != "T1"
            or completion.get("status") != "ready"
            or completion.get("session_id") != session["session_id"]
            or completion.get("manifest")
            != {
                "path": _logical(prefix, "package-manifest.json"),
                "sha256": rt.sha256_file(root / "package-manifest.json"),
            }
            or completion.get("validation")
            != {
                "path": _logical(prefix, "validation.json"),
                "sha256": rt.sha256_file(root / "validation.json"),
            }
            or completion.get("input_gate") != gate_ref
            or completion.get("state_before") != gate.get("run_state")
            or completion.get("previous_stage_completions")
            != [s1_ref, w1_ref, e1_ref]
            or completion.get("return_binding") != gate.get("return_binding")
        ):
            _fail("T1_COMPLETION_BINDING_MISMATCH", "completion lineage is stale")
    expected_validation = _validation(model["run_id"])
    if stored != expected_validation:
        _fail("T1_VALIDATION_STALE", "stored validation differs")
    return expected_validation


def run_t1(
    package_root: str | Path,
    *,
    baseline_package: str | Path,
    storyline_package: str | Path,
    world_package: str | Path,
    environment_package: str | Path,
    coordinator: Any,
    input_gate: Any,
    controlled_workspace: str | Path,
    logical_package_path: str = "T1",
    next_state_path: str,
    active_return_request: Any | None = None,
    runtime: Any | None = None,
) -> T1RunReceipt:
    destination = Path(package_root).resolve()
    if destination.exists():
        _fail("T1_OUTPUT_EXISTS", str(destination))
    if not os.environ.get("CODEX_THREAD_ID", "").strip():
        _fail("T1_THREAD_REQUIRED", "CODEX_THREAD_ID is required")
    contract_runtime = runtime or rt.ContractRuntime()
    workspace = Path(controlled_workspace).resolve()
    session, baseline, storyline, world, environment, controls = _validated_session(
        workspace,
        baseline_package=baseline_package,
        storyline_package=storyline_package,
        world_package=world_package,
        environment_package=environment_package,
        input_gate=input_gate,
        runtime=contract_runtime,
    )
    final = _read(
        workspace
        / "generation-evidence"
        / f"{len(PHASES):02d}-{PHASES[-1]}.json",
        "T1_EVIDENCE_MISSING",
    )
    payload = final.get("payload")
    if not isinstance(payload, Mapping) or not isinstance(
        payload.get("model"), Mapping
    ):
        _fail("T1_EVIDENCE_INVALID", "final model missing")
    model = copy.deepcopy(dict(payload["model"]))
    _validate_phase_chain(
        workspace / "generation-evidence", session=session, model=model
    )
    _validate_model(
        model,
        baseline,
        storyline,
        world,
        environment,
        controls,
        contract_runtime,
        expected_gate=input_gate.reference,
        expected_sources=session["source_artifacts"],
    )

    destination.parent.mkdir(parents=True, exist_ok=True)
    temp_parent = Path(
        tempfile.mkdtemp(prefix=f".{destination.name}.", dir=destination.parent)
    )
    staging = temp_parent / "package"
    staging.mkdir()
    try:
        for stage, source in (
            ("B0", Path(baseline_package).resolve()),
            ("S1", Path(storyline_package).resolve()),
            ("W1", Path(world_package).resolve()),
            ("E1", Path(environment_package).resolve()),
        ):
            shutil.copytree(source, staging / "sources" / stage)
        _write(staging / "input-gate.json", input_gate.data)
        if _source_artifacts(
            staging / "sources" / "B0",
            staging / "sources" / "S1",
            staging / "sources" / "W1",
            staging / "sources" / "E1",
        ) != session["source_artifacts"]:
            _fail("T1_SOURCE_ARTIFACT_MISMATCH", "staged inputs changed")
        _write(staging / "event-timeline.json", model)
        evidence_refs = []
        for index, phase in enumerate(PHASES, 1):
            source = (
                workspace / "generation-evidence" / f"{index:02d}-{phase}.json"
            )
            target = staging / "generation-evidence" / source.name
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(source, target)
            evidence_refs.append(rt.artifact_reference(target, root=staging))
        _write(
            staging / "generation-evidence-index.json",
            {
                "schema_version": "2.0",
                "run_id": baseline["run_id"],
                "stage": "T1",
                "session_id": session["session_id"],
                "phases": list(PHASES),
                "evidence": evidence_refs,
            },
        )
        _write(staging / "generation-session.json", session)
        implementation_refs = []
        implementation_catalog = []
        for identity, source in sorted(_implementation_paths().items()):
            target = staging / "implementation" / identity
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(source, target)
            reference = rt.artifact_reference(target, root=staging)
            implementation_refs.append(reference)
            implementation_catalog.append(
                {"identity": identity, "artifact": reference}
            )
        execution = {
            "schema_version": "2.0",
            "run_id": baseline["run_id"],
            "stage": "T1",
            "operation": "controlled-event-timeline-generation",
            "session_id": session["session_id"],
            "input_gate": copy.deepcopy(input_gate.reference),
            "baseline_completion": session["baseline_completion"],
            "upstream_completions": session["upstream_completions"],
            "implementation": implementation_refs,
            "implementation_catalog": implementation_catalog,
            "output_sha256": rt.canonical_sha256(model),
        }
        _write(staging / "execution-record.json", execution)
        (staging / "event-preview.md").write_text(
            "# Event timeline\n\n"
            + "\n".join(
                f"- **{item['id']}** {item['world_time']}: "
                f"{item['responsibility']}"
                for item in model["major_events"]
            )
            + "\n",
            encoding="utf-8",
            newline="",
        )
        validation = _validation(baseline["run_id"])
        _write(staging / "validation.json", validation)
        files = [
            rt.artifact_reference(path, root=staging)
            for path in sorted(staging.rglob("*"), key=lambda item: item.as_posix())
            if path.is_file()
        ]
        by_path = {item["path"]: item for item in files}
        manifest = {
            "schema_version": "2.0",
            "run_id": baseline["run_id"],
            "stage": "T1",
            "package_profile": "generated-model",
            "verdict": "ready",
            "files": files,
            "artifact_roles": {
                "canonical": by_path["event-timeline.json"],
                "generation_session": by_path["generation-session.json"],
                "generation_evidence_index": by_path[
                    "generation-evidence-index.json"
                ],
                "execution_record": by_path["execution-record.json"],
                "preview": by_path["event-preview.md"],
            },
            "validation": by_path["validation.json"],
            "implementation": implementation_refs,
        }
        contract_runtime.validate(manifest, "package-manifest.schema.json")
        rt.verify_manifest_integrity(manifest, root=staging)
        _write(staging / "package-manifest.json", manifest)
        validate_t1_package(
            staging, runtime=contract_runtime, require_completion=False
        )
        completion_data = {
            "schema_version": "2.0",
            "run_id": baseline["run_id"],
            "stage": "T1",
            "status": "ready",
            "session_id": session["session_id"],
            "manifest": {
                "path": _logical(logical_package_path, "package-manifest.json"),
                "sha256": rt.sha256_file(staging / "package-manifest.json"),
            },
            "validation": {
                "path": _logical(logical_package_path, "validation.json"),
                "sha256": rt.sha256_file(staging / "validation.json"),
            },
            "input_gate": copy.deepcopy(input_gate.reference),
            "state_before": copy.deepcopy(input_gate.data["run_state"]),
            "previous_stage_completions": copy.deepcopy(
                input_gate.data["upstream_completions"]
            ),
            "return_binding": copy.deepcopy(input_gate.data["return_binding"]),
        }
        contract_runtime.validate(
            completion_data, "stage-completion.schema.json"
        )
        sealed = rt.seal_stage_document(
            completion_data,
            "T1",
            _logical(logical_package_path, "stage-completion.json"),
        )
        _write(staging / "stage-completion.json", sealed.data)
        validate_t1_package(staging, runtime=contract_runtime)
        transition = coordinator.accept_stage_completion(
            gate=input_gate,
            completion=sealed,
            next_state_path=next_state_path,
            active_return_request=active_return_request,
        )
        staging.replace(destination)
    except Exception:
        shutil.rmtree(temp_parent, ignore_errors=True)
        raise
    shutil.rmtree(temp_parent, ignore_errors=True)
    return T1RunReceipt(
        package_root=destination,
        model=copy.deepcopy(model),
        manifest=copy.deepcopy(manifest),
        completion=sealed,
        transition=transition,
    )


__all__ = [
    "PHASES",
    "PHASE_FIELDS",
    "T1Error",
    "T1RunReceipt",
    "run_t1",
    "start_t1_session",
    "submit_t1_phase",
    "validate_t1_package",
]
