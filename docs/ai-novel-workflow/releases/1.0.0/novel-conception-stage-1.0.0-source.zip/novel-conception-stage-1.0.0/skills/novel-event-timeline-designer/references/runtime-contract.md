# T1 V2 runtime contract

`scripts/run_v2.py` is the sole T1 production runtime. Python may start a
controlled session, accept phase submissions, validate them, seal a package,
and finalize coordinator state. It never authors events, causal links, state
changes, or timeline semantics. Those are Agent-authored inputs.

## Exact input gate

T1 accepts only ready packages from B0, S1, W1, and E1 plus the coordinator's
exact T1 gate and pre-stage run state. `CODEX_THREAD_ID` is mandatory. The
session freezes:

- the four completion references and all twelve selected canonical,
  manifest, and completion source artifacts;
- B0 control values and hardness;
- every S1 storyline, EVD, SLC, and complete start/change/end state chain;
- W1 fact, system, institution, resource-flow, and authority-flow objects;
- every E1 environment and event affordance;
- the gate, thread, and return binding.

Any changed input, gate, state, thread, source hash, missing completion, or
non-shared lineage invalidates the session.

## Controlled Agent protocol

The Agent submits exactly five phases:

1. `event-demand-scan`: exact S1 `event_requirements`;
2. `global-timeline`: design decisions, span, four time axes, timing
   constraints;
3. `event-and-causality-model`: events, causal edges, environment placement;
4. `cross-line-state-test`: line sequences, SLC realization, state and
   information ledgers, EVD coverage, authority, derivations, open items;
5. `final-event-model`: the exact assembled canonical model.

Each evidence file binds the frozen session, phase payload hash, and preceding
evidence hash. Every earlier field must equal its final-model projection.
Backfilled evidence and a one-shot Python-generated semantic model are invalid.

## Ready guarantees

### Storyline and demand realization

- `event_demands` equals S1 `event_requirements` object-for-object.
- Every EVD appears in exactly one coverage record and only realizes events
  belonging to its S1 line.
- Every non-optional line has an ordered, recognizable responsibility chain:
  background/setup, trigger, development, turn or crisis, result, and
  aftermath. These are controlled `[RESP:...]` enum tokens, not inferred from
  prose. One event may carry adjacent compatible responsibilities, and any
  number of events may be used.
- Across a non-optional line, responsibility ranks are monotonic; a long chain
  may repeat or extend the current rank but cannot return to an earlier rank.
  Its final event contains both result and aftermath, and that same event
  performs the final transition into the S1 end state.
- Every line sequence has the exact S1 entry and exit state. Its
  `state_ledger` transitions for the storyline subject exactly implement
  `start_state -> state_changes[] -> end_state`.
- Every SLC has exactly one dedicated `connection_realization` record. Its
  `connection_id`, `relation`, `source_anchor`, and `target_anchor` equal the
  S1 canonical connection, including state index. State index `0` is the
  `before` side of the line's first transition event; index `i > 0` is the
  `after` side of transition event `i - 1`. Text equality never substitutes
  for the index, so repeated state text remains unambiguous.
- A causal SLC uses `realization_kind=causal_handoff`, names an ordered,
  continuous source-anchor-to-target-anchor `causal_edge_ids` path, and names
  `[REL:convergence]` timing constraints covering the complete path. Every
  cross-line causal edge is owned by exactly one causal SLC.
- An associative SLC uses `realization_kind=associative_alignment`, has no
  causal-edge claim and no predecessor/causal path in either direction between
  its anchors, stays outside the causal DAG, and names `[REL:association]`
  timing that contains both complete anchors.

### Event, causality, and time

- Every event has explicit preconditions, action, complication, one dominant
  before/after change, direct result, and next pressure. Placeholder
  consequences are rejected.
- `predecessor_event_ids` and causal edges are identical in both directions.
  The graph is acyclic, causal time never reverses, and every event is
  reachable from a declared root.
- A causal edge carries a strictly parsed header before its non-placeholder,
  human-readable explanation. `mechanism` begins with exact
  `[CAUSE_RESULT_SHA256:...][CAUSE_PRESSURE_SHA256:...]` hashes of the source
  EV's complete `direct_result` and `next_pressure`. `necessary_condition`
  begins with one `[PRECONDITION_SHA256:...]` hash matching one complete target
  precondition. Duplicate, missing, trailing token fragments, junk hashes, or
  empty explanations are rejected.
- Multiple roots are permitted. Each must be a background responsibility and
  have an explicit `[REL:independent-root]` or `[REL:concurrent]` explanation.
- World time uses exact `[WT:NNNNNN]` values. The span equals event min/max.
  The model declares exactly the world, background, event, and narrative
  disclosure axes. Memory, analepsis, concurrency, convergence, and association are
  represented only when used, by controlled `[REL:...]` values.

### Environment and participation

- Every event has exactly one E1 environment placement and one or more
  affordances from that same environment.
- Each affordance must serve the event's S1 line/EVD, allow the initiating
  action, and contribute all of its prerequisites to the event.
- Participants, initiator, and counter roles use only S1 slot IDs. Empty
  counter roles require an explicit `[NO_COUNTER:reason]`; T1 never creates a
  concrete character.

### State, resource, authority, and information

`event-timeline.schema.json` intentionally has one general `state_ledger`.
T1 uses the formal `subject_id` to project different change kinds:

- `[KIND:state]`: S1 storyline/slot, W1 system/fact/institution, or E1
  environment state;
- `[KIND:resource]`: a W1 `resource_flows[].id`;
- `[KIND:authority]`: a W1 `authority_flows[].id` or E1
  `access_and_authority[].id`.

The event's changed `before_state`/`after_state` key is the structure declaring
the change; no free-text keyword scan is used. It must map one-to-one to a
ledger with the same subject, values, and triggering EV. Every ledger maps
back to such an event. Repeated transitions for one subject must be continuous.
Resources and authority are not fabricated for events that do not change them.
Every `allowed_by_ids` item must also be an applicable provider, not merely a
known object ID: a W1 rule applicable to an event line; a W1 system or
institution assigned to an event line; an E1 access assignment for the event
environment; the event's placed affordance; or an E1 transition contract for
that environment triggered by a placed affordance. SLOT, SL, ENV, flow objects,
and providers belonging to another line/environment are rejected.

Positive resource example: an event changes key `RF-001` from `available` to
`committed`, and one `[KIND:resource]` ledger for subject `RF-001` carries the
same values and EV trigger. Negative example: changing `RF-001` without that
ledger, or labelling it `[KIND:state]`, is rejected.

Positive authority example: an event changes key `AA-001` from `withheld` to
`granted`, and one `[KIND:authority]` ledger for the formal E1 access object
matches it. Negative example: an authority ledger whose subject is not a
formal W1/E1 authority object, or that has no matching event key, is rejected.

Information changes are optional unless claimed. An EV's
`information_changes` and the formal information records must reference each
other exactly; repeated changes for one subject must be continuous and
visibility may contain only S1 slots.

## Authority, boundary, and package

Author-locked/open sets equal B0. T1 owns the ID-bearing event model and
decisions; downstream freedom is exactly the S1 slot set. Events and sequences
have current derivation hashes.

The four local authority classes are pairwise-disjoint. Any overlap is rejected
before deeper semantic validation; each class must then equal its exact B0,
T1-owned, or S1-slot source set.

T1 does not change storylines, world rules, or environments; create CHR
identities; write psychology, dialogue, scene prose, chapter plans, or finished
fiction. The exact package allowlist contains only the nine formal T1 root
artifacts, five named evidence files, the exact implementation catalog, and
the unmodified formal B0/S1/W1/E1 source trees. `validate_t1_package()` is
read-only and recomputes schema, semantics, evidence, implementation, manifest,
completion, and coordinator lineage.
