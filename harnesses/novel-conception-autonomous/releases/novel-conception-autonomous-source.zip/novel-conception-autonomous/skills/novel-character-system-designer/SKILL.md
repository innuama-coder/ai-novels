---
name: novel-character-system-designer
description: 根据冻结的故事线、世界、环境和事件模型解析角色槽，定义人物责任、目标、边界、能动选择、信息限制、人物弧与核心人物三层关系网络。用于自主构思 V2 的 C1 阶段；不修改上游模型，不开发场景、章节、正文或完整人物传记。
---

# 小说角色系统设计

## 目标

让每条故事线、每个事件与每项终局后果都有可信人物承担，并形成可供后续小说开发使用、同时受上游事实约束的角色系统。

## 输入

仅接受同一 run 的当前：

- B0 作者控制基线；
- S1 故事线架构；
- W1 世界模型；
- E1 环境系统；
- T1 事件时间线；
- C1 input gate 与执行前 run-state。

必须先完整读取
[运行契约](references/runtime-contract.md) 和
[C1 schema](../../docs/ai-novel-workflow/contracts/autonomous-v2/character-system.schema.json)。

## 职责

1. 原样消费 S1 `character_requirements`。
2. 将全部 S1/T1 角色槽精确解析为人物；仅在职责兼容且有明确设计决定时合并槽。
3. 为人物定义故事责任、目标、价值、盲点、硬边界、能力、权限、信息限制、压力行为、可选行动、不可委托选择和弧线方向。
4. 证明每个 T1 事件的发起、参与、对抗、环境进入、权限和信息条件由人物真实承担。
5. 从决策、信息、能力、对抗、关系压力、行动和后果七个维度闭合职责。
6. 定义有事件依据的关系变化与关系杠杆。
7. 由受控 Agent 选择真正的核心人物，并为每个核心人物建立关系图最短距离为 1、2、3 的三层网络。
8. 精确覆盖全部故事线人物、事件人物和终局后果责任。
9. 用独立 `DEV-` 对象声明小说开发仍可创造的场景级表达空间；每项自由必须绑定
   canonical 人物、来源、允许变化、禁止改变和验收条件。

## 边界

- 不修改 S1 故事线、W1 世界规则、E1 环境或 T1 事件。
- 不改变事件参与槽、发起行动、可观察结果、顺序或后果。
- 不按固定职业、性别、类型或数量模板生成角色。
- 不为了“人物丰富”强迫每个人拥有关系或成长弧；结构职责足以证明其存在时即为有效人物。
- 不编写场景、章节、对白、正文、完整传记、外貌清单或口癖。
- 不把 `CHR-` 人物档案、人物弧、关系或设计决定 ID 当作开发自由；这些对象仍是
  C1 权威控制信息，终端开发自由只能使用 `DEV-` ID。
- 若冻结事件无法由可信人物完成，返回 T1 或真正的问题所有者，不在 C1 内偷偷改事件。

## 受控执行

调用 `scripts/run_v2.py`：

1. `start_c1_session(...)` 冻结输入、线程、gate 与五个阶段；
2. 受控 Agent 按顺序提交：
   `character-demand-scan`、
   `slot-resolution-and-profiles`、
   `agency-and-relationships`、
   `cross-model-cast-test`（同时提交 `development_freedoms` 与四权分区）、
   `final-character-model`；
3. `run_c1(...)` 只读取已封存的最终模型，完成验证、封包、completion 和 coordinator 状态转换。

Python 仅调度、哈希、验证和封包，不生成角色语义。

## 交付

交付 `character-system.json`、五阶段证据、session、execution record、
人读预览、validation、manifest、五个上游源包副本和 C1 completion。

只有在输入沿袭、槽解析、七类职责、人物能动性、事件可执行性、信息连续性、
关系网络、人物覆盖、作者权限、派生证据、证据链和封包完整性全部通过时，
才允许标记为 `ready`。

`ready` 还要求 `development_freedoms` 的 subject 并集精确覆盖全部 profiles，
所有 source 均解析到当前输入或 C1 canonical 对象，文本不是占位符，
`authority_partition.downstream_freedom` 精确等于 DEV ID 集，且四个权限集合
两两不相交。旧模型缺少该字段时必须失败并重新生成。
