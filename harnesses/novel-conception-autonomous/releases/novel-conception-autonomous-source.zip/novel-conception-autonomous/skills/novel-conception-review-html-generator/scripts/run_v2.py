"""Deterministic H1-C offline HTML renderer and package runtime."""

from __future__ import annotations

import copy
import html
import importlib
import json
import math
import re
import shutil
import tempfile
from dataclasses import dataclass
from html.parser import HTMLParser
from pathlib import Path
from typing import Any, Mapping, Sequence


rt = importlib.import_module("harnesses.novel-conception-autonomous.runtime")
h1a = importlib.import_module(
    "skills.novel-conception-human-review-assembler.scripts.run_v2"
)

RENDER_CONTRACT = "offline-accessible-h1-v2"
DOM_CONTRACT = "h1-html-v2"
SECTION_KINDS = ("world", "storylines", "characters", "fragments", "decision")
SEMANTIC_ROLES = tuple(h1a.VISUAL_ROLE_SPECS)
_HERE = Path(__file__).resolve()
_REPO = _HERE.parents[3]
_SKILL = _HERE.parents[1]
_SCHEMAS = _REPO / "docs" / "ai-novel-workflow" / "contracts" / "autonomous-v2"
_ROOT_FILES = {
    "human-review-report.html",
    "render-record.json",
    "validation.json",
    "package-manifest.json",
}
_ROOT_PREFIXES = ("implementation/",)
_URL_BEARING_ATTRIBUTES = {
    "action",
    "archive",
    "background",
    "cite",
    "classid",
    "codebase",
    "data",
    "dynsrc",
    "formaction",
    "icon",
    "itemid",
    "longdesc",
    "lowsrc",
    "manifest",
    "ping",
    "poster",
    "profile",
    "src",
    "srcset",
    "usemap",
    "xlink:href",
    "xmlns",
    "xmlns:xlink",
}
_CSS_URL_PATTERN = re.compile(r"(?:url\s*\(|@import\b)", re.IGNORECASE)


class H1CError(ValueError):
    def __init__(self, code: str, message: str):
        self.code = code
        super().__init__(f"{code}: {message}")


@dataclass(frozen=True)
class HtmlReceipt:
    package_root: Path
    manifest: dict[str, Any]
    transition: Any


def _fail(code: str, message: str) -> None:
    raise H1CError(code, message)


def _read(path: Path, code: str) -> dict[str, Any]:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, UnicodeError, json.JSONDecodeError) as error:
        _fail(code, f"{path}: {error}")
    if not isinstance(value, dict):
        _fail(code, f"{path} root must be an object")
    return value


def _write(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(rt.canonical_json(value), encoding="utf-8", newline="")


def _write_new(path: Path, value: Any) -> None:
    if path.exists():
        _fail("H1C_OUTPUT_EXISTS", str(path))
    _write(path, value)


def _tree_inventory(root: Path) -> list[dict[str, str]]:
    return [
        rt.artifact_reference(path, root=root)
        for path in sorted(root.rglob("*"), key=lambda item: item.as_posix())
        if path.is_file()
    ]


def _copy_exact(source: Path, target: Path) -> None:
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(source, target)
    if source.read_bytes() != target.read_bytes():
        _fail("H1C_COPY_DRIFT", str(source))


def _implementation_paths() -> dict[str, Path]:
    return {
        "skill/run_v2.py": _HERE,
        "skill/SKILL.md": _SKILL / "SKILL.md",
        "skill/v2-html-contract.md": (
            _SKILL / "references" / "v2-html-contract.md"
        ),
        "schemas/h1-review-plan.schema.json": (
            _SCHEMAS / "h1-review-plan.schema.json"
        ),
        "schemas/human-review-report.schema.json": (
            _SCHEMAS / "human-review-report.schema.json"
        ),
        "schemas/h1-workspace-state.schema.json": (
            _SCHEMAS / "h1-workspace-state.schema.json"
        ),
        "schemas/package-manifest.schema.json": (
            _SCHEMAS / "package-manifest.schema.json"
        ),
    }


def _e(value: Any) -> str:
    return html.escape(str(value), quote=True)


def _attr(value: Any) -> str:
    return _e(value)


def _encoded_ids(values: Sequence[str]) -> str:
    return json.dumps(
        list(values),
        ensure_ascii=False,
        separators=(",", ":"),
    )


def _list(items: Sequence[Any], css: str = "compact") -> str:
    return (
        f'<ul class="{css}">'
        + "".join(f"<li>{_e(item)}</li>" for item in items)
        + "</ul>"
    )


def _sources(items: Sequence[str]) -> str:
    return (
        '<p class="sources"><strong>来源：</strong>'
        + " · ".join(_e(item) for item in items)
        + "</p>"
    )


def _control_card(item: Mapping[str, Any]) -> str:
    return (
        f'<article class="control-card" data-element-id="{_attr(item["id"])}">'
        f'<h3>{_e(item["id"])}</h3>'
        f'<p>{_e(item["definition"])}</p>'
        f'<p><strong>职责：</strong>{_e(item["responsibility"])}</p>'
        "<h4>必须成立</h4>"
        f'{_list(item["must_hold"])}'
        "<h4>不得暗示</h4>"
        f'{_list(item["must_not_imply"])}'
        f'{_sources(item["source_ids"])}</article>'
    )


def _nullable(value: Any) -> str:
    return "不适用" if value is None else str(value)


def _visual_positions(
    visual: Mapping[str, Any],
) -> tuple[int, int, dict[str, tuple[float, float]]]:
    nodes = visual["nodes"]
    if visual["visual_kind"] == "timeline":
        groups = visual["groups"]
        lane_index = {
            group["id"]: index for index, group in enumerate(groups)
        }
        width = max(760, 180 * len(nodes) + 120)
        height = max(280, 120 * max(1, len(groups)) + 100)
        positions = {
            node["id"]: (
                110 + (node["order"] - 1) * 170,
                100 + lane_index[node["group_id"]] * 110,
            )
            for node in nodes
        }
        return width, height, positions
    columns = max(1, math.ceil(math.sqrt(len(nodes))))
    rows = math.ceil(len(nodes) / columns)
    width = max(680, columns * 220 + 100)
    height = max(260, rows * 150 + 100)
    positions = {
        node["id"]: (
            120 + ((node["order"] - 1) % columns) * 220,
            100 + ((node["order"] - 1) // columns) * 150,
        )
        for node in nodes
    }
    if visual["visual_kind"] == "flow":
        width = max(680, len(nodes) * 210 + 100)
        height = 300
        positions = {
            node["id"]: (110 + (node["order"] - 1) * 210, 145)
            for node in nodes
        }
    return width, height, positions


def render_visual(visual: Mapping[str, Any]) -> str:
    width, height, positions = _visual_positions(visual)
    marker_id = f"marker-{visual['id']}"
    groups = []
    if visual["visual_kind"] == "timeline":
        for group in visual["groups"]:
            y = 100 + (group["order"] - 1) * 110
            groups.append(
                f'<g data-group-id="{_attr(group["id"])}">'
                f"<title>{_e(group['label'])}｜{_e(group['summary'])}</title>"
                f'<line class="lane" x1="45" y1="{y}" x2="{width - 35}" y2="{y}"/>'
                f'<text x="48" y="{y - 16}">{_e(group["label"])}</text></g>'
            )
    edges = []
    for edge in visual["edges"]:
        start = positions[edge["from_node_id"]]
        end = positions[edge["to_node_id"]]
        marker = ""
        if edge["direction"] in {"directed", "bidirectional"}:
            marker += f' marker-end="url(#{_attr(marker_id)})"'
        if edge["direction"] == "bidirectional":
            marker += f' marker-start="url(#{_attr(marker_id)})"'
        edges.append(
            f'<g data-edge-id="{_attr(edge["id"])}" '
            f'data-direction="{_attr(edge["direction"])}" '
            f'data-order="{edge["order"]}">'
            f"<title>{_e(edge['relation_label'])}｜{_e(edge['summary'])}</title>"
            f'<line class="edge" x1="{start[0]}" y1="{start[1]}" '
            f'x2="{end[0]}" y2="{end[1]}"{marker}/>'
            f'<text class="edge-label" x="{(start[0] + end[0]) / 2:.1f}" '
            f'y="{(start[1] + end[1]) / 2 - 8:.1f}">'
            f'{_e(edge["relation_label"])}</text></g>'
        )
    nodes = []
    for node in visual["nodes"]:
        x, y = positions[node["id"]]
        nodes.append(
            f'<g class="node" data-node-id="{_attr(node["id"])}" '
            f'data-order="{node["order"]}" '
            f'data-group-id="{_attr(_nullable(node["group_id"]))}">'
            f"<title>{_e(node['label'])}｜{_e(node['summary'])}</title>"
            f'<rect x="{x - 75}" y="{y - 34}" width="150" height="68" rx="12"/>'
            f'<text x="{x}" y="{y - 3}" text-anchor="middle">{_e(node["label"])}</text>'
            f'<text class="small" x="{x}" y="{y + 18}" text-anchor="middle">'
            f'{_e(node["temporal_label"] or node["kind"])}</text></g>'
        )
    group_values = "".join(
        f'<li data-group-id="{_attr(item["id"])}">'
        f'#{item["order"]} {_e(item["label"])}｜{_e(item["summary"])}｜'
        f'kind={_e(item["kind"])}｜lane={_e(_nullable(item["lane"]))}｜'
        f'tier={_e(_nullable(item["tier"]))}｜'
        f'time={_e(_nullable(item["temporal_label"]))}'
        f'{_sources(item["source_ids"])}</li>'
        for item in visual["groups"]
    )
    node_values = "".join(
        f'<li data-node-id="{_attr(item["id"])}">'
        f'#{item["order"]} {_e(item["label"])}｜{_e(item["summary"])}｜'
        f'kind={_e(item["kind"])}｜group={_e(_nullable(item["group_id"]))}｜'
        f'lane={_e(_nullable(item["lane"]))}｜tier={_e(_nullable(item["tier"]))}｜'
        f'time={_e(_nullable(item["temporal_label"]))}'
        f'{_sources(item["source_ids"])}</li>'
        for item in visual["nodes"]
    )
    edge_values = "".join(
        f'<li data-edge-id="{_attr(item["id"])}">'
        f'#{item["order"]} {_e(item["from_node_id"])} '
        f'{_e(item["direction"])} {_e(item["to_node_id"])}｜'
        f'{_e(item["relation_label"])}｜{_e(item["summary"])}｜'
        f'kind={_e(item["kind"])}｜group={_e(_nullable(item["group_id"]))}｜'
        f'lane={_e(_nullable(item["lane"]))}｜tier={_e(_nullable(item["tier"]))}｜'
        f'time={_e(_nullable(item["temporal_label"]))}'
        f'{_sources(item["source_ids"])}</li>'
        for item in visual["edges"]
    )
    equivalents = "".join(
        f'<li data-text-equivalent-id="{_attr(item["id"])}">'
        f'#{item["order"]} {_e(item["text"])} '
        f'<span class="binding">[{_e(", ".join(item["element_ids"]))}]</span>'
        f'{_sources(item["source_ids"])}</li>'
        for item in visual["text_equivalents"]
    )
    return f"""
<article class="visual-card" data-element-id="{_attr(visual["id"])}"
 data-visual-id="{_attr(visual["id"])}"
 data-semantic-role="{_attr(visual["semantic_role"])}"
 data-text-equivalent-module-id="{_attr(visual["text_equivalent_module_id"])}">
  <h3>{_e(visual["title"])}</h3>
  <p>{_e(visual["review_purpose"])}</p>
  <div class="svg-scroll" tabindex="0" aria-label="{_attr(visual["title"])}图形区域">
    <svg class="semantic-visual" data-visual-id="{_attr(visual["id"])}"
      data-semantic-role="{_attr(visual["semantic_role"])}"
      data-text-equivalent-module-id="{_attr(visual["text_equivalent_module_id"])}"
      viewBox="0 0 {width} {height}" role="img"
      aria-labelledby="{_attr(visual["id"])}-title {_attr(visual["id"])}-desc">
      <title id="{_attr(visual["id"])}-title">{_e(visual["title"])}</title>
      <desc id="{_attr(visual["id"])}-desc">{_e(visual["review_purpose"])}</desc>
      <defs><marker id="{_attr(marker_id)}" markerWidth="8" markerHeight="8"
       refX="7" refY="4" orient="auto-start-reverse"><path d="M0,0 L8,4 L0,8 z"/></marker></defs>
      {''.join(groups)}{''.join(edges)}{''.join(nodes)}
    </svg>
  </div>
  <div class="visual-graph-values">
    <h4>图形逐值信息</h4>
    <p><strong>role：</strong>{_e(visual["semantic_role"])}；
       <strong>kind：</strong>{_e(visual["visual_kind"])}；
       <strong>section：</strong>{_e(visual["section_id"])}</p>
    <h5>分组</h5><ol>{group_values}</ol>
    <h5>节点</h5><ol>{node_values}</ol>
    <h5>边</h5><ol>{edge_values}</ol>
  </div>
  <div class="visual-text-equivalent"
    data-visual-id="{_attr(visual["id"])}"
    data-text-equivalent-module-id="{_attr(visual["text_equivalent_module_id"])}">
    <h4>图形文字等价</h4><ol>{equivalents}</ol>
  </div>
  {_sources(visual["source_ids"])}
</article>"""


def _render_world(report: Mapping[str, Any], visuals: Sequence[Mapping[str, Any]]) -> str:
    value = report["world"]
    return f"""
<section id="section-world" aria-labelledby="heading-world">
 <h2 id="heading-world">小说世界设定</h2>
 <p><strong>定义：</strong>{_e(value["definition"])}</p>
 <p><strong>运行逻辑：</strong>{_e(value["operating_logic"])}</p>
 {''.join(render_visual(item) for item in visuals)}
 <h3>系统</h3><div class="cards">{''.join(_control_card(item) for item in value["systems"])}</div>
 <h3>环境</h3><div class="cards">{''.join(_control_card(item) for item in value["environments"])}</div>
 <h3>事件条件</h3><div class="cards">{''.join(_control_card(item) for item in value["event_conditions"])}</div>
 <h3>约束</h3>{_list(value["constraints"])}
 <h3>边界</h3>{_list(value["boundaries"])}
 {_sources(value["source_ids"])}
</section>"""


def _render_storylines(report: Mapping[str, Any], visuals: Sequence[Mapping[str, Any]]) -> str:
    value = report["storylines"]
    return f"""
<section id="section-storylines" aria-labelledby="heading-storylines">
 <h2 id="heading-storylines">小说故事线设定</h2>
 <p><strong>故事主体：</strong>{_e(value["story_subject"])}</p>
 {''.join(render_visual(item) for item in visuals)}
 <h3>故事线</h3><div class="cards">{''.join(_control_card(item) for item in value["lines"])}</div>
 <h3>连接点</h3><div class="cards">{''.join(_control_card(item) for item in value["connections"])}</div>
 <h3>主要事件</h3><div class="cards">{''.join(_control_card(item) for item in value["major_events"])}</div>
 <p><strong>悬念、冲突与节奏：</strong>{_e(value["suspense_conflict_rhythm"])}</p>
 <h3>约束</h3>{_list(value["constraints"])}
 {_sources(value["source_ids"])}
</section>"""


def _render_characters(report: Mapping[str, Any], visuals: Sequence[Mapping[str, Any]]) -> str:
    value = report["characters"]
    return f"""
<section id="section-characters" aria-labelledby="heading-characters">
 <h2 id="heading-characters">小说人物设定</h2>
 {''.join(render_visual(item) for item in visuals)}
 <h3>核心人物</h3><div class="cards">{''.join(_control_card(item) for item in value["core_characters"])}</div>
 <h3>支持人物</h3><div class="cards">{''.join(_control_card(item) for item in value["supporting_characters"])}</div>
 <h3>关系网络</h3><div class="cards">{''.join(_control_card(item) for item in value["relationship_networks"])}</div>
 <h3>角色覆盖</h3><div class="cards">{''.join(_control_card(item) for item in value["role_coverage"])}</div>
 <h3>约束</h3>{_list(value["constraints"])}
 {_sources(value["source_ids"])}
</section>"""


def _render_fragments(report: Mapping[str, Any]) -> str:
    fragments = "".join(
        f'<article class="fragment" data-element-id="{_attr(item["id"])}">'
        f'<h3>{_e(item["title"])}</h3>'
        f'<p class="purpose">{_e(item["review_purpose"])}</p>'
        f'<p class="binding">controls={_e(", ".join(item["decision_control_ids"]))}</p>'
        f'<div class="fragment-text">{_e(item["text"]).replace(chr(10), "<br>")}</div>'
        f'{_sources(item["source_ids"])}</article>'
        for item in report["fragments"]
    )
    return (
        '<section id="section-fragments" aria-labelledby="heading-fragments">'
        '<h2 id="heading-fragments">小说片段</h2>'
        f"{fragments}</section>"
    )


def _render_decision(report: Mapping[str, Any]) -> str:
    prompts = "".join(
        f'<article class="decision-card" data-element-id="{_attr(item["id"])}">'
        f'<h3>{_e(item["question"])}</h3>'
        '<p class="pending">状态：未作选择</p>'
        f'<p><strong>允许决定：</strong>{_e(" / ".join(item["allowed_decisions"]))}</p>'
        f'{_sources(item["affected_source_ids"])}</article>'
        for item in report["decision_prompts"]
    )
    coverage = "".join(
        f"<li>{_e(item['source_id'])} → "
        f"{_e(', '.join(item['visible_element_ids']))}</li>"
        for item in report["source_coverage"]
    )
    controls = "".join(
        f'<article class="control-card" data-control-id="{_attr(item["id"])}">'
        f'<h3>{_e(item["domain"])} · {_e(item["priority"])}</h3>'
        f'<p>{_e(item["statement"])}</p>'
        f'<p><strong>Must hold:</strong> {_e(" / ".join(item["must_hold"]))}</p>'
        f'<p><strong>Must not imply:</strong> {_e(" / ".join(item["must_not_imply"]))}</p>'
        '</article>'
        for item in report["decision_controls"]
    )
    evidence = "".join(
        f'<details id="{_attr(item["id"])}" class="evidence-detail">'
        f'<summary>{_e(item["label"])} · {_e(item["stage"])} · '
        f'{_e(item["source_id"])}</summary>'
        f'<p>anchor={_e(item["source_anchor_id"])}; '
        f'pointer={_e(item["json_pointer"])}; sha256={_e(item["value_sha256"])}</p>'
        '</details>'
        for item in report["drilldown_index"]
    )
    return f"""
<section id="section-decision" aria-labelledby="heading-decision">
 <h2 id="heading-decision">作者判断</h2>
 <p>本页不记录、预选或提交决定。请在工作流中另行作出正式判断。</p>
 <p class="scope-contract">The ten-minute path is the complete decision-control surface. Full P1 evidence remains available below; source binding is provenance, not semantic equivalence.</p>
 <h3>Decision controls</h3>{controls}
 {prompts}
 <h3>来源覆盖</h3><ul>{coverage}</ul>
 <h3>Full P1 evidence</h3>{evidence}
</section>"""


CSS = """
:root{color-scheme:light;--paper:#f7f3ea;--ink:#18202a;--muted:#52606d;
--blue:#2457a7;--amber:#8a4b00;--line:#c8c1b5;--card:#fffdf8}
*{box-sizing:border-box}html{background:var(--paper);color:var(--ink);
font-family:system-ui,-apple-system,"Segoe UI","Noto Sans CJK SC",sans-serif}
body{margin:0;line-height:1.6;overflow-wrap:anywhere}a{color:var(--blue)}
.skip-link{position:absolute;left:.5rem;top:.5rem;background:#fff;padding:.6rem;
transform:translateY(-200%)}.skip-link:focus{transform:none}
header,nav,main,footer{max-width:1160px;margin:auto;padding:1rem}
header{padding-top:2rem;border-bottom:3px solid var(--ink)}h1{font-size:clamp(1.8rem,5vw,3rem)}
h2{border-top:2px solid var(--ink);padding-top:1rem}h3{margin-bottom:.35rem}
nav ol{display:grid;grid-template-columns:repeat(5,minmax(0,1fr));gap:.5rem;padding:0}
nav li{list-style:none;border:1px solid var(--line);background:var(--card);padding:.6rem}
.path-question{display:block;color:var(--muted);font-size:.88rem}.cards{display:grid;
grid-template-columns:repeat(2,minmax(0,1fr));gap:1rem}.control-card,.visual-card,
.fragment,.decision-card{background:var(--card);border:1px solid var(--line);
border-radius:12px;padding:1rem;margin:1rem 0}.compact{padding-left:1.25rem}
.evidence-detail{background:var(--card);border:1px solid var(--line);padding:.6rem 1rem;margin:.5rem 0}
.evidence-detail summary{cursor:pointer;font-weight:700}.scope-contract{border-left:4px solid var(--amber);padding-left:1rem}
.sources{font-size:.82rem;color:var(--muted)}.svg-scroll{overflow-x:auto;
border:1px solid var(--line);background:#fff;padding:.5rem}.semantic-visual{display:block;
min-width:680px;width:100%;height:auto}.semantic-visual .node rect{fill:#eef4ff;
stroke:var(--blue);stroke-width:2}.semantic-visual .edge,.semantic-visual .lane{
stroke:var(--blue);stroke-width:2;fill:none}.semantic-visual marker path{fill:var(--blue)}
.semantic-visual text{fill:var(--ink);font-size:14px}.semantic-visual .small,
.semantic-visual .edge-label{font-size:11px;fill:var(--muted)}
.visual-text-equivalent,.visual-graph-values{border-left:4px solid var(--blue);
padding-left:1rem}.binding{color:var(--muted)}.fragment-text{max-width:68ch;
font-family:serif;font-size:1.08rem;line-height:1.9}.pending{color:var(--amber);font-weight:700}
:focus-visible{outline:3px solid #d97706;outline-offset:3px}
@media(max-width:640px){header,nav,main,footer{padding:.75rem}.cards,nav ol{
grid-template-columns:1fr}.semantic-visual{min-width:680px}}
@media(prefers-reduced-motion:reduce){*,*::before,*::after{scroll-behavior:auto!important}}
@media print{html{background:#fff}body{font-size:11pt}header,nav,main,footer{
max-width:none}.control-card,.visual-card,.fragment,.decision-card{break-inside:avoid;
box-shadow:none}.svg-scroll{overflow:visible}.semantic-visual{min-width:0}}
"""

CSP = (
    "default-src 'none'; style-src 'unsafe-inline'; img-src data:; "
    "font-src 'none'; script-src 'none'; connect-src 'none'; "
    "object-src 'none'; base-uri 'none'; form-action 'none'; "
    "frame-ancestors 'none'"
)


def render_html(report: Mapping[str, Any]) -> str:
    visuals_by_section = {
        section: [
            visual
            for visual in report["visual_models"]
            if visual["section_id"]
            == next(
                item["section_id"]
                for item in report["visual_models"]
                if item["semantic_role"]
                == {
                    "world": "world_environment_map",
                    "storylines": "control_logic_chain",
                    "characters": "character_relationship_network",
                }[section]
            )
        ]
        for section in ("world", "storylines", "characters")
    }
    nav = "".join(
        f'<li><a href="#section-{_attr(step["kind"])}" '
        f'data-path-id="{_attr(step["id"])}" '
        f'data-path-kind="{_attr(step["kind"])}" '
        f'data-visible-element-ids="'
        f'{_attr(_encoded_ids(step["visible_element_ids"]))}">'
        f'<span class="path-title">'
        f'{_e(step["title"])}'
        f'<span class="path-question">{_e(step["review_question"])} · '
        f'{step["estimated_seconds"]}秒</span></span></a></li>'
        for step in report["review_path"]
    )
    return f"""<!doctype html>
<html lang="zh-CN" data-render-contract="{DOM_CONTRACT}">
<head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<meta http-equiv="Content-Security-Policy" content="{_attr(CSP)}">
<meta name="referrer" content="no-referrer">
<title>{_e(report["title"])}</title><style>{CSS}</style></head>
<body><a class="skip-link" href="#main-content">跳到主要内容</a>
<header><p>小说构思人审报告</p><h1>{_e(report["title"])}</h1>
<p>目标 {report["review_budget"]["target_minutes"]} 分钟；预计
{_e(report["review_budget"]["estimated_minutes"])} 分钟；
计量 {_e(report["review_budget"]["reading_baseline"])}</p></header>
<nav aria-label="十分钟评审路径"><ol>{nav}</ol></nav>
<main id="main-content">
{_render_world(report, visuals_by_section["world"])}
{_render_storylines(report, visuals_by_section["storylines"])}
{_render_characters(report, visuals_by_section["characters"])}
{_render_fragments(report)}
{_render_decision(report)}
</main>
<footer><p>run={_e(report["run_id"])} · session={_e(report["h1_session_id"])} ·
P1={_e(report["p1_completion"]["path"])} · {_e(report["p1_completion"]["sha256"])}</p></footer>
</body></html>"""


class _Inspector(HTMLParser):
    _VOID_TAGS = {
        "area", "base", "br", "col", "embed", "hr", "img", "input",
        "link", "meta", "param", "source", "track", "wbr",
    }

    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.ids: set[str] = set()
        self.duplicates: set[str] = set()
        self.tags: list[str] = []
        self.attrs: list[tuple[str, dict[str, str]]] = []
        self.title_text: list[str] = []
        self.h1_text: list[str] = []
        self.svg_title_text: dict[str, list[str]] = {}
        self.style_text: list[str] = []
        self._capture: str | None = None
        self._stack: list[str] = []
        self._svg_id: str | None = None
        self._in_head = False

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        values = {key: value or "" for key, value in attrs}
        self.tags.append(tag)
        self.attrs.append((tag, values))
        item_id = values.get("id")
        if item_id:
            if item_id in self.ids:
                self.duplicates.add(item_id)
            self.ids.add(item_id)
        if tag == "head":
            self._in_head = True
        if tag == "style":
            self._capture = "style"
        if tag == "svg":
            self._svg_id = values.get("data-visual-id")
        if tag == "title" and self._in_head and self._svg_id is None:
            self._capture = "document-title"
        elif tag == "title" and self._stack and self._stack[-1] == "svg":
            self._capture = f"svg-title:{self._svg_id or ''}"
            self.svg_title_text.setdefault(self._svg_id or "", [])
        elif tag == "h1":
            self._capture = "h1"
        if tag not in self._VOID_TAGS:
            self._stack.append(tag)

    def handle_endtag(self, tag: str) -> None:
        if tag in {"title", "h1", "style"}:
            self._capture = None
        if tag == "svg":
            self._svg_id = None
        if tag == "head":
            self._in_head = False
        if self._stack:
            if self._stack[-1] == tag:
                self._stack.pop()
            elif tag in self._stack:
                del self._stack[self._stack.index(tag):]

    def handle_data(self, data: str) -> None:
        if self._capture == "document-title":
            self.title_text.append(data)
        elif self._capture == "h1":
            self.h1_text.append(data)
        elif self._capture and self._capture.startswith("svg-title:"):
            visual_id = self._capture.removeprefix("svg-title:")
            self.svg_title_text[visual_id].append(data)
        elif self._capture == "style":
            self.style_text.append(data)


def validate_html_document(
    document: str, report: Mapping[str, Any]
) -> dict[str, Any]:
    inspector = _Inspector()
    try:
        inspector.feed(document)
        inspector.close()
    except Exception as error:
        _fail("H1C_HTML_INVALID", str(error))
    if inspector.duplicates:
        _fail("H1C_HTML_INVALID", f"duplicate ids: {sorted(inspector.duplicates)}")
    forbidden = {
        "script", "form", "input", "button", "select", "textarea",
        "iframe", "object", "embed", "link", "base",
    }
    if forbidden.intersection(inspector.tags):
        _fail("H1C_HTML_SECURITY_INVALID", "forbidden active element")
    for tag, attrs in inspector.attrs:
        normalized = {
            key.lower(): value for key, value in attrs.items()
        }
        if any(key.startswith("on") for key in normalized):
            _fail("H1C_HTML_SECURITY_INVALID", "inline event handler")
        if "download" in normalized:
            _fail("H1C_HTML_SECURITY_INVALID", "download attribute")
        url_attributes = _URL_BEARING_ATTRIBUTES.intersection(normalized)
        if url_attributes:
            _fail(
                "H1C_HTML_SECURITY_INVALID",
                f"forbidden URL attribute: {sorted(url_attributes)}",
            )
        if (
            tag == "meta"
            and normalized.get("http-equiv", "").strip().lower()
            == "refresh"
        ):
            _fail("H1C_HTML_SECURITY_INVALID", "meta refresh")
        if "style" in normalized:
            _fail("H1C_HTML_SECURITY_INVALID", "style attribute")
    style_text = "".join(inspector.style_text)
    if (
        inspector.tags.count("style") != 1
        or style_text != CSS
        or _CSS_URL_PATTERN.search(style_text)
    ):
        _fail("H1C_HTML_SECURITY_INVALID", "CSS URL/import")
    if "".join(inspector.title_text) != report["title"]:
        _fail("H1C_HTML_TITLE_INVALID", "document title drift")
    if "".join(inspector.h1_text) != report["title"] or inspector.tags.count("h1") != 1:
        _fail("H1C_HTML_TITLE_INVALID", "unique h1 drift")
    if (
        f'content="{_attr(CSP)}"' not in document
        or f'data-render-contract="{DOM_CONTRACT}"' not in document
        or 'lang="zh-CN"' not in document
        or 'class="skip-link"' not in document
        or document.count('class="semantic-visual"') != 5
        or document.count('class="visual-text-equivalent"') != 5
    ):
        _fail("H1C_HTML_ACCESSIBILITY_INVALID", "required shell or visuals missing")
    hrefs = [
        (tag, attrs)
        for tag, attrs in inspector.attrs
        if "href" in attrs
    ]
    if (
        len(hrefs) != len(report["review_path"]) + 1
        or hrefs[0][0] != "a"
        or "skip-link" not in hrefs[0][1].get("class", "").split()
        or hrefs[0][1]["href"] != "#main-content"
        or "main-content" not in inspector.ids
    ):
        _fail("H1C_HTML_SECURITY_INVALID", "unauthorized href")
    path_links = hrefs[1:]
    expected_path_values = [
        {
            "href": f"#section-{step['kind']}",
            "data-path-id": step["id"],
            "data-path-kind": step["kind"],
            "data-visible-element-ids": _encoded_ids(
                step["visible_element_ids"]
            ),
        }
        for step in report["review_path"]
    ]
    actual_path_values = []
    for tag, attrs in path_links:
        if tag != "a":
            _fail("H1C_HTML_SECURITY_INVALID", "href outside anchor")
        actual_path_values.append(
            {
                key: attrs.get(key)
                for key in expected_path_values[0]
            }
        )
        target = attrs["href"].removeprefix("#")
        if not attrs["href"].startswith("#") or target not in inspector.ids:
            _fail("H1C_HTML_SECURITY_INVALID", "dangling href")
    if actual_path_values != expected_path_values:
        _fail("H1C_HTML_REVIEW_PATH_INVALID", "review path drift")
    roles = [
        attrs["data-semantic-role"]
        for tag, attrs in inspector.attrs
        if tag == "svg" and "data-semantic-role" in attrs
    ]
    page_visuals = [
        visual
        for section in ("world", "storylines", "characters")
        for visual in report["visual_models"]
        if h1a.VISUAL_ROLE_SPECS[visual["semantic_role"]][0] == section
    ]
    expected_roles = [
        visual["semantic_role"] for visual in page_visuals
    ]
    if roles != expected_roles:
        _fail("H1C_HTML_VISUAL_INVALID", "visual order/role drift")
    expected_module_bindings = [
        (visual["id"], visual["text_equivalent_module_id"])
        for visual in page_visuals
    ]
    for tag, css_class in (
        ("article", "visual-card"),
        ("svg", "semantic-visual"),
        ("div", "visual-text-equivalent"),
    ):
        actual_module_bindings = [
            (
                attrs.get("data-visual-id"),
                attrs.get("data-text-equivalent-module-id"),
            )
            for item_tag, attrs in inspector.attrs
            if item_tag == tag
            and css_class in attrs.get("class", "").split()
        ]
        if actual_module_bindings != expected_module_bindings:
            _fail(
                "H1C_HTML_VISUAL_INVALID",
                f"{css_class} module binding drift",
            )
    svg_titles = {
        visual_id: "".join(parts)
        for visual_id, parts in inspector.svg_title_text.items()
    }
    if svg_titles != {
        visual["id"]: visual["title"] for visual in report["visual_models"]
    }:
        _fail("H1C_HTML_VISUAL_INVALID", "visual title drift")
    for section in SECTION_KINDS:
        if f"section-{section}" not in inspector.ids:
            _fail("H1C_HTML_CONTENT_INVALID", f"missing {section}")
    return {
        "verdict": "ready",
        "checks": [
            "exact-title-and-five-step-path",
            "complete-default-visible-content",
            "five-accessible-semantic-visuals",
            "offline-no-active-content",
            "responsive-print-and-focus-contract",
        ],
    }


def _p1_reference(root: Path) -> dict[str, str]:
    value = _read(root / "stage-completion.json", "H1C_P1_INVALID")
    if value.get("stage") != "P1" or value.get("status") != "ready":
        _fail("H1C_P1_INVALID", "P1 is not ready")
    return {
        "stage": "P1",
        "path": "P1/stage-completion.json",
        "sha256": rt.sha256_file(root / "stage-completion.json"),
    }


def _manifest_reference(root: Path, logical: str) -> dict[str, str]:
    return {
        "path": f"{logical}/package-manifest.json",
        "sha256": rt.sha256_file(root / "package-manifest.json"),
    }


def _validate_inputs(
    *,
    p1_package: str | Path,
    plan_package: str | Path,
    plan_input_gate: Any,
    plan_workspace_state: Any,
    fragment_package: str | Path,
    fragment_workspace_state: Any,
    assembly_package: str | Path,
    assembly_workspace_state: Any,
    workspace_state: Any,
    plan_logical_package_path: str,
    fragment_logical_package_path: str,
    assembly_logical_package_path: str,
    plan_active_return_request: Any | None,
    runtime: Any,
) -> dict[str, Any]:
    roots = {
        "p1": Path(p1_package).resolve(),
        "plan": Path(plan_package).resolve(),
        "fragment": Path(fragment_package).resolve(),
        "assembly": Path(assembly_package).resolve(),
    }
    before = {key: _tree_inventory(root) for key, root in roots.items()}
    try:
        result = h1a.validate_assembly_package(
            roots["assembly"],
            p1_package=roots["p1"],
            plan_package=roots["plan"],
            plan_input_gate=plan_input_gate,
            plan_workspace_state=plan_workspace_state,
            fragment_package=roots["fragment"],
            fragment_workspace_state=fragment_workspace_state,
            workspace_state=assembly_workspace_state,
            plan_logical_package_path=plan_logical_package_path,
            fragment_logical_package_path=fragment_logical_package_path,
            plan_active_return_request=plan_active_return_request,
            runtime=runtime,
        )
    except Exception as error:
        _fail("H1C_UPSTREAM_INVALID", str(error))
    if not isinstance(result, Mapping) or result.get("verdict") != "ready":
        _fail("H1C_UPSTREAM_INVALID", "H1-A assembly is not ready")
    p1_ref = _p1_reference(roots["p1"])
    plan_ref = _manifest_reference(roots["plan"], plan_logical_package_path)
    fragment_ref = _manifest_reference(
        roots["fragment"], fragment_logical_package_path
    )
    assembly_ref = _manifest_reference(
        roots["assembly"], assembly_logical_package_path
    )
    try:
        runtime.validate(workspace_state.data, "h1-workspace-state.schema.json")
    except Exception as error:
        _fail("H1C_WORKSPACE_INVALID", str(error))
    state = workspace_state.data
    if (
        state.get("state") != "assembled"
        or state.get("p1_completion") != p1_ref
        or state.get("previous_state_sha256")
        != assembly_workspace_state.reference.get("sha256")
        or state.get("artifacts")
        != {
            "plan_manifest": plan_ref,
            "fragment_manifest": fragment_ref,
            "assembly_manifest": assembly_ref,
        }
        or rt.canonical_sha256(state)
        != workspace_state.reference.get("sha256")
    ):
        _fail("H1C_WORKSPACE_INVALID", "current workspace is not exact assembled state")
    plan = _read(roots["plan"] / "review-plan.json", "H1C_PLAN_INVALID")
    report = _read(
        roots["assembly"] / "human-review-report.json",
        "H1C_REPORT_INVALID",
    )
    try:
        runtime.validate(report, "human-review-report.schema.json")
    except Exception as error:
        _fail("H1C_REPORT_INVALID", str(error))
    if (
        state.get("run_id") != report.get("run_id")
        or state.get("session_id") != report.get("h1_session_id")
        or plan.get("run_id") != report.get("run_id")
        or plan.get("h1_session_id") != report.get("h1_session_id")
        or report["review_budget"]["estimated_minutes"]
        > report["review_budget"]["target_minutes"]
        or before != {key: _tree_inventory(root) for key, root in roots.items()}
    ):
        _fail("H1C_INPUT_LINEAGE_INVALID", "run/session/budget/TOCTOU mismatch")
    return {
        "roots": roots,
        "inventory": before,
        "report": report,
        "p1_completion": p1_ref,
        "plan_manifest": plan_ref,
        "fragment_manifest": fragment_ref,
        "assembly_manifest": assembly_ref,
    }


def _validation(run_id: str, session_id: str) -> dict[str, Any]:
    return {
        "schema_version": "2.0",
        "run_id": run_id,
        "stage": "H1",
        "operation": "H1-C-render",
        "session_id": session_id,
        "verdict": "ready",
        "checks": [
            "formal-H1-A-assembly-chain-validation",
            "exact-current-assembled-workspace",
            "deterministic-byte-identical-render",
            "complete-visible-report-projection",
            "offline-accessibility-security-and-print",
            "manifest-implementation-and-TOCTOU-binding",
        ],
        "errors": [],
    }


def _check_boundary(root: Path) -> None:
    for path in root.rglob("*"):
        if not path.is_file():
            continue
        relative = path.relative_to(root).as_posix()
        if relative in _ROOT_FILES or any(
            relative.startswith(prefix) for prefix in _ROOT_PREFIXES
        ):
            continue
        _fail("H1C_PACKAGE_BOUNDARY_INVALID", relative)
    if (root / "stage-completion.json").exists():
        _fail("H1C_COMPLETION_FORBIDDEN", "H1-C cannot emit completion")


def validate_html_package(
    package_root: str | Path,
    *,
    p1_package: str | Path,
    plan_package: str | Path,
    plan_input_gate: Any,
    plan_workspace_state: Any,
    fragment_package: str | Path,
    fragment_workspace_state: Any,
    assembly_package: str | Path,
    assembly_workspace_state: Any,
    workspace_state: Any,
    plan_logical_package_path: str = "H1/plan",
    fragment_logical_package_path: str = "H1/fragments",
    assembly_logical_package_path: str = "H1/assembly",
    plan_active_return_request: Any | None = None,
    runtime: Any | None = None,
) -> dict[str, Any]:
    root = Path(package_root).resolve()
    contract_runtime = runtime or rt.ContractRuntime()
    _check_boundary(root)
    upstream = _validate_inputs(
        p1_package=p1_package,
        plan_package=plan_package,
        plan_input_gate=plan_input_gate,
        plan_workspace_state=plan_workspace_state,
        fragment_package=fragment_package,
        fragment_workspace_state=fragment_workspace_state,
        assembly_package=assembly_package,
        assembly_workspace_state=assembly_workspace_state,
        workspace_state=workspace_state,
        plan_logical_package_path=plan_logical_package_path,
        fragment_logical_package_path=fragment_logical_package_path,
        assembly_logical_package_path=assembly_logical_package_path,
        plan_active_return_request=plan_active_return_request,
        runtime=contract_runtime,
    )
    try:
        document = (root / "human-review-report.html").read_text(
            encoding="utf-8"
        )
    except (OSError, UnicodeError) as error:
        _fail("H1C_HTML_INVALID", str(error))
    if document != render_html(upstream["report"]):
        _fail("H1C_DETERMINISM_INVALID", "HTML is not current pure render")
    validate_html_document(document, upstream["report"])
    execution = _read(root / "render-record.json", "H1C_RECORD_INVALID")
    catalog = {
        item.get("identity"): item.get("artifact")
        for item in execution.get("implementation_catalog", [])
        if isinstance(item, Mapping)
    }
    if set(catalog) != set(_implementation_paths()):
        _fail("H1C_IMPLEMENTATION_STALE", "implementation catalog")
    for identity, source in _implementation_paths().items():
        copied = rt.verify_artifact_reference(catalog[identity], root=root)
        if copied.read_bytes() != source.read_bytes():
            _fail("H1C_IMPLEMENTATION_STALE", identity)
    implementation = [catalog[key] for key in sorted(catalog)]
    report_ref = {
        "path": f"{assembly_logical_package_path}/human-review-report.json",
        "sha256": rt.sha256_file(
            upstream["roots"]["assembly"] / "human-review-report.json"
        ),
    }
    html_ref = rt.artifact_reference(
        root / "human-review-report.html", root=root
    )
    expected_record = {
        "schema_version": "2.0",
        "run_id": upstream["report"]["run_id"],
        "stage": "H1",
        "operation": "H1-C-render",
        "h1_session_id": upstream["report"]["h1_session_id"],
        "render_contract": RENDER_CONTRACT,
        "workspace_state": workspace_state.reference,
        "p1_completion": upstream["p1_completion"],
        "plan_manifest": upstream["plan_manifest"],
        "fragment_manifest": upstream["fragment_manifest"],
        "assembly_manifest": upstream["assembly_manifest"],
        "input_report": report_ref,
        "outputs": {"human-review-report.html": html_ref},
        "implementation": implementation,
        "implementation_catalog": [
            {"identity": key, "artifact": catalog[key]}
            for key in sorted(catalog)
        ],
    }
    if execution != expected_record:
        _fail("H1C_RECORD_INVALID", "render record drift")
    expected_validation = _validation(
        upstream["report"]["run_id"],
        upstream["report"]["h1_session_id"],
    )
    validation = _read(root / "validation.json", "H1C_VALIDATION_INVALID")
    if validation != expected_validation:
        _fail("H1C_VALIDATION_INVALID", "validation drift")
    manifest = _read(root / "package-manifest.json", "H1C_MANIFEST_INVALID")
    try:
        contract_runtime.validate(manifest, "package-manifest.schema.json")
        rt.verify_manifest_integrity(manifest, root=root)
    except Exception as error:
        _fail("H1C_MANIFEST_INVALID", str(error))
    actual_files = [
        item
        for item in _tree_inventory(root)
        if item["path"] != "package-manifest.json"
    ]
    by_path = {item["path"]: item for item in actual_files}
    if (
        manifest.get("run_id") != upstream["report"]["run_id"]
        or manifest.get("stage") != "H1"
        or manifest.get("package_profile") != "h1-html"
        or manifest.get("verdict") != "ready"
        or manifest.get("session_id") != upstream["report"]["h1_session_id"]
        or manifest.get("parent_state_sha256")
        != workspace_state.reference["sha256"]
        or manifest.get("artifact_roles")
        != {
            "html": by_path["human-review-report.html"],
            "render_record": by_path["render-record.json"],
        }
        or manifest.get("validation") != by_path["validation.json"]
        or manifest.get("implementation") != implementation
        or manifest.get("files") != actual_files
    ):
        _fail("H1C_MANIFEST_INVALID", "manifest is not exact")
    return copy.deepcopy(validation)


def run(
    package_root: str | Path,
    *,
    p1_package: str | Path,
    plan_package: str | Path,
    plan_input_gate: Any,
    plan_workspace_state: Any,
    fragment_package: str | Path,
    fragment_workspace_state: Any,
    assembly_package: str | Path,
    assembly_workspace_state: Any,
    workspace_state: Any,
    coordinator: Any,
    logical_package_path: str = "H1/html",
    plan_logical_package_path: str = "H1/plan",
    fragment_logical_package_path: str = "H1/fragments",
    assembly_logical_package_path: str = "H1/assembly",
    plan_active_return_request: Any | None = None,
    active_return_request: Any | None = None,
    runtime: Any | None = None,
) -> HtmlReceipt:
    destination = Path(package_root).resolve()
    if destination.exists():
        _fail("H1C_OUTPUT_EXISTS", str(destination))
    contract_runtime = runtime or rt.ContractRuntime()
    upstream = _validate_inputs(
        p1_package=p1_package,
        plan_package=plan_package,
        plan_input_gate=plan_input_gate,
        plan_workspace_state=plan_workspace_state,
        fragment_package=fragment_package,
        fragment_workspace_state=fragment_workspace_state,
        assembly_package=assembly_package,
        assembly_workspace_state=assembly_workspace_state,
        workspace_state=workspace_state,
        plan_logical_package_path=plan_logical_package_path,
        fragment_logical_package_path=fragment_logical_package_path,
        assembly_logical_package_path=assembly_logical_package_path,
        plan_active_return_request=plan_active_return_request,
        runtime=contract_runtime,
    )
    document = render_html(upstream["report"])
    validate_html_document(document, upstream["report"])
    destination.parent.mkdir(parents=True, exist_ok=True)
    temp_parent = Path(
        tempfile.mkdtemp(prefix=f".{destination.name}.", dir=destination.parent)
    )
    staging = temp_parent / "package"
    staging.mkdir()
    try:
        (staging / "human-review-report.html").write_text(
            document, encoding="utf-8", newline=""
        )
        implementation: list[dict[str, str]] = []
        catalog: list[dict[str, Any]] = []
        for identity, source in sorted(_implementation_paths().items()):
            target = staging / "implementation" / identity
            _copy_exact(source, target)
            reference = rt.artifact_reference(target, root=staging)
            implementation.append(reference)
            catalog.append({"identity": identity, "artifact": reference})
        report_ref = {
            "path": f"{assembly_logical_package_path}/human-review-report.json",
            "sha256": rt.sha256_file(
                upstream["roots"]["assembly"] / "human-review-report.json"
            ),
        }
        record = {
            "schema_version": "2.0",
            "run_id": upstream["report"]["run_id"],
            "stage": "H1",
            "operation": "H1-C-render",
            "h1_session_id": upstream["report"]["h1_session_id"],
            "render_contract": RENDER_CONTRACT,
            "workspace_state": workspace_state.reference,
            "p1_completion": upstream["p1_completion"],
            "plan_manifest": upstream["plan_manifest"],
            "fragment_manifest": upstream["fragment_manifest"],
            "assembly_manifest": upstream["assembly_manifest"],
            "input_report": report_ref,
            "outputs": {
                "human-review-report.html": rt.artifact_reference(
                    staging / "human-review-report.html", root=staging
                )
            },
            "implementation": implementation,
            "implementation_catalog": catalog,
        }
        _write_new(staging / "render-record.json", record)
        _write_new(
            staging / "validation.json",
            _validation(
                upstream["report"]["run_id"],
                upstream["report"]["h1_session_id"],
            ),
        )
        files = _tree_inventory(staging)
        by_path = {item["path"]: item for item in files}
        manifest = {
            "schema_version": "2.0",
            "run_id": upstream["report"]["run_id"],
            "stage": "H1",
            "package_profile": "h1-html",
            "verdict": "ready",
            "files": files,
            "artifact_roles": {
                "html": by_path["human-review-report.html"],
                "render_record": by_path["render-record.json"],
            },
            "validation": by_path["validation.json"],
            "implementation": implementation,
            "parent_state_sha256": workspace_state.reference["sha256"],
            "session_id": upstream["report"]["h1_session_id"],
        }
        contract_runtime.validate(manifest, "package-manifest.schema.json")
        rt.verify_manifest_integrity(manifest, root=staging)
        _write_new(staging / "package-manifest.json", manifest)
        validate_html_package(
            staging,
            p1_package=p1_package,
            plan_package=plan_package,
            plan_input_gate=plan_input_gate,
            plan_workspace_state=plan_workspace_state,
            fragment_package=fragment_package,
            fragment_workspace_state=fragment_workspace_state,
            assembly_package=assembly_package,
            assembly_workspace_state=assembly_workspace_state,
            workspace_state=workspace_state,
            plan_logical_package_path=plan_logical_package_path,
            fragment_logical_package_path=fragment_logical_package_path,
            assembly_logical_package_path=assembly_logical_package_path,
            plan_active_return_request=plan_active_return_request,
            runtime=contract_runtime,
        )
        if upstream["inventory"] != {
            key: _tree_inventory(root)
            for key, root in upstream["roots"].items()
        }:
            _fail("H1C_INPUT_MUTATED", "input package changed before publish")
        staging.replace(destination)
        validate_html_package(
            destination,
            p1_package=p1_package,
            plan_package=plan_package,
            plan_input_gate=plan_input_gate,
            plan_workspace_state=plan_workspace_state,
            fragment_package=fragment_package,
            fragment_workspace_state=fragment_workspace_state,
            assembly_package=assembly_package,
            assembly_workspace_state=assembly_workspace_state,
            workspace_state=workspace_state,
            plan_logical_package_path=plan_logical_package_path,
            fragment_logical_package_path=fragment_logical_package_path,
            assembly_logical_package_path=assembly_logical_package_path,
            plan_active_return_request=plan_active_return_request,
            runtime=contract_runtime,
        )
        manifest_ref = {
            "path": f"{logical_package_path}/package-manifest.json",
            "sha256": rt.sha256_file(destination / "package-manifest.json"),
        }
        transition = coordinator.accept_h1_workspace_transition(
            current_workspace=workspace_state,
            package_manifest=rt.SealedDocument(
                data=manifest, reference=manifest_ref
            ),
            expected_next_state="rendered",
            active_return_request=active_return_request,
        )
    except Exception:
        shutil.rmtree(temp_parent, ignore_errors=True)
        raise
    shutil.rmtree(temp_parent, ignore_errors=True)
    return HtmlReceipt(
        package_root=destination,
        manifest=copy.deepcopy(manifest),
        transition=transition,
    )


__all__ = [
    "RENDER_CONTRACT",
    "DOM_CONTRACT",
    "H1CError",
    "HtmlReceipt",
    "render_visual",
    "render_html",
    "validate_html_document",
    "validate_html_package",
    "run",
]
