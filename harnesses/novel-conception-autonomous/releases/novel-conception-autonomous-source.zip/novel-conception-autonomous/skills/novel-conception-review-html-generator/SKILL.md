---
name: novel-conception-review-html-generator
description: H1-C：把已经正式验收的小说构思人审内容模型确定性渲染为离线、可访问、可打印的单文件 HTML，并将 H1 工作区从 assembled 推进到 rendered。只做忠实呈现，不改写构思，不推断新信息，也不作作者决定或阶段完成。
---

# 小说构思人审 HTML 生成

## 目标

把 H1-A 交付的 `human-review-report.json` 原样投影为人可在十分钟内检查的单文件 HTML。页面必须让世界、故事线、角色、小说片段和决策问题默认可见，并用五种固定语义图形降低关系阅读成本。

本技能是 H1-C。它只负责呈现和呈现包验收；不负责内容策划、小说片段写作、构思修订、作者选择、H1 完成或 P1 完成。

## 硬输入

一次执行必须同时收到同一 run、同一 H1 session 的：

1. 已完成的 P1 包。
2. H1-A 规划包、规划输入门、规划期 active return（如有）和规划所用的 `initialized` 工作区。
3. H1-B 片段包和片段生成所用的 `planned` 工作区。
4. H1-A 组装包和组装所用的 `fragments_ready` 工作区。
5. 当前、密封且仍为 `assembled` 的 H1 工作区。
6. H1 coordinator。

缺少任一输入、哈希不一致、跨 run/session、状态跳跃、上游包重封、当前工作区已变化或上游正式校验失败时，必须停止；不得用宽松读取或 HTML 局部修补绕过。

## 正式执行

使用 [scripts/run_v2.py](scripts/run_v2.py) 中的：

- `run(...)`：正式原子生成并申请 `assembled -> rendered`。
- `validate_html_package(...)`：独立重验既有 H1-C 包。
- `render_html(report)`：无文件写入、无网络、无推断的确定性投影。
- `validate_html_document(document, report)`：HTML 结构、安全与可访问性检查。

执行前必须正式调用 H1-A 的 `validate_assembly_package(...)`。该校验会传递重验 P1、H1-A 规划、H1-B 片段和 H1-A 组装链；H1-C 还必须独立检查当前 assembled 工作区及输入树 TOCTOU。

## 呈现硬约束

- `<title>` 与唯一 `<h1>` 必须逐字等于 `report.title`。
- 导航必须逐项、按序对应 `report.review_path`。
- 每个导航项必须以稳定、无歧义的属性逐值绑定其 `visible_element_ids`；任何合法追溯差分都必须改变 HTML。
- 世界、故事线、角色、片段、决策五部分必须默认可见，不得折叠或懒加载。
- 默认路径必须完整呈现 `decision_controls`；`critical` 控制不得只在附录出现。
- 全量 P1 evidence 必须按 `drilldown_index` 放入默认关闭、可键盘展开的
  `<details>`，逐项保留来源定位和哈希，不计入十分钟默认路径但不得遗漏。
- 页面必须明确说明来源绑定证明 provenance，不自动证明摘要与来源语义等价。
- 必须逐项呈现所有控制对象及其定义、职责、`must_hold`、`must_not_imply`、约束、边界和来源。
- 必须各呈现一次 `control_logic_chain`、`world_environment_map`、`storyline_architecture`、`major_event_timeline`、`character_relationship_network`。
- 每个图必须使用内联 SVG，保留原图模型 ID、顺序、分组、方向、标签和来源，并紧邻完整文字等价物。
- 图卡、SVG 和文字等价容器必须分别逐图绑定同一个 `text_equivalent_module_id`，不得遗漏仅用于追溯的合法字段。
- 不得使用 NLP、关键词猜测、重新排序或 P1 反向推断来生成页面内容。
- 页面必须为 UTF-8、离线、安全、可键盘访问、可回流、可打印；禁止脚本、表单、外链、下载、meta refresh、URL-bearing 属性、CSS URL/import、存储、网络访问和预选作者决定。只允许生成器定义的同页 skip-link 与五个精确导航锚点。

## 交付

只允许交付：

- `human-review-report.html`
- `render-record.json`
- `validation.json`
- `package-manifest.json`
- `implementation/` 下的精确实现快照

发布必须先在同父目录暂存、完整复验，再原子改名。成功后只允许 coordinator 接受一次 `assembled -> rendered`。不得生成 `stage-completion.json`，不得宣称 H1 或构思阶段完成。

把 current rendered workspace 与 H1-C sealed manifest 移交 workflow 的正式
H1 completion runtime；不得在本技能中替代该重验和顶层状态转换。

## 验收

验收必须重新调用 `render_html(report)` 并要求 HTML 字节完全一致，同时核对：

- 四个上游包、五个相关工作区/门以及 run/session 血缘；
- 当前 assembled 状态及父状态哈希；
- HTML 标题、导航、五部分、五图、文字等价物和全部来源绑定；
- CSP、无活动内容、唯一 ID、焦点、回流和打印契约；
- render record、validation、manifest、实现快照和输入树 TOCTOU；
- 包边界及无阶段完成文件。

完整字段、错误语义和 API 见 [references/v2-html-contract.md](references/v2-html-contract.md)。旧 `scripts/render_review_html.py`、`scripts/validate_review_html.py` 与其旧 references 仅供 1.x 兼容，不构成 V2 准入或完成依据。
