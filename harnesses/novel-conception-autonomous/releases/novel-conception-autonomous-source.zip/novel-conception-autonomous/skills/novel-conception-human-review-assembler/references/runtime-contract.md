# H1-A V2 runtime contract

`scripts/run_v2.py` is the sole H1-A production runtime. The Agent authors the
five ordered review-plan phase submissions. Python validates, seals, publishes,
and coordinates state; it does not invent review semantics or rewrite P1.

## Exact production sequence

1. Start from the current validator-ready P1 package, its exact H1 input gate,
   and an `initialized` workspace bound to the same run and P1 completion.
2. Call `run_plan()` once with exactly the five `PLAN_PHASES` submissions and
   `work_title`. It validates the complete plan, publishes the immutable plan
   package, and requests the `initialized -> planned` transition.
3. Let `novel-conception-fragment-writer` consume that exact published plan and
   `planned` workspace. It must publish a ready fragment package and produce the
   corresponding `fragments_ready` workspace in the same H1 session.
4. Call `run_assemble()` once with the exact P1, plan package, plan gate,
   `planned` workspace, fragment package, `fragments_ready` workspace, and the
   coordinator-issued assembly workspace. It formally revalidates both
   upstream packages, deterministically assembles the report, publishes it,
   and requests the `fragments_ready -> assembled` transition.

`run_plan()` and `run_assemble()` are the only production entry points owned by
H1-A. The other scripts in this skill and `validate_plan_package()` /
`validate_assembly_package()` are diagnostic or read-only validation surfaces;
they cannot independently prove H1-A execution.

## Hard prohibitions

- Do not handwrite or edit the published plan, report, validation, manifest, or
  workspace transition.
- Do not substitute the old R1/D1 report scripts or an old H1 plan.
- Do not call assemble before a formally ready H1-B package exists.
- Do not mix run IDs, H1 session IDs, P1 completions, gates, workspace states,
  active returns, logical package paths, or package manifests.
- Do not treat an H1-A package as the top-level H1 completion or author approval.

Any changed P1, plan, fragment package, gate, workspace, return, or coordinator
state invalidates the current operation and requires the owning stage to rerun.
