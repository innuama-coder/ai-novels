---
name: novel-conception-human-review-assembler
description: 基于自主构思 V2 的 P1 机器交付，设计十分钟人审计划，并将同一 H1 会话的已验收小说片段确定性组装为 JSON 与 Markdown 人审报告。
---

# 小说构思人审内容设计与组装

## 目标

让作者在十分钟内沿“世界—故事线—角色—片段—决定”路径检查完整构思，
最后只能选择 `approved / revise / rejected`，不得预选。

## 唯一生产运行路径

完整读取 [H1-A 唯一运行契约](references/runtime-contract.md)。只允许通过
`scripts/run_v2.py` 的 `run_plan()` 发布计划，再由正式 H1-B 生成并验收片段，
最后通过同一脚本的 `run_assemble()` 组装报告。不得把其他脚本、单独 validator、
手写文件或旧 R1/D1/H1 包当作正式 H1-A 执行。`validate_plan_package()` 与
`validate_assembly_package()` 只用于只读复验，不能替代生产调用。

## 输入

`plan` 入口只接收当前、validator-ready 的 P1 包、H1 input gate、项目展示元数据
`work_title`，以及与 P1 completion 精确绑定的 `initialized` workspace。
`work_title` 不是构思事实；运行时把它固化为与 input gate 绑定的
`work_identity`，并唯一生成 `《{work_title}》小说构思人审报告`。不得让 Agent
自由改写标题，也不得从目录、文件名或构思摘要猜测标题。

`assemble` 入口只接收同一 run/session 的：

- 已发布并可复验的 H1-A plan 包；
- H1-B 实际消费的 `planned` workspace；
- `fragments_ready` workspace；
- H1-B fragment 包。

## Plan 职责

Agent 必须按固定顺序完成五阶段：

1. `review-task-analysis`
2. `information-architecture`
3. `visual-and-fragment-plan`
4. `ten-minute-budget-test`
5. `final-review-plan`

第三阶段必须显式给出 `assembly_projection`。它为世界、故事线、角色报告中的
每个字段指定同板块 module id。控制数组必须无重叠地
覆盖该板块全部 module；Python 仅按投影复制字段，不推断分类、不补写内容。

第三阶段还必须恰好给出五个通用 attributed graph，每个 semantic role 各一个：

1. `control_logic_chain`：storylines / flow；
2. `world_environment_map`：world / map；
3. `storyline_architecture`：storylines / flow；
4. `major_event_timeline`：storylines / timeline；
5. `character_relationship_network`：characters / network。

每图显式提交有序 group、node、edge、逐图元 P1 source anchors 和完整文字等价
绑定。运行时只检查 schema、唯一 ID、连续顺序、端点/分组闭合、role 映射、
source/hash/coverage，不替 Agent 从自然语言推断关系。仅 major event timeline
强制 lane/group 和 temporal label；其他图允许单节点、零边，唯
`control_logic_chain` 至少两个节点和一条边。

同一阶段还必须显式给出 `decision_prompts` 与
`presentation_bindings`。bindings 按展示顺序精确覆盖全部
module/visual/brief/prompt，保存完整元素内容哈希、每个 source anchor 对应的
冻结 P1 value 哈希、`must_not_imply` 和 challenge 结果；final plan 必须逐值
一致。Python 只重算验证，不能替 Agent 生成或选择 binding。

每个 fragment brief 还必须由 Agent 显式定义固定简体中文、固定评审文风、
第三人称受限视角、信息可知与禁知边界、允许感知通道、场景前后状态及
压力—阻碍—选择—后果契约、决定性内心活动限制和非权威表面细节策略。
这些字段属于 H1-B 控制信息，纳入完整 brief 内容哈希，但不计入作者默认阅读预算。

唯一计划文件名是 `review-plan.json`。默认可见路径必须恰为三个板块、片段、
决定五步，总预算不超过 600 秒。十分钟的“完整”严格指有限的
`decision_controls` 决策控制面，不等于逐字阅读无界 P1；不得再用一个短元素批量
绑定大量 source anchors 来声称语义完整。

所有 P1 source anchor 必须在 `reduction_ledger` 中恰好归入至少一个控制项，并在
`drilldown_index` 中恰好保留一份可展开的无损定位、原值哈希和来源信息。
`critical` 控制不得只存在于 drill-down，必须由默认路径中的真实元素绑定。
来源与哈希只证明 provenance，不证明压缩文案语义等价；Agent 必须在五阶段挑战中
记录取舍、边界和不得暗示的结论。忠实决策面仍超过 600 秒时必须阻断，不得删信息。

默认可见 module、所属板块 visual、全部 fragment slot 和全部 decision prompt
共同形成唯一 registry。五步路径必须按板块精确覆盖 registry，不得出现 ghost、
漏项、重复或跨类元素。`control_coverage` 只能指向路径中真实可见且实际绑定对应
decision control 的元素；五个 `budget_items` 必须逐项绑定五个 PATH id 与相同秒数。

阅读计量固定使用 `review-reading-baseline-v1`：中文 400 字/分钟、Latin
200 词/分钟。所有默认可见 graph 标题、label、summary、kind、lane/tier/time、
edge relation 和文字等价按实际字段出现次数各计一次；每个 visual 另计 10 秒
理解开销，每个 decision prompt 另计
15 秒判断开销。片段除标题与评审用途外，按 `target_words_max` 以 Latin
词速保守计量。各 PATH 声明秒数不得低于重算值，合计仍不得超过 600 秒；
调用方不能传入或放大阅读速率。

## Assemble 职责

组装器动态调用正式 H1-B validator，传入 P1、plan、同一 sealed
`plan_input_gate`、plan 前态、H1-B 的 `planned` workspace、plan active return
request 和 fragment 包；H1-B 必须再次调用完整 formal H1-A plan validator，
不能以 plan manifest 的浅层重封检查替代。只有 H1-B 返回 `ready` 才继续。
随后校验 `fragments_ready` 前态哈希确实指向该 planned workspace，并逐项核对
片段 id、标题、评审用途和 P1 source IDs 与 brief 一致；正文只逐字复制。

组装器只按 `assembly_projection` 生成：

- `human-review-report.json`
- `human-review-report.md`
- `assembly-execution.json`
- `validation.json`
- `package-manifest.json`

发布并从目标路径复验成功后，才请求 workspace 从 `fragments_ready` 进入
`assembled`。

组装报告必须按 plan 原顺序携带 `review_path` 和五个 `visual_models`。图形字段
逐值复制，唯一转换是把每一层 `source_anchor_ids` 确定性映射为 P1
`source_ids`；缺图、改字、换序或标题漂移都由 formal validator 拒绝。
`review_scope_contract`、`decision_controls`、`reduction_ledger` 与
`drilldown_index` 必须逐值复制，H1-A 不在组装期重新概括或重分组。

## 边界与约束

- 不修改 P1、plan 或 fragment 输入。
- 不总结、改写或扩写 P1 控制信息与片段正文。
- 不生成 HTML、CSS、JavaScript 或最终 H1 completion。
- 不记录作者决定，不把技术 ready 当作作者批准。
- 不读取或回退到 R1/D1、旧版 `h1-review-plan.json`。
- coordinator 拒绝时，已发布包可作为非当前 orphan 保留，但状态不得前进。

## 规范

- [Plan schema](../../docs/ai-novel-workflow/contracts/autonomous-v2/h1-review-plan.schema.json)
- [Fragment package schema](../../docs/ai-novel-workflow/contracts/autonomous-v2/fragment-package.schema.json)
- [Report schema](../../docs/ai-novel-workflow/contracts/autonomous-v2/human-review-report.schema.json)
- [Workspace schema](../../docs/ai-novel-workflow/contracts/autonomous-v2/h1-workspace-state.schema.json)
- [详细契约](references/review-plan-contract.md)
- [唯一运行契约](references/runtime-contract.md)
