"""Production S1 runner for autonomous novel-conception V2."""

from __future__ import annotations

import copy
import importlib
import json
import os
import re
import shutil
import tempfile
from dataclasses import dataclass
from pathlib import Path, PurePosixPath
from typing import Any, Mapping, Sequence


rt = importlib.import_module("harnesses.novel-conception-autonomous.runtime")
_HERE = Path(__file__).resolve()
_REPO = _HERE.parents[3]
_SKILL = _HERE.parents[1]
_SCHEMAS = _REPO / "docs" / "ai-novel-workflow" / "contracts" / "autonomous-v2"
PHASES = (
    "demand-scan",
    "line-design",
    "topology-and-consistency",
    "downstream-requirements",
    "final-storyline-model",
)
PHASE_FIELDS = {
    "demand-scan": ("storyline_demands",),
    "line-design": ("design_decisions", "storylines"),
    "topology-and-consistency": (
        "connections",
        "architecture",
        "cross_line_consistency",
    ),
    "downstream-requirements": (
        "world_requirements",
        "environment_requirements",
        "event_requirements",
        "character_requirements",
        "coverage_ledger",
        "authority_partition",
        "derivation_claims",
        "open_items",
    ),
    "final-storyline-model": ("model",),
}
CONSISTENCY_DIMENSIONS = (
    "time",
    "causality",
    "information",
    "authority",
    "state",
    "theme",
)
_PLACEHOLDER = re.compile(
    r"(?i)(?:\b(?:tbd|todo|placeholder|lorem\s+ipsum|xxx)\b|"
    r"待定|未定义|占位)"
)


class S1Error(ValueError):
    def __init__(self, code: str, message: str):
        self.code = code
        super().__init__(f"{code}: {message}")


@dataclass(frozen=True)
class S1RunReceipt:
    package_root: Path
    model: dict[str, Any]
    manifest: dict[str, Any]
    completion: Any
    transition: Any


def _fail(code: str, message: str) -> None:
    raise S1Error(code, message)


def _validate_authority_disjoint(partition: Mapping[str, Any]) -> None:
    names = (
        "author_locked",
        "autonomous_owned",
        "downstream_freedom",
        "author_open",
    )
    values = {name: set(partition[name]) for name in names}
    for index, left in enumerate(names):
        for right in names[index + 1 :]:
            overlap = sorted(values[left] & values[right])
            if overlap:
                _fail(
                    "S1_AUTHORITY_PARTITION_OVERLAP",
                    f"{left}/{right}: {overlap}",
                )


def _read(path: Path, code: str) -> dict[str, Any]:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, UnicodeError, json.JSONDecodeError) as error:
        _fail(code, f"{path}: {error}")
    if not isinstance(value, dict):
        _fail(code, f"{path} root must be an object")
    return value


def _write(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(rt.canonical_json(value), encoding="utf-8", newline="")


def _logical(prefix: str, name: str) -> str:
    value = PurePosixPath(prefix, name).as_posix() if prefix else name
    if value.startswith("/") or ".." in PurePosixPath(value).parts:
        _fail("S1_PATH_INVALID", value)
    return value


def _implementation_paths() -> dict[str, Path]:
    runtime_dir = _REPO / "harnesses" / "novel-conception-autonomous" / "runtime"
    values = {
        "skill/run_v2.py": _HERE,
        "skill/SKILL.md": _SKILL / "SKILL.md",
        "skill/runtime-contract.md": _SKILL / "references" / "runtime-contract.md",
    }
    for name in (
        "canonical.py",
        "contracts.py",
        "coordinator.py",
        "baseline.py",
        "b0_completion.py",
    ):
        values[f"runtime/{name}"] = runtime_dir / name
    for name in (
        "storyline-architecture.schema.json",
        "canonical-common.schema.json",
        "common-defs.schema.json",
        "input-gate.schema.json",
        "package-manifest.schema.json",
        "stage-completion.schema.json",
    ):
        values[f"schemas/{name}"] = _SCHEMAS / name
    return values


def _controls(b0_root: Path, baseline: Mapping[str, Any]) -> list[dict[str, Any]]:
    found: list[dict[str, Any]] = []
    for entry in baseline["design_artifacts"]:
        source = rt.verify_artifact_reference(entry["artifact"], root=b0_root)
        for value in rt.extract_controls(source, entry["domain"]):
            found.append({**value, "domain": entry["domain"]})
    found.sort(key=lambda item: item["id"])
    return found


def _control_text(value: Any) -> str:
    return value if isinstance(value, str) else rt.canonical_json(value)


def _contains_placeholder(value: str) -> bool:
    return bool(_PLACEHOLDER.search(" ".join(value.split())))


def _validate_model(
    model: Mapping[str, Any],
    baseline: Mapping[str, Any],
    controls: Sequence[Mapping[str, Any]],
    runtime: Any,
    *,
    expected_gate: Mapping[str, str] | None = None,
    expected_sources: Sequence[Mapping[str, str]] | None = None,
) -> None:
    try:
        runtime.validate(model, "storyline-architecture.schema.json")
    except Exception as error:
        _fail("S1_MODEL_SCHEMA_INVALID", str(error))
    partition = model["authority_partition"]
    _validate_authority_disjoint(partition)
    demands = model["storyline_demands"]
    controls_by_id = {x["id"]: x for x in controls}
    baseline_controls = {x["id"] for x in baseline["control_registry"]}
    if set(controls_by_id) != baseline_controls:
        _fail("S1_B0_CONTROL_MISMATCH", "source controls differ from B0 registry")
    if {x["source_ids"][0] for x in demands} != baseline_controls or any(len(x["source_ids"]) != 1 for x in demands):
        _fail("S1_DEMAND_COVERAGE_MISMATCH", "controls and storyline demands are not one-to-one")
    demand_by_control = {item["source_ids"][0]: item for item in demands}
    if len(demand_by_control) != len(demands):
        _fail("S1_DEMAND_COVERAGE_MISMATCH", "a control has duplicate demands")
    for control_id, control in controls_by_id.items():
        obligation = demand_by_control[control_id]["obligation"]
        if (
            control["heading"] not in obligation
            or _control_text(control["value"]) not in obligation
        ):
            _fail(
                "S1_CONTROL_MEANING_UNBOUND",
                f"{control_id} title/value is not carried verbatim by its demand",
            )
    demand_ids = {x["id"] for x in demands}
    covered = [x["source_ids"][0] for x in model["coverage_ledger"]]
    if set(covered) != demand_ids or len(covered) != len(set(covered)):
        _fail("S1_DEMAND_COVERAGE_MISMATCH", "demands are not covered exactly once")
    lines = {x["id"]: x for x in model["storylines"]}
    if len(lines) != len(model["storylines"]):
        _fail("S1_LINE_DUPLICATE", "storyline IDs must be unique")
    mains = [x for x in lines.values() if x["type"] == "main"]
    if len(mains) != 1:
        _fail("S1_MAIN_TRUNK_INVALID", "exactly one main storyline is required")
    main_id = mains[0]["id"]
    connections = {x["id"]: x for x in model["connections"]}
    if len(connections) != len(model["connections"]):
        _fail("S1_CONNECTION_DUPLICATE", "connection IDs must be unique")
    for line in lines.values():
        if not line["start_state"] or not line["state_changes"] or not line["end_state"]:
            _fail("S1_LINE_INCOMPLETE", line["id"])
    structural_ids = {
        line_id
        for line_id, line in lines.items()
        if line["type"] != "optional_melody"
    }
    incident: dict[str, set[str]] = {line_id: set() for line_id in lines}
    causal_outgoing: dict[str, set[str]] = {
        line_id: set() for line_id in structural_ids
    }
    for connection in connections.values():
        source_id = connection["from_storyline_id"]
        target_id = connection["to_storyline_id"]
        source = lines.get(source_id)
        target = lines.get(target_id)
        if source is None or target is None or source_id == target_id:
            _fail("S1_CONNECTION_DANGLING", connection["id"])
        source_states = [
            source["start_state"],
            *source["state_changes"],
            source["end_state"],
        ]
        target_states = [
            target["start_state"],
            *target["state_changes"],
            target["end_state"],
        ]
        if (
            connection["from_state_index"] >= len(source_states)
            or source_states[connection["from_state_index"]]
            != connection["from_state"]
            or connection["to_state_index"] >= len(target_states)
            or target_states[connection["to_state_index"]]
            != connection["to_state"]
        ):
            _fail("S1_CONNECTION_STATE_INVALID", connection["id"])
        incident[source_id].add(connection["id"])
        incident[target_id].add(connection["id"])
        if connection["relation"] == "causal":
            if source_id not in structural_ids or target_id not in structural_ids:
                _fail("S1_OPTIONAL_CAUSAL_LINK_FORBIDDEN", connection["id"])
            causal_outgoing[source_id].add(target_id)
    for line_id, line in lines.items():
        if set(line["connection_ids"]) != incident[line_id]:
            _fail("S1_CONNECTION_RECIPROCAL_MISMATCH", line_id)
        if line["type"] == "optional_melody":
            structural_associations = [
                connection
                for connection in connections.values()
                if connection["id"] in incident[line_id]
                and connection["relation"] == "associative"
                and (
                    connection["from_storyline_id"] in structural_ids
                    or connection["to_storyline_id"] in structural_ids
                )
            ]
            if not structural_associations:
                _fail("S1_OPTIONAL_ASSOCIATION_MISSING", line_id)
    line_order = model["architecture"]["line_order"]
    if set(line_order) != set(lines) or len(line_order) != len(lines):
        _fail(
            "S1_LINE_ORDER_INVALID",
            "line_order must contain every storyline exactly once",
        )
    line_position = {
        line_id: index for index, line_id in enumerate(line_order)
    }
    for connection in connections.values():
        if (
            connection["relation"] == "causal"
            and line_position[connection["from_storyline_id"]]
            >= line_position[connection["to_storyline_id"]]
        ):
            _fail("S1_CAUSAL_LINE_ORDER_INVALID", connection["id"])
    for line_id in structural_ids - {main_id}:
        visited: set[str] = set()
        frontier = [line_id]
        while frontier:
            current = frontier.pop()
            if current in visited:
                continue
            visited.add(current)
            frontier.extend(sorted(causal_outgoing[current] - visited))
        if main_id not in visited:
            _fail("S1_STRUCTURAL_CAUSAL_CLOSURE_MISSING", line_id)
    consistency = model["cross_line_consistency"]
    consistency_by_dimension: dict[str, Mapping[str, Any]] = {}
    consistency_ids: set[str] = set()
    for check in consistency:
        if check["id"] in consistency_ids:
            _fail("S1_CONSISTENCY_CHECK_DUPLICATE", check["id"])
        consistency_ids.add(check["id"])
        dimension = check["dimension"]
        if dimension in consistency_by_dimension:
            _fail("S1_CONSISTENCY_DIMENSION_DUPLICATE", dimension)
        consistency_by_dimension[dimension] = check
    if set(consistency_by_dimension) != set(CONSISTENCY_DIMENSIONS):
        _fail(
            "S1_CONSISTENCY_DIMENSIONS_MISMATCH",
            (
                f"expected={list(CONSISTENCY_DIMENSIONS)} "
                f"actual={sorted(consistency_by_dimension)}"
            ),
        )
    line_ids = set(lines)
    connection_ids = set(connections)
    causal_connection_ids = {
        connection_id
        for connection_id, connection in connections.items()
        if connection["relation"] == "causal"
    }
    decision_ids = {
        item["id"] for item in model["design_decisions"]
    }
    consistency_allowed = {
        "time": line_ids | connection_ids,
        "causality": line_ids | causal_connection_ids,
        "information": line_ids | connection_ids | demand_ids,
        "authority": line_ids | decision_ids | demand_ids,
        "state": line_ids | connection_ids,
        "theme": line_ids | connection_ids | demand_ids | decision_ids,
    }
    for dimension in CONSISTENCY_DIMENSIONS:
        check = consistency_by_dimension[dimension]
        witnesses = set(check["witness_ids"])
        if not line_ids.issubset(witnesses):
            _fail(
                "S1_CONSISTENCY_LINE_COVERAGE_MISSING",
                dimension,
            )
        invalid = sorted(witnesses - consistency_allowed[dimension])
        if invalid:
            _fail(
                "S1_CONSISTENCY_WITNESS_INVALID",
                f"{dimension}: {invalid}",
            )
        claim = " ".join(check["claim"].split())
        failure = " ".join(check["failure_condition"].split())
        if (
            _contains_placeholder(claim)
            or _contains_placeholder(failure)
        ):
            _fail("S1_CONSISTENCY_PLACEHOLDER", dimension)
        if claim == failure:
            _fail(
                "S1_CONSISTENCY_CLAIM_NOT_FALSIFIABLE",
                dimension,
            )
    coverage_by_demand = {
        item["source_ids"][0]: item["realization_ids"]
        for item in model["coverage_ledger"]
    }
    demands_by_line: dict[str, list[str]] = {line_id: [] for line_id in lines}
    for demand in demands:
        realization_ids = coverage_by_demand.get(demand["id"], [])
        if len(realization_ids) != 1 or realization_ids[0] not in lines:
            _fail("S1_DEMAND_COVERAGE_MISMATCH", demand["id"])
        demands_by_line[realization_ids[0]].append(demand["id"])
    for line_id, demand_id_list in demands_by_line.items():
        relevant_controls = [
            controls_by_id[demand_by_control_id]
            for demand_id in demand_id_list
            for demand_by_control_id in next(
                item["source_ids"] for item in demands if item["id"] == demand_id
            )
        ]
        line_text = rt.canonical_json(lines[line_id])
        for control in relevant_controls:
            if _control_text(control["value"]) not in line_text:
                _fail(
                    "S1_CONTROL_MEANING_UNBOUND",
                    f"{control['id']} value does not participate in {line_id}",
                )
    for line_id, demand_id_list in demands_by_line.items():
        if lines[line_id]["type"] != "optional_melody":
            continue
        if any(
            controls_by_id[next(
                item["source_ids"][0]
                for item in demands
                if item["id"] == demand_id
            )]["hardness"]
            == "author_open"
            for demand_id in demand_id_list
        ) and any(
            connection["relation"] == "causal"
            and connection["id"] in incident[line_id]
            for connection in connections.values()
        ):
            _fail("S1_AUTHOR_OPEN_OPTIONAL_CAUSAL", line_id)
    downstream_ids: set[str] = set()
    for field, stage in (
        ("world_requirements", "W1"),
        ("environment_requirements", "E1"),
        ("event_requirements", "T1"),
        ("character_requirements", "C1"),
    ):
        requirements = model[field]
        expected_line_ids = set(lines)
        observed_line_ids: list[str] = []
        observed_demand_ids: list[str] = []
        for requirement in requirements:
            if requirement["target_stage"] != stage:
                _fail("S1_REQUIREMENT_TARGET_MISMATCH", requirement["id"])
            source_ids = requirement["source_ids"]
            line_ids = [item for item in source_ids if item in lines]
            demand_refs = [item for item in source_ids if item in demand_ids]
            if len(line_ids) != 1:
                _fail("S1_REQUIREMENT_COVERAGE_MISMATCH", requirement["id"])
            line_id = line_ids[0]
            if source_ids != [line_id, *demands_by_line[line_id]]:
                _fail(
                    "S1_REQUIREMENT_COVERAGE_MISMATCH",
                    f"{requirement['id']} does not exactly bind its line demands",
                )
            observed_line_ids.append(line_id)
            observed_demand_ids.extend(demand_refs)
            requirement_text = rt.canonical_json(requirement)
            for demand_id in demands_by_line[line_id]:
                control_id = next(
                    item["source_ids"][0] for item in demands if item["id"] == demand_id
                )
                if _control_text(controls_by_id[control_id]["value"]) not in requirement_text:
                    _fail(
                        "S1_CONTROL_MEANING_UNBOUND",
                        f"{control_id} value does not participate in {requirement['id']}",
                    )
            downstream_ids.add(requirement["id"])
        if (
            set(observed_line_ids) != expected_line_ids
            or len(observed_line_ids) != len(set(observed_line_ids))
            or set(observed_demand_ids) != demand_ids
            or len(observed_demand_ids) != len(set(observed_demand_ids))
        ):
            _fail(
                "S1_REQUIREMENT_COVERAGE_MISMATCH",
                f"{field} must cover every line and demand exactly once",
            )
    locked = {
        item["id"]
        for item in baseline["control_registry"]
        if item["hardness"] == "author_locked"
    }
    author_open = {
        item["id"]
        for item in baseline["control_registry"]
        if item["hardness"] == "author_open"
    }
    owned = {
        item["id"]
        for field in ("design_decisions", "storylines")
        for item in model[field]
    }
    expected_partition = {
        "author_locked": locked,
        "autonomous_owned": owned,
        "downstream_freedom": downstream_ids,
        "author_open": author_open,
    }
    for name, expected in expected_partition.items():
        if set(partition[name]) != expected:
            _fail(
                "S1_AUTHORITY_PARTITION_MISMATCH",
                f"{name} differs: expected={sorted(expected)} "
                f"actual={sorted(set(partition[name]))}",
            )
    for claim in model["derivation_claims"]:
        if len(claim["projection_ids"]) == 1 and claim["projection_ids"][0] in lines:
            expected = rt.canonical_sha256(lines[claim["projection_ids"][0]])
            if claim["value_sha256"] != expected:
                _fail("S1_DERIVATION_STALE", claim["id"])
        elif claim["id"] == "DRV-ARCHITECTURE" and claim["value_sha256"] != rt.canonical_sha256(model["architecture"]):
            _fail("S1_DERIVATION_STALE", claim["id"])
    expected_open = author_open
    actual_open = {source for item in model["open_items"] for source in item["source_ids"]}
    if expected_open != actual_open:
        _fail("S1_OPEN_ITEMS_MISMATCH", "author-open controls changed")
    if expected_gate is not None and model["input_gate"] != expected_gate:
        _fail("S1_GATE_REFERENCE_MISMATCH", "model does not bind the stored input gate")
    if expected_sources is not None and model["source_artifacts"] != list(expected_sources):
        _fail("S1_B0_SOURCE_MISMATCH", "model does not bind the exact B0 source set")


def _b0_reference(b0_root: Path) -> dict[str, str]:
    completion_path = b0_root / "stage-completion.json"
    completion = _read(completion_path, "S1_B0_INVALID")
    return {
        "stage": "B0",
        "path": "B0/stage-completion.json",
        "sha256": rt.sha256_file(completion_path),
    }


def _source_artifacts(b0_root: Path) -> list[dict[str, str]]:
    return [
        {
            "path": f"sources/B0/{name}",
            "sha256": rt.sha256_file(b0_root / name),
        }
        for name in (
            "author-control-baseline.json",
            "package-manifest.json",
            "stage-completion.json",
        )
    ]


def _control_bindings(controls: Sequence[Mapping[str, Any]]) -> list[dict[str, str]]:
    return [
        {
            "id": item["id"],
            "domain": item["domain"],
            "heading": item["heading"],
            "value_sha256": rt.canonical_sha256(item["value"]),
        }
        for item in controls
    ]


def _session_context(
    *,
    baseline_package: str | Path,
    input_gate: Any,
    runtime: Any,
    full_validation: bool = True,
) -> tuple[Path, dict[str, Any], list[dict[str, Any]], dict[str, str]]:
    b0_root = Path(baseline_package).resolve()
    if full_validation:
        try:
            rt.validate_baseline_package(b0_root, runtime=runtime)
        except Exception as error:
            _fail("S1_B0_INVALID", str(error))
    baseline = _read(
        b0_root / "author-control-baseline.json", "S1_B0_INVALID"
    )
    expected_b0 = _b0_reference(b0_root)
    try:
        runtime.validate(input_gate.data, "input-gate.schema.json")
    except Exception as error:
        _fail("S1_GATE_INVALID", str(error))
    if (
        input_gate.data.get("target_stage") != "S1"
        or input_gate.data.get("run_id") != baseline["run_id"]
        or input_gate.data.get("baseline_completion") != expected_b0
        or input_gate.data.get("upstream_completions") != []
        or rt.canonical_sha256(input_gate.data)
        != input_gate.reference.get("sha256")
    ):
        _fail("S1_GATE_INVALID", "gate is not the exact sealed S1/B0 gate")
    controls = _controls(b0_root, baseline)
    return b0_root, baseline, controls, expected_b0


def start_s1_session(
    workspace: str | Path,
    *,
    baseline_package: str | Path,
    input_gate: Any,
    runtime: Any | None = None,
) -> dict[str, Any]:
    """Freeze B0/gate/thread before any Agent-authored S1 phase is accepted."""

    root = Path(workspace).resolve()
    if root.exists():
        _fail("S1_SESSION_EXISTS", str(root))
    thread_id = os.environ.get("CODEX_THREAD_ID", "").strip()
    if not thread_id:
        _fail("S1_THREAD_REQUIRED", "CODEX_THREAD_ID is required")
    contract_runtime = runtime or rt.ContractRuntime()
    b0_root, baseline, controls, expected_b0 = _session_context(
        baseline_package=baseline_package,
        input_gate=input_gate,
        runtime=contract_runtime,
    )
    session_id = f"S1-{rt.canonical_sha256([thread_id, input_gate.reference, expected_b0])[:20]}"
    session = {
        "schema_version": "2.0",
        "run_id": baseline["run_id"],
        "stage": "S1",
        "session_id": session_id,
        "thread_id": thread_id,
        "input_gate": copy.deepcopy(input_gate.reference),
        "state_before": copy.deepcopy(input_gate.data["run_state"]),
        "input_manifest": expected_b0,
        "source_artifacts": _source_artifacts(b0_root),
        "control_bindings": _control_bindings(controls),
        "phases": list(PHASES),
    }
    root.mkdir(parents=True)
    _write(root / "generation-session.json", session)
    return copy.deepcopy(session)


def _validated_session(
    workspace: Path,
    *,
    baseline_package: str | Path,
    input_gate: Any,
    runtime: Any,
    full_validation: bool = True,
) -> tuple[dict[str, Any], dict[str, Any], list[dict[str, Any]]]:
    session = _read(
        workspace / "generation-session.json", "S1_SESSION_INVALID"
    )
    b0_root, baseline, controls, expected_b0 = _session_context(
        baseline_package=baseline_package,
        input_gate=input_gate,
        runtime=runtime,
        full_validation=full_validation,
    )
    expected = {
        "schema_version": "2.0",
        "run_id": baseline["run_id"],
        "stage": "S1",
        "session_id": (
            "S1-"
            + rt.canonical_sha256(
                [
                    os.environ.get("CODEX_THREAD_ID", "").strip(),
                    input_gate.reference,
                    expected_b0,
                ]
            )[:20]
        ),
        "thread_id": os.environ.get("CODEX_THREAD_ID", "").strip(),
        "input_gate": copy.deepcopy(input_gate.reference),
        "state_before": copy.deepcopy(input_gate.data["run_state"]),
        "input_manifest": expected_b0,
        "source_artifacts": _source_artifacts(b0_root),
        "control_bindings": _control_bindings(controls),
        "phases": list(PHASES),
    }
    if (
        not expected["thread_id"]
        or not isinstance(expected["session_id"], str)
        or not expected["session_id"]
        or session != expected
    ):
        _fail("S1_SESSION_INVALID", "session no longer binds B0/gate/thread")
    return session, baseline, controls


def submit_s1_phase(
    workspace: str | Path,
    *,
    baseline_package: str | Path,
    input_gate: Any,
    phase: str,
    payload: Mapping[str, Any],
    runtime: Any | None = None,
) -> dict[str, str]:
    """Accept the next Agent-authored phase and extend the forward hash chain."""

    root = Path(workspace).resolve()
    contract_runtime = runtime or rt.ContractRuntime()
    session, baseline, controls = _validated_session(
        root,
        baseline_package=baseline_package,
        input_gate=input_gate,
        runtime=contract_runtime,
        full_validation=False,
    )
    completed = [
        item for item in PHASES
        if (root / "generation-evidence" / f"{PHASES.index(item)+1:02d}-{item}.json").is_file()
    ]
    if len(completed) >= len(PHASES):
        _fail("S1_PHASE_ORDER_INVALID", "all phases are already sealed")
    if phase not in PHASES or phase != PHASES[len(completed)]:
        _fail("S1_PHASE_ORDER_INVALID", f"next phase is {PHASES[len(completed)]}")
    body = copy.deepcopy(dict(payload))
    if set(body) != set(PHASE_FIELDS[phase]):
        _fail(
            "S1_PHASE_PAYLOAD_INVALID",
            f"{phase} must contain exactly {list(PHASE_FIELDS[phase])}",
        )
    if phase == "final-storyline-model":
        model = body.get("model")
        if not isinstance(model, Mapping):
            _fail("S1_PHASE_PAYLOAD_INVALID", "final model is missing")
        _validate_model(
            model,
            baseline,
            controls,
            contract_runtime,
            expected_gate=input_gate.reference,
            expected_sources=session["source_artifacts"],
        )
    previous = None
    if completed:
        previous_path = (
            root
            / "generation-evidence"
            / f"{len(completed):02d}-{completed[-1]}.json"
        )
        previous = rt.sha256_file(previous_path)
    evidence = {
        "schema_version": "2.0",
        "run_id": session["run_id"],
        "stage": "S1",
        "session_id": session["session_id"],
        "thread_id": session["thread_id"],
        "phase": phase,
        "sequence": len(completed) + 1,
        "previous_evidence_sha256": previous,
        "input_gate": session["input_gate"],
        "state_before": session["state_before"],
        "input_manifest": session["input_manifest"],
        "control_bindings": session["control_bindings"],
        "payload": body,
        "payload_sha256": rt.canonical_sha256(body),
    }
    path = (
        root
        / "generation-evidence"
        / f"{len(completed)+1:02d}-{phase}.json"
    )
    _write(path, evidence)
    return rt.artifact_reference(path, root=root)


def _validate_phase_chain(
    evidence_root: Path,
    *,
    session: Mapping[str, Any],
    model: Mapping[str, Any],
) -> list[Path]:
    paths: list[Path] = []
    previous = None
    for index, phase in enumerate(PHASES, 1):
        path = evidence_root / f"{index:02d}-{phase}.json"
        evidence = _read(path, "S1_EVIDENCE_MISSING")
        payload = evidence.get("payload")
        if not isinstance(payload, Mapping):
            _fail("S1_EVIDENCE_INVALID", f"{phase} payload is missing")
        expected_common = {
            "schema_version": "2.0",
            "run_id": session["run_id"],
            "stage": "S1",
            "session_id": session["session_id"],
            "thread_id": session["thread_id"],
            "phase": phase,
            "sequence": index,
            "previous_evidence_sha256": previous,
            "input_gate": session["input_gate"],
            "state_before": session["state_before"],
            "input_manifest": session["input_manifest"],
            "control_bindings": session["control_bindings"],
            "payload": dict(payload),
            "payload_sha256": rt.canonical_sha256(payload),
        }
        if evidence != expected_common or set(payload) != set(PHASE_FIELDS[phase]):
            _fail("S1_EVIDENCE_INVALID", f"{phase} evidence binding is invalid")
        if phase == "final-storyline-model":
            if payload["model"] != model:
                _fail("S1_EVIDENCE_MODEL_MISMATCH", "final evidence differs from model")
        else:
            for field in PHASE_FIELDS[phase]:
                if payload[field] != model[field]:
                    _fail(
                        "S1_EVIDENCE_MODEL_MISMATCH",
                        f"{phase}.{field} differs from final model",
                    )
        previous = rt.sha256_file(path)
        paths.append(path)
    return paths


def _validation(run_id: str) -> dict[str, Any]:
    return {
        "schema_version": "2.0",
        "run_id": run_id,
        "stage": "S1",
        "verdict": "ready",
        "checks": [
            "schema", "b0-binding", "demand-exact-cover", "single-main",
            "causal-structural-closure", "optional-association-boundary",
            "connection-state-index-binding", "reciprocal-incidence",
            "causal-line-order", "six-dimension-consistency",
            "dimension-witness-whitelists", "downstream-requirements",
            "open-items", "derivations",
        ],
        "errors": [],
    }


def validate_s1_package(
    package_root: str | Path,
    *,
    runtime: Any | None = None,
    require_completion: bool = True,
) -> dict[str, Any]:
    root = Path(package_root).resolve()
    contract_runtime = runtime or rt.ContractRuntime()
    model = _read(root / "storyline-architecture.json", "S1_MODEL_MISSING")
    manifest = _read(root / "package-manifest.json", "S1_MANIFEST_INVALID")
    stored = _read(root / "validation.json", "S1_VALIDATION_MISSING")
    try:
        contract_runtime.validate(manifest, "package-manifest.schema.json")
        rt.verify_manifest_integrity(manifest, root=root)
    except Exception as error:
        _fail("S1_MANIFEST_INVALID", str(error))
    copied_b0 = root / "sources" / "B0"
    try:
        rt.validate_baseline_package(copied_b0, runtime=contract_runtime)
    except Exception as error:
        _fail("S1_B0_INVALID", str(error))
    baseline = _read(copied_b0 / "author-control-baseline.json", "S1_B0_INVALID")
    if baseline["run_id"] != model["run_id"]:
        _fail("S1_RUN_ID_MISMATCH", "S1 and B0 run IDs differ")
    gate = _read(root / "input-gate.json", "S1_GATE_MISSING")
    try:
        contract_runtime.validate(gate, "input-gate.schema.json")
    except Exception as error:
        _fail("S1_GATE_INVALID", str(error))
    stored_gate_reference = {
        "path": model["input_gate"]["path"],
        "sha256": rt.sha256_file(root / "input-gate.json"),
    }
    if not stored_gate_reference["path"].endswith("/input-gate.json"):
        _fail("S1_GATE_REFERENCE_MISMATCH", "input gate path is not package-qualified")
    b0_completion_path = copied_b0 / "stage-completion.json"
    b0_completion = _read(b0_completion_path, "S1_B0_INVALID")
    try:
        contract_runtime.validate(b0_completion, "stage-completion.schema.json")
    except Exception as error:
        _fail("S1_B0_INVALID", str(error))
    expected_b0_reference = {
        "stage": "B0",
        "path": "B0/stage-completion.json",
        "sha256": rt.sha256_file(b0_completion_path),
    }
    if (
        gate.get("target_stage") != "S1"
        or gate.get("run_id") != model["run_id"]
        or gate.get("baseline_completion") != expected_b0_reference
        or gate.get("upstream_completions") != []
    ):
        _fail("S1_GATE_INVALID", "gate does not bind the exact S1/B0 topology")
    expected_sources = [
        rt.artifact_reference(copied_b0 / name, root=root)
        for name in (
            "author-control-baseline.json",
            "package-manifest.json",
            "stage-completion.json",
        )
    ]
    controls = _controls(copied_b0, baseline)
    _validate_model(
        model,
        baseline,
        controls,
        contract_runtime,
        expected_gate=stored_gate_reference,
        expected_sources=expected_sources,
    )
    if manifest["artifact_roles"]["canonical"] != rt.artifact_reference(
        root / "storyline-architecture.json", root=root
    ):
        _fail("S1_MANIFEST_INVALID", "canonical role does not bind the model")
    execution = _read(root / "execution-record.json", "S1_EXECUTION_INVALID")
    if (
        execution.get("input_gate") != stored_gate_reference
        or execution.get("input_manifest") != expected_b0_reference
        or execution.get("output_sha256") != rt.canonical_sha256(model)
    ):
        _fail("S1_EXECUTION_INVALID", "execution lineage does not bind gate/B0/model")
    session = _read(root / "generation-session.json", "S1_SESSION_INVALID")
    session_thread = session.get("thread_id")
    if not isinstance(session_thread, str) or not session_thread.strip():
        _fail("S1_SESSION_INVALID", "session thread is missing")
    expected_session = {
        "schema_version": "2.0",
        "run_id": model["run_id"],
        "stage": "S1",
        "session_id": (
            "S1-"
            + rt.canonical_sha256(
                [session_thread, stored_gate_reference, expected_b0_reference]
            )[:20]
        ),
        "thread_id": session_thread,
        "input_gate": stored_gate_reference,
        "state_before": gate.get("run_state"),
        "input_manifest": expected_b0_reference,
        "source_artifacts": expected_sources,
        "control_bindings": _control_bindings(controls),
        "phases": list(PHASES),
    }
    if session != expected_session:
        _fail("S1_SESSION_INVALID", "session lineage differs from package inputs")
    if execution.get("session_id") != session["session_id"]:
        _fail("S1_SESSION_INVALID", "execution does not bind the frozen session")
    evidence_paths = _validate_phase_chain(
        root / "generation-evidence",
        session=session,
        model=model,
    )
    evidence_index = _read(
        root / "generation-evidence-index.json", "S1_EVIDENCE_INVALID"
    )
    expected_evidence_refs = [
        rt.artifact_reference(path, root=root) for path in evidence_paths
    ]
    if evidence_index != {
        "schema_version": "2.0",
        "run_id": model["run_id"],
        "stage": "S1",
        "session_id": session["session_id"],
        "phases": list(PHASES),
        "evidence": expected_evidence_refs,
    }:
        _fail("S1_EVIDENCE_INVALID", "evidence index differs from phase chain")
    catalog = {x["identity"]: x["artifact"] for x in execution.get("implementation_catalog", [])}
    for identity, current in _implementation_paths().items():
        reference = catalog.get(identity)
        if reference is None:
            _fail("S1_IMPLEMENTATION_STALE", identity)
        try:
            rt.verify_artifact_reference(reference, root=root)
        except Exception as error:
            _fail("S1_IMPLEMENTATION_STALE", str(error))
        if reference["sha256"] != rt.sha256_file(current):
            _fail("S1_IMPLEMENTATION_STALE", identity)
    if require_completion:
        completion_path = root / "stage-completion.json"
        completion = _read(completion_path, "S1_COMPLETION_MISSING")
        try:
            contract_runtime.validate(completion, "stage-completion.schema.json")
        except Exception as error:
            _fail("S1_COMPLETION_INVALID", str(error))
        logical_prefix = PurePosixPath(stored_gate_reference["path"]).parent.as_posix()
        expected_manifest = {
            "path": _logical(logical_prefix, "package-manifest.json"),
            "sha256": rt.sha256_file(root / "package-manifest.json"),
        }
        expected_validation = {
            "path": _logical(logical_prefix, "validation.json"),
            "sha256": rt.sha256_file(root / "validation.json"),
        }
        if (
            completion.get("run_id") != model["run_id"]
            or completion.get("stage") != "S1"
            or completion.get("status") != "ready"
            or completion.get("session_id") != session.get("session_id")
            or completion.get("manifest") != expected_manifest
            or completion.get("validation") != expected_validation
            or completion.get("input_gate") != stored_gate_reference
            or completion.get("state_before") != gate.get("run_state")
            or completion.get("previous_stage_completions")
            != gate.get("upstream_completions")
            or completion.get("return_binding") != gate.get("return_binding")
        ):
            _fail(
                "S1_COMPLETION_BINDING_MISMATCH",
                "completion does not exactly bind gate/state/B0/package/session",
            )
    expected = _validation(model["run_id"])
    if stored != expected:
        _fail("S1_VALIDATION_STALE", "stored validation differs from read-only validation")
    return expected


def run_s1(
    package_root: str | Path,
    *,
    baseline_package: str | Path,
    coordinator: Any,
    input_gate: Any,
    controlled_workspace: str | Path,
    logical_package_path: str = "S1",
    next_state_path: str,
    active_return_request: Any | None = None,
    runtime: Any | None = None,
) -> S1RunReceipt:
    destination = Path(package_root).resolve()
    b0_root = Path(baseline_package).resolve()
    contract_runtime = runtime or rt.ContractRuntime()
    if destination.exists():
        _fail("S1_OUTPUT_EXISTS", str(destination))
    thread_id = os.environ.get("CODEX_THREAD_ID", "").strip()
    if not thread_id:
        _fail("S1_THREAD_REQUIRED", "CODEX_THREAD_ID is required")
    workspace = Path(controlled_workspace).resolve()
    session, baseline, controls = _validated_session(
        workspace,
        baseline_package=b0_root,
        input_gate=input_gate,
        runtime=contract_runtime,
    )
    final_evidence = _read(
        workspace
        / "generation-evidence"
        / f"{len(PHASES):02d}-{PHASES[-1]}.json",
        "S1_EVIDENCE_MISSING",
    )
    final_payload = final_evidence.get("payload")
    if not isinstance(final_payload, Mapping) or not isinstance(
        final_payload.get("model"), Mapping
    ):
        _fail("S1_EVIDENCE_INVALID", "final model evidence is missing")
    model = copy.deepcopy(dict(final_payload["model"]))
    _validate_phase_chain(
        workspace / "generation-evidence",
        session=session,
        model=model,
    )
    _validate_model(
        model,
        baseline,
        controls,
        contract_runtime,
        expected_gate=input_gate.reference,
        expected_sources=session["source_artifacts"],
    )
    expected_b0_ref = session["input_manifest"]

    destination.parent.mkdir(parents=True, exist_ok=True)
    temp_parent = Path(tempfile.mkdtemp(prefix=f".{destination.name}.", dir=destination.parent))
    staging = temp_parent / "package"
    staging.mkdir()
    try:
        shutil.copytree(b0_root, staging / "sources" / "B0")
        _write(staging / "input-gate.json", input_gate.data)
        source_artifacts = [
            rt.artifact_reference(staging / "sources" / "B0" / name, root=staging)
            for name in (
                "author-control-baseline.json",
                "package-manifest.json",
                "stage-completion.json",
            )
        ]
        if source_artifacts != session["source_artifacts"]:
            _fail("S1_B0_SOURCE_MISMATCH", "staged B0 differs from frozen session")
        _write(staging / "storyline-architecture.json", model)

        evidence_refs = []
        for index, phase in enumerate(PHASES, 1):
            source = (
                workspace / "generation-evidence" / f"{index:02d}-{phase}.json"
            )
            path = staging / "generation-evidence" / source.name
            path.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(source, path)
            reference = rt.artifact_reference(path, root=staging)
            evidence_refs.append(reference)
        evidence_index = {
            "schema_version": "2.0", "run_id": baseline["run_id"], "stage": "S1",
            "session_id": session["session_id"],
            "phases": list(PHASES), "evidence": evidence_refs,
        }
        _write(staging / "generation-evidence-index.json", evidence_index)
        _write(staging / "generation-session.json", session)
        session_id = session["session_id"]
        implementation_refs = []
        implementation_catalog = []
        for identity, source in sorted(_implementation_paths().items()):
            target = staging / "implementation" / identity
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(source, target)
            reference = rt.artifact_reference(target, root=staging)
            implementation_refs.append(reference)
            implementation_catalog.append({"identity": identity, "artifact": reference})
        execution = {
            "schema_version": "2.0", "run_id": baseline["run_id"], "stage": "S1",
            "operation": "controlled-storyline-architecture-generation",
            "session_id": session_id, "input_gate": copy.deepcopy(input_gate.reference),
            "input_manifest": expected_b0_ref,
            "implementation": implementation_refs,
            "implementation_catalog": implementation_catalog,
            "output_sha256": rt.canonical_sha256(model),
        }
        _write(staging / "execution-record.json", execution)
        (staging / "storyline-preview.md").write_text(
            "# Storyline architecture\n\n"
            + "\n".join(
                f"- **{line['id']} ({line['type']})**: {line['responsibility']}"
                for line in model["storylines"]
            )
            + "\n",
            encoding="utf-8",
            newline="",
        )
        validation = _validation(baseline["run_id"])
        _write(staging / "validation.json", validation)
        files = [
            rt.artifact_reference(path, root=staging)
            for path in sorted(staging.rglob("*"), key=lambda x: x.as_posix())
            if path.is_file()
        ]
        by_path = {x["path"]: x for x in files}
        manifest = {
            "schema_version": "2.0", "run_id": baseline["run_id"], "stage": "S1",
            "package_profile": "generated-model", "verdict": "ready", "files": files,
            "artifact_roles": {
                "canonical": by_path["storyline-architecture.json"],
                "generation_session": by_path["generation-session.json"],
                "generation_evidence_index": by_path["generation-evidence-index.json"],
                "execution_record": by_path["execution-record.json"],
                "preview": by_path["storyline-preview.md"],
            },
            "validation": by_path["validation.json"],
            "implementation": implementation_refs,
        }
        contract_runtime.validate(manifest, "package-manifest.schema.json")
        rt.verify_manifest_integrity(manifest, root=staging)
        _write(staging / "package-manifest.json", manifest)
        validate_s1_package(
            staging, runtime=contract_runtime, require_completion=False
        )
        completion_data = {
            "schema_version": "2.0", "run_id": baseline["run_id"], "stage": "S1",
            "status": "ready", "session_id": session_id,
            "manifest": {
                "path": _logical(logical_package_path, "package-manifest.json"),
                "sha256": rt.sha256_file(staging / "package-manifest.json"),
            },
            "validation": {
                "path": _logical(logical_package_path, "validation.json"),
                "sha256": rt.sha256_file(staging / "validation.json"),
            },
            "input_gate": copy.deepcopy(input_gate.reference),
            "state_before": copy.deepcopy(input_gate.data["run_state"]),
            "previous_stage_completions": [],
            "return_binding": copy.deepcopy(input_gate.data["return_binding"]),
        }
        contract_runtime.validate(completion_data, "stage-completion.schema.json")
        sealed = rt.seal_stage_document(
            completion_data, "S1", _logical(logical_package_path, "stage-completion.json")
        )
        _write(staging / "stage-completion.json", sealed.data)
        validate_s1_package(staging, runtime=contract_runtime)
        transition = coordinator.accept_stage_completion(
            gate=input_gate,
            completion=sealed,
            next_state_path=next_state_path,
            active_return_request=active_return_request,
        )
        staging.replace(destination)
    except Exception:
        shutil.rmtree(temp_parent, ignore_errors=True)
        raise
    shutil.rmtree(temp_parent, ignore_errors=True)
    return S1RunReceipt(
        package_root=destination,
        model=copy.deepcopy(model),
        manifest=copy.deepcopy(manifest),
        completion=sealed,
        transition=transition,
    )


__all__ = [
    "S1Error",
    "S1RunReceipt",
    "run_s1",
    "start_s1_session",
    "submit_s1_phase",
    "validate_s1_package",
]
