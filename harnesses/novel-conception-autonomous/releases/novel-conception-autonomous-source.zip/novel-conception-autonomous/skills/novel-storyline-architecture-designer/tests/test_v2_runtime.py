from __future__ import annotations

import copy
import importlib
import json
import os
import tempfile
import unittest
from pathlib import Path
from unittest import mock


runtime = importlib.import_module(
    "harnesses.novel-conception-autonomous.runtime"
)
s1 = importlib.import_module(
    "skills.novel-storyline-architecture-designer.scripts.run_v2"
)
baseline_test = importlib.import_module(
    "harnesses.novel-conception-autonomous.tests.test_baseline"
)


def agent_proposal(
    *,
    run_id: str,
    gate_reference: dict[str, str],
    source_artifacts: list[dict[str, str]],
    controls: list[dict[str, object]],
) -> dict[str, object]:
    """A test Agent's authored proposal; production code never synthesizes it."""

    demands = []
    storylines = []
    decisions = []
    coverage = []
    line_by_control = {}
    for index, control in enumerate(controls, 1):
        control_id = str(control["id"])
        value = (
            control["value"]
            if isinstance(control["value"], str)
            else runtime.canonical_json(control["value"])
        )
        line_id = "SL-MAIN" if index == 1 else f"SL-{index:03d}"
        demand_id = f"SLD-{index:03d}"
        decision_id = f"DEC-{index:03d}"
        line_by_control[control_id] = line_id
        demands.append(
            {
                "id": demand_id,
                "source_ids": [control_id],
                "obligation": (
                    f"Agent interpretation of {control['heading']}. "
                    f"Source meaning (verbatim): {value}"
                ),
                "disposition": "merged" if index == 1 else "independent_line",
            }
        )
        decisions.append(
            {
                "id": decision_id,
                "gap": f"Choose dramatic ownership for {control_id}.",
                "options": ["Merge into main line.", "Create a connected line."],
                "selection": (
                    "Merge into main line."
                    if index == 1
                    else "Create a connected line."
                ),
                "owner": "S1",
                "authority_basis": f"S1 owns storyline projection of {control_id}.",
                "compatibility": f"Preserves the source meaning: {value}",
                "impact_ids": [line_id],
                "cost": "Creates one explicit dramatic responsibility.",
                "reversibility": "costly",
                "downstream_freedom": "Concrete realization remains downstream.",
                "projection_ids": [line_id],
            }
        )
        storylines.append(
            {
                "id": line_id,
                "type": "main" if index == 1 else "supporting",
                "responsibility": f"Carry {control_id}: {value}",
                "actor_slot_ids": [f"SLOT-{index:03d}"],
                "goal": f"Make this meaning actionable without changing it: {value}",
                "pressure": f"Ignoring this meaning leaves the story incomplete: {value}",
                "start_state": f"The obligation is latent: {value}",
                "state_changes": [
                    f"Pressure exposes the obligation: {value}",
                    f"A choice changes its consequences: {value}",
                ],
                "end_state": f"The obligation has a visible consequence: {value}",
                "connection_ids": [],
                "source_decision_ids": [decision_id],
                "downstream_freedom": "World, place, event, actor identity and prose are open.",
            }
        )
        coverage.append(
            {
                "id": f"COV-{index:03d}",
                "source_ids": [demand_id],
                "realization_ids": [line_id],
                "status": "covered",
                "evidence": f"{demand_id} is assigned once to {line_id}.",
            }
        )
    main = storylines[0]
    connections = []
    for index, line in enumerate(storylines[1:], 1):
        connection_id = f"SLC-{index:03d}"
        connections.append(
            {
                "id": connection_id,
                "type": "collision",
                "relation": "causal",
                "from_storyline_id": line["id"],
                "to_storyline_id": "SL-MAIN",
                "from_state": line["end_state"],
                "from_state_index": len(line["state_changes"]) + 1,
                "to_state": main["state_changes"][-1],
                "to_state_index": len(main["state_changes"]),
            }
        )
        line["connection_ids"].append(connection_id)
        main["connection_ids"].append(connection_id)
    demand_by_line = {
        line_by_control[str(control["id"])]: f"SLD-{index:03d}"
        for index, control in enumerate(controls, 1)
    }
    requirements = {}
    for field, prefix, stage in (
        ("world_requirements", "WR", "W1"),
        ("environment_requirements", "END", "E1"),
        ("event_requirements", "EVD", "T1"),
        ("character_requirements", "CHD", "C1"),
    ):
        requirements[field] = []
        for index, line in enumerate(storylines, 1):
            requirements[field].append(
                {
                    "id": f"{prefix}-{index:03d}",
                    "target_stage": stage,
                    "responsibility": f"Realize {line['responsibility']}",
                    "source_ids": [line["id"], demand_by_line[line["id"]]],
                    "required_capability": (
                        f"Support {line['start_state']} through {line['end_state']}"
                    ),
                    "constraints": [line["goal"], line["pressure"]],
                    "acceptance_checks": [
                        f"The result cites {line['id']}.",
                        f"The result preserves {line['end_state']}.",
                    ],
                    "downstream_freedom": line["downstream_freedom"],
                }
            )
    architecture = {
        "subject": "All approved obligations form one connected causal whole.",
        "opening_condition": main["start_state"],
        "development_logic": "Each line changes state before joining the main trunk.",
        "turning_logic": "Every connection changes the pressure on the main trunk.",
        "resolution_condition": main["end_state"],
        "theme_test": "The ending answers locked controls and preserves open controls.",
        "line_order": [
            *[line["id"] for line in storylines if line["id"] != "SL-MAIN"],
            "SL-MAIN",
        ],
    }
    model = {
        "schema_version": "2.0",
        "skill": "novel-storyline-architecture-designer",
        "stage": "S1",
        "run_id": run_id,
        "status": "ready",
        "input_gate": copy.deepcopy(gate_reference),
        "source_artifacts": copy.deepcopy(source_artifacts),
        "authority_partition": {
            "author_locked": [
                str(item["id"])
                for item in controls
                if item["hardness"] == "author_locked"
            ],
            "autonomous_owned": [
                *[item["id"] for item in decisions],
                *[item["id"] for item in storylines],
            ],
            "downstream_freedom": [
                item["id"] for values in requirements.values() for item in values
            ],
            "author_open": [
                str(item["id"])
                for item in controls
                if item["hardness"] == "author_open"
            ],
        },
        "design_decisions": decisions,
        "derivation_claims": [
            {
                "id": f"DRV-{index:03d}",
                "value_sha256": runtime.canonical_sha256(line),
                "source_ids": [str(controls[index - 1]["id"])],
                "decision_ids": [f"DEC-{index:03d}"],
                "projection_ids": [line["id"]],
            }
            for index, line in enumerate(storylines, 1)
        ]
        + [
            {
                "id": "DRV-ARCHITECTURE",
                "value_sha256": runtime.canonical_sha256(architecture),
                "source_ids": [str(item["id"]) for item in controls],
                "decision_ids": [item["id"] for item in decisions],
                "projection_ids": [item["id"] for item in storylines],
            }
        ],
        "storyline_demands": demands,
        "storylines": storylines,
        "connections": connections,
        "architecture": architecture,
        "cross_line_consistency": [
            {
                "id": f"SLCHECK-{dimension.upper()}",
                "dimension": dimension,
                "witness_ids": [line["id"] for line in storylines],
                "claim": (
                    f"Every storyline has a declared {dimension} relation "
                    "that remains consistent with the complete architecture."
                ),
                "failure_condition": (
                    f"The {dimension} relation fails if any declared "
                    "storyline contradicts another line or the architecture."
                ),
            }
            for dimension in (
                "time",
                "causality",
                "information",
                "authority",
                "state",
                "theme",
            )
        ],
        **requirements,
        "coverage_ledger": coverage,
        "open_items": [
            {
                "id": f"OPEN-{index:03d}",
                "question": (
                    f"Preserve {control['heading']}: "
                    f"{control['value']}"
                ),
                "source_ids": [str(control["id"])],
                "status": "author_open",
            }
            for index, control in enumerate(
                [item for item in controls if item["hardness"] == "author_open"],
                1,
            )
        ],
    }
    return model


class S1RuntimeTests(unittest.TestCase):
    def setUp(self) -> None:
        self.temporary = tempfile.TemporaryDirectory()
        self.work = Path(self.temporary.name)
        self.sources = baseline_test.SourceFixture(self.work / "sources")
        self.coordinator = runtime.AutonomousCoordinator.initialize(
            run_id=self.sources.run_id,
            source_interview_state={
                "path": "interview/interview-state.json",
                "sha256": runtime.sha256_file(self.sources.state),
            },
            state_path="state/revision-000.json",
        )
        b0_gate = self.coordinator.build_input_gate("B0", "B0/input-gate.json")
        self.b0 = self.work / "run" / "B0"
        runtime.build_baseline_package(
            **self.sources.build_args(self.b0, b0_gate)
        )
        runtime.complete_b0(
            self.b0,
            coordinator=self.coordinator,
            input_gate=b0_gate,
            logical_package_path="B0",
            next_state_path="state/revision-001.json",
        )
        self.gate = self.coordinator.build_input_gate(
            "S1", "S1/input-gate.json"
        )
        self.package = self.work / "run" / "S1"
        self.workspace = self.work / "workspace" / "S1"
        baseline_model = json.loads(
            (self.b0 / "author-control-baseline.json").read_text(encoding="utf-8")
        )
        controls = s1._controls(self.b0, baseline_model)
        source_artifacts = [
            {
                "path": f"sources/B0/{name}",
                "sha256": runtime.sha256_file(self.b0 / name),
            }
            for name in (
                "author-control-baseline.json",
                "package-manifest.json",
                "stage-completion.json",
            )
        ]
        self.proposal = agent_proposal(
            run_id=self.sources.run_id,
            gate_reference=self.gate.reference,
            source_artifacts=source_artifacts,
            controls=controls,
        )
        with mock.patch.dict(
            os.environ, {"CODEX_THREAD_ID": "thread-generic-s1"}, clear=False
        ):
            s1.start_s1_session(
                self.workspace,
                baseline_package=self.b0,
                input_gate=self.gate,
            )
            for phase in s1.PHASES:
                payload = (
                    {"model": self.proposal}
                    if phase == "final-storyline-model"
                    else {
                        field: self.proposal[field]
                        for field in s1.PHASE_FIELDS[phase]
                    }
                )
                s1.submit_s1_phase(
                    self.workspace,
                    baseline_package=self.b0,
                    input_gate=self.gate,
                    phase=phase,
                    payload=payload,
                )

    def tearDown(self) -> None:
        self.temporary.cleanup()

    def run_s1(self) -> s1.S1RunReceipt:
        with mock.patch.dict(
            os.environ, {"CODEX_THREAD_ID": "thread-generic-s1"}, clear=False
        ):
            return s1.run_s1(
                self.package,
                baseline_package=self.b0,
                coordinator=self.coordinator,
                input_gate=self.gate,
                controlled_workspace=self.workspace,
                logical_package_path="S1",
                next_state_path="state/revision-002.json",
            )

    def _validate(self, model: dict[str, object]) -> None:
        baseline = json.loads(
            (self.b0 / "author-control-baseline.json").read_text(encoding="utf-8")
        )
        s1._validate_model(
            model,
            baseline,
            s1._controls(self.b0, baseline),
            runtime.ContractRuntime(),
            expected_gate=self.gate.reference,
            expected_sources=self.proposal["source_artifacts"],
        )

    def _refresh_derivations(self, model: dict[str, object]) -> None:
        lines = {item["id"]: item for item in model["storylines"]}
        for claim in model["derivation_claims"]:
            if (
                len(claim["projection_ids"]) == 1
                and claim["projection_ids"][0] in lines
            ):
                claim["value_sha256"] = runtime.canonical_sha256(
                    lines[claim["projection_ids"][0]]
                )
            elif claim["id"] == "DRV-ARCHITECTURE":
                claim["value_sha256"] = runtime.canonical_sha256(
                    model["architecture"]
                )

    def test_authority_partition_rejects_overlap_before_deep_validation(self) -> None:
        model = copy.deepcopy(self.proposal)
        model["authority_partition"]["downstream_freedom"].append(
            model["authority_partition"]["autonomous_owned"][0]
        )
        with self.assertRaisesRegex(
            s1.S1Error, "S1_AUTHORITY_PARTITION_OVERLAP"
        ):
            self._validate(model)

    def test_authority_partition_requires_all_four_exact_sets(self) -> None:
        model = copy.deepcopy(self.proposal)
        model["authority_partition"]["autonomous_owned"].pop()
        with self.assertRaisesRegex(
            s1.S1Error, "S1_AUTHORITY_PARTITION_MISMATCH"
        ):
            self._validate(model)

    def test_connection_relation_is_required(self) -> None:
        model = copy.deepcopy(self.proposal)
        model["connections"][0].pop("relation")
        with self.assertRaisesRegex(s1.S1Error, "S1_MODEL_SCHEMA_INVALID"):
            self._validate(model)

    def test_connection_state_index_and_text_are_one_binding(self) -> None:
        model = copy.deepcopy(self.proposal)
        model["connections"][0]["from_state_index"] = 0
        with self.assertRaisesRegex(
            s1.S1Error, "S1_CONNECTION_STATE_INVALID"
        ):
            self._validate(model)

    def test_connection_incidence_is_reciprocal_exact(self) -> None:
        model = copy.deepcopy(self.proposal)
        model["storylines"][1]["connection_ids"] = []
        self._refresh_derivations(model)
        with self.assertRaisesRegex(
            s1.S1Error, "S1_CONNECTION_RECIPROCAL_MISMATCH"
        ):
            self._validate(model)

    def test_structural_line_needs_causal_path_to_main(self) -> None:
        model = copy.deepcopy(self.proposal)
        model["connections"][0]["relation"] = "associative"
        with self.assertRaisesRegex(
            s1.S1Error, "S1_STRUCTURAL_CAUSAL_CLOSURE_MISSING"
        ):
            self._validate(model)

    def test_optional_line_accepts_association_without_ordering_weight(
        self,
    ) -> None:
        model = copy.deepcopy(self.proposal)
        model["storylines"][1]["type"] = "optional_melody"
        model["connections"][0]["relation"] = "associative"
        self._refresh_derivations(model)
        self._validate(model)
        causality = next(
            item
            for item in model["cross_line_consistency"]
            if item["dimension"] == "causality"
        )
        causality["witness_ids"].append(
            model["connections"][0]["id"]
        )
        with self.assertRaisesRegex(
            s1.S1Error, "S1_CONSISTENCY_WITNESS_INVALID"
        ):
            self._validate(model)

        missing_dimension = copy.deepcopy(self.proposal)
        missing_dimension["cross_line_consistency"] = [
            item
            for item in missing_dimension["cross_line_consistency"]
            if item["dimension"] != "causality"
        ]
        with self.assertRaisesRegex(
            s1.S1Error, "S1_CONSISTENCY_DIMENSIONS_MISMATCH"
        ):
            self._validate(missing_dimension)

        missing_line = copy.deepcopy(self.proposal)
        missing_line["cross_line_consistency"][0][
            "witness_ids"
        ].pop()
        with self.assertRaisesRegex(
            s1.S1Error, "S1_CONSISTENCY_LINE_COVERAGE_MISSING"
        ):
            self._validate(missing_line)

        unknown = copy.deepcopy(self.proposal)
        unknown["cross_line_consistency"][0][
            "witness_ids"
        ].append("UNKNOWN-WITNESS")
        with self.assertRaisesRegex(
            s1.S1Error, "S1_CONSISTENCY_WITNESS_INVALID"
        ):
            self._validate(unknown)

        for field in ("claim", "failure_condition"):
            with self.subTest(placeholder_field=field):
                placeholder = copy.deepcopy(self.proposal)
                placeholder["cross_line_consistency"][0][field] = (
                    "TBD placeholder consistency statement."
                )
                with self.assertRaisesRegex(
                    s1.S1Error, "S1_CONSISTENCY_PLACEHOLDER"
                ):
                    self._validate(placeholder)

    def test_optional_line_rejects_causal_connection(self) -> None:
        model = copy.deepcopy(self.proposal)
        model["storylines"][1]["type"] = "optional_melody"
        self._refresh_derivations(model)
        with self.assertRaisesRegex(
            s1.S1Error, "S1_OPTIONAL_CAUSAL_LINK_FORBIDDEN"
        ):
            self._validate(model)

    def test_structural_lines_may_reach_main_through_causal_path(self) -> None:
        model = copy.deepcopy(self.proposal)
        lines = {item["id"]: item for item in model["storylines"]}
        connection = model["connections"][1]
        connection["to_storyline_id"] = "SL-002"
        connection["to_state"] = lines["SL-002"]["state_changes"][0]
        connection["to_state_index"] = 1
        lines["SL-MAIN"]["connection_ids"].remove(connection["id"])
        lines["SL-002"]["connection_ids"].append(connection["id"])
        model["architecture"]["line_order"] = [
            *[
                item["id"]
                for item in model["storylines"]
                if item["id"] not in {"SL-MAIN", "SL-002", "SL-003"}
            ],
            "SL-003",
            "SL-002",
            "SL-MAIN",
        ]
        self._refresh_derivations(model)
        self._validate(model)

    def test_generic_baseline_builds_closed_storyline_package(self) -> None:
        receipt = self.run_s1()
        model = receipt.model

        self.assertEqual("ready", model["status"])
        self.assertEqual(1, sum(x["type"] == "main" for x in model["storylines"]))
        self.assertGreaterEqual(len(model["storylines"]), 3)
        self.assertEqual(
            {x["id"] for x in model["storyline_demands"]},
            {x["source_ids"][0] for x in model["coverage_ledger"]},
        )
        main_id = next(x["id"] for x in model["storylines"] if x["type"] == "main")
        connected = {x["from_storyline_id"] for x in model["connections"]}
        self.assertEqual(
            {x["id"] for x in model["storylines"] if x["id"] != main_id},
            connected,
        )
        self.assertTrue(
            all(x["to_storyline_id"] == main_id for x in model["connections"])
        )
        for field, stage in (
            ("world_requirements", "W1"),
            ("environment_requirements", "E1"),
            ("event_requirements", "T1"),
            ("character_requirements", "C1"),
        ):
            self.assertTrue(model[field])
            self.assertTrue(
                all(
                    x["target_stage"] == stage
                    and x["responsibility"]
                    and x["constraints"]
                    and x["acceptance_checks"]
                    for x in model[field]
                )
            )
        self.assertNotIn("断线", json.dumps(model, ensure_ascii=False))
        self.assertEqual("S1", receipt.completion.data["stage"])
        self.assertEqual(2, receipt.transition.snapshot["revision"])
        self.assertEqual(
            receipt.completion.reference,
            receipt.transition.snapshot["current_stage_completions"]["S1"],
        )
        self.assertEqual(
            {"author_open"},
            {item["status"] for item in model["open_items"]},
        )
        self.assertEqual(
            "ready", s1.validate_s1_package(self.package)["verdict"]
        )

    def test_invalid_b0_is_rejected_before_candidate_package(self) -> None:
        copied = next(
            p for p in (self.b0 / "sources").rglob("design.md") if "I0" in p.parts
        )
        copied.write_text("tampered", encoding="utf-8")
        with self.assertRaises(s1.S1Error) as caught:
            self.run_s1()
        self.assertEqual("S1_B0_INVALID", caught.exception.code)
        self.assertFalse(self.package.exists())
        self.assertEqual(1, self.coordinator.state["revision"])

    def test_missing_controlled_thread_is_blocked_without_output(self) -> None:
        with mock.patch.dict(os.environ, {}, clear=True):
            with self.assertRaises(s1.S1Error) as caught:
                s1.run_s1(
                    self.package,
                    baseline_package=self.b0,
                    coordinator=self.coordinator,
                    input_gate=self.gate,
                    controlled_workspace=self.workspace,
                    logical_package_path="S1",
                    next_state_path="state/revision-002.json",
                )
        self.assertEqual("S1_THREAD_REQUIRED", caught.exception.code)
        self.assertFalse(self.package.exists())

    def test_tamper_and_resealed_semantic_gap_fail_read_only_validation(self) -> None:
        self.run_s1()
        model_path = self.package / "storyline-architecture.json"
        model = json.loads(model_path.read_text(encoding="utf-8"))
        model["storylines"][0]["state_changes"] = []
        model_path.write_text(runtime.canonical_json(model), encoding="utf-8")
        with self.assertRaises(s1.S1Error) as caught:
            s1.validate_s1_package(self.package)
        self.assertIn(
            caught.exception.code,
            {"S1_MANIFEST_INVALID", "S1_MODEL_SCHEMA_INVALID"},
        )

    def test_gate_from_another_baseline_is_rejected(self) -> None:
        bad = copy.deepcopy(self.gate.data)
        bad["baseline_completion"]["sha256"] = "0" * 64
        bad_gate = runtime.SealedDocument(
            data=bad,
            reference={
                "path": "S1/input-gate.json",
                "sha256": runtime.canonical_sha256(bad),
            },
        )
        with mock.patch.dict(
            os.environ, {"CODEX_THREAD_ID": "thread-generic-s1"}, clear=False
        ):
            with self.assertRaises(s1.S1Error) as caught:
                s1.run_s1(
                    self.package,
                    baseline_package=self.b0,
                    coordinator=self.coordinator,
                    input_gate=bad_gate,
                    controlled_workspace=self.workspace,
                    logical_package_path="S1",
                    next_state_path="state/revision-002.json",
                )
        self.assertIn(
            caught.exception.code,
            {"S1_GATE_INVALID", "S1_SESSION_INVALID"},
        )
        self.assertFalse(self.package.exists())

    def test_resealed_requirement_deletion_is_rejected(self) -> None:
        self.run_s1()
        model_path = self.package / "storyline-architecture.json"
        model = json.loads(model_path.read_text(encoding="utf-8"))
        removed = model["world_requirements"].pop()
        model["authority_partition"]["downstream_freedom"].remove(removed["id"])
        self._reseal_model(model)

        with self.assertRaises(s1.S1Error) as caught:
            s1.validate_s1_package(self.package)

        self.assertEqual("S1_REQUIREMENT_COVERAGE_MISMATCH", caught.exception.code)

    def test_forged_model_gate_is_rejected_after_reseal(self) -> None:
        self.run_s1()
        model_path = self.package / "storyline-architecture.json"
        model = json.loads(model_path.read_text(encoding="utf-8"))
        model["input_gate"]["sha256"] = "0" * 64
        self._reseal_model(model, input_gate=model["input_gate"])

        with self.assertRaises(s1.S1Error) as caught:
            s1.validate_s1_package(self.package)

        self.assertEqual("S1_GATE_REFERENCE_MISMATCH", caught.exception.code)

    def test_missing_completion_is_not_a_ready_package(self) -> None:
        self.run_s1()
        (self.package / "stage-completion.json").unlink()

        with self.assertRaises(s1.S1Error) as caught:
            s1.validate_s1_package(self.package)

        self.assertEqual("S1_COMPLETION_MISSING", caught.exception.code)

    def test_opposite_source_values_change_all_agent_phase_payloads(self) -> None:
        baseline_model = json.loads(
            (self.b0 / "author-control-baseline.json").read_text(encoding="utf-8")
        )
        controls = s1._controls(self.b0, baseline_model)
        positive = copy.deepcopy(controls)
        negative = copy.deepcopy(controls)
        positive[0]["value"] = "The protected person must stay."
        negative[0]["value"] = "The protected person must leave."
        sources = copy.deepcopy(self.proposal["source_artifacts"])
        left = agent_proposal(
            run_id=self.sources.run_id,
            gate_reference=self.gate.reference,
            source_artifacts=sources,
            controls=positive,
        )
        right = agent_proposal(
            run_id=self.sources.run_id,
            gate_reference=self.gate.reference,
            source_artifacts=sources,
            controls=negative,
        )

        for phase in s1.PHASES:
            left_payload = (
                {"model": left}
                if phase == "final-storyline-model"
                else {field: left[field] for field in s1.PHASE_FIELDS[phase]}
            )
            right_payload = (
                {"model": right}
                if phase == "final-storyline-model"
                else {field: right[field] for field in s1.PHASE_FIELDS[phase]}
            )
            self.assertNotEqual(
                runtime.canonical_sha256(left_payload),
                runtime.canonical_sha256(right_payload),
                phase,
            )

    def _reseal_model(
        self,
        model: dict[str, object],
        *,
        input_gate: dict[str, str] | None = None,
    ) -> None:
        model_path = self.package / "storyline-architecture.json"
        model_path.write_text(runtime.canonical_json(model), encoding="utf-8")
        execution_path = self.package / "execution-record.json"
        execution = json.loads(execution_path.read_text(encoding="utf-8"))
        execution["output_sha256"] = runtime.canonical_sha256(model)
        if input_gate is not None:
            execution["input_gate"] = copy.deepcopy(input_gate)
        execution_path.write_text(
            runtime.canonical_json(execution), encoding="utf-8"
        )
        manifest_path = self.package / "package-manifest.json"
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
        replacements = {
            "storyline-architecture.json": runtime.artifact_reference(
                model_path, root=self.package
            ),
            "execution-record.json": runtime.artifact_reference(
                execution_path, root=self.package
            ),
        }
        manifest["files"] = [
            replacements.get(item["path"], item) for item in manifest["files"]
        ]
        manifest["artifact_roles"]["canonical"] = replacements[
            "storyline-architecture.json"
        ]
        manifest["artifact_roles"]["execution_record"] = replacements[
            "execution-record.json"
        ]
        manifest_path.write_text(runtime.canonical_json(manifest), encoding="utf-8")
        completion_path = self.package / "stage-completion.json"
        completion = json.loads(completion_path.read_text(encoding="utf-8"))
        completion["manifest"]["sha256"] = runtime.sha256_file(manifest_path)
        if input_gate is not None:
            completion["input_gate"] = copy.deepcopy(input_gate)
        completion_path.write_text(
            runtime.canonical_json(completion), encoding="utf-8"
        )


if __name__ == "__main__":
    unittest.main()
