---
name: novel-environment-system-designer
description: 把故事线和世界模型展开为可承载具体行动的环境、功能区、通道、权限、风险和转场条件。用于自主构思 V2 的 E1 阶段；不决定事件是否发生、人物最终选择或正文级场景细节。
---

# 小说具体环境系统设计

## 目标

让每项后续事件行为都有具体、可观察、可进入并受限制的承载环境。

## 权威契约

完整读取工作流第 3、6、14、15 节，以及：

- [E1 Schema](../../docs/ai-novel-workflow/contracts/autonomous-v2/environment-system.schema.json)；
- [E1 唯一运行契约](references/runtime-contract.md)。

## 唯一生产运行路径

只允许使用 `scripts/run_v2.py`。在同一 `CODEX_THREAD_ID` 中依次调用
`start_e1_session()`、按契约顺序调用 `submit_e1_phase()`、最后调用
`run_e1()`。不得跳过受控会话、倒填阶段证据、传入会话外的一次性完整候选稿，
也不得手写 validation、manifest 或 completion。`validate_e1_package()` 只用于
只读复验，不能替代上述生产调用。

## 输入硬准入

只接受当前 B0、S1、W1 completion、manifest、canonical 模型、E1 input gate 和
执行前 run-state。E1 `environment_demands` ID 集必须与 W1 交付精确相等。

## 职责

1. 定义主要环境的范围、叙事责任、特征、感知条件和状态词汇。
2. 定义功能区、拓扑、出入规则、权限、资源与信息通道。
3. 定义允许行为、阻碍、风险、失败方式和允许状态转移。
4. 证明每条结构故事线阶段都有环境承载。
5. 向 T1 提供事件可用条件和转场契约。

## 边界

- 不决定事件是否发生及其结果。
- 不编写场景调度、镜头、对白、装饰或氛围正文。
- 不修改世界规则；若 W1 无法承载需求，定向 return W1。
- 不创建人物心理或关系。

## 交付与验收

交付 `environment-system.json`、证据、validation、manifest 和 E1 completion。
ready 必须证明需求全覆盖、环境与功能区引用闭合、关键行动有 affordance、权限和资源
可执行、风险与失败真实存在、全部转场符合 W1。
