# Output Contract

The production scheduler returns a `ProductionContext` after every committed
transaction. Its state reference is the only current orchestration authority;
receipts do not replace stage packages or completion records.

The run root contains:

- append-only canonical `state/revision-NNN.json` snapshots;
- immutable gates and one-shot work orders with consumed receipts;
- the current H1 workspace chain;
- formal B0, S1, W1, E1, T1, C1, Q1 and P1 packages;
- H1-A plan, H1-B fragments, H1-A assembly, H1-C HTML and formal H1 package;
- the external author event and, for revise, its deterministic return body;
- final conception completion only on the current approved branch.

The machine conception deliverable is the current P1 package. The human
deliverable is the H1 report, fragments and offline HTML, all bound to that P1.
Development may start only when the latest persisted state has
`development_status=ready` and the final completion revalidates all nine stage
completions plus the current author approval.

Branches:

- `approved`: author state is persisted, then a resumable final transaction
  publishes development admission;
- `revise`: the return request is persisted before the revise state and names
  the exact owner/resume point; invalidated downstream packages are non-current;
- `rejected`: terminal state, no final completion.

The historical `HarnessRunReceipt` remains the result of the compatibility-only
`run_from_rendered_h1` API. It is not evidence that B0–H1 were production-
orchestrated.
