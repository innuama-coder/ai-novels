"""Production transaction guard for the complete conception chain.

Domain Agents still own semantic payloads and the existing stage runners keep
their contracts.  This module owns only durable ordering: it persists every
coordinator snapshot and H1 workspace, binds one current work order, and splits
H1/author/final into recoverable transactions.
"""

from __future__ import annotations

import copy
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable, Mapping

from .author_decision import AuthorDecisionReceipt, record_author_decision
from .canonical import canonical_sha256
from .contracts import ContractRuntime
from .coordinator import (
    AutonomousCoordinator,
    H1WorkspaceTransition,
    SealedDocument,
    StateTransition,
)
from .return_routing import STAGE_ORDER
from .final_completion import FinalCompletionReceipt, publish_final_completion
from .h1_completion import H1CompletionReceipt, publish_h1_completion
from .production_store import ProductionRunStore, ProductionStoreError


class ProductionOrchestratorError(ValueError):
    def __init__(self, code: str, message: str):
        self.code = code
        super().__init__(f"{code}: {message}")


ACTION_CONTRACT: dict[str, tuple[str | None, str]] = {
    "B0": ("B0", "baseline-controller"),
    "S1": ("S1", "novel-storyline-architecture-designer"),
    "W1": ("W1", "novel-world-model-designer"),
    "E1": ("E1", "novel-environment-system-designer"),
    "T1": ("T1", "novel-event-timeline-designer"),
    "C1": ("C1", "novel-character-system-designer"),
    # The Q1 owner internally coordinates its mandatory controller, semantic,
    # and isolated handoff contexts; only the final Q1 completion advances the
    # production chain.
    "Q1": ("Q1", "novel-conception-reviewer"),
    "P1": ("P1", "novel-conception-deliverable-assembler"),
    "H1-A-plan": ("H1", "novel-conception-human-review-assembler"),
    "H1-B": ("H1", "novel-conception-fragment-writer"),
    "H1-A-assemble": ("H1", "novel-conception-human-review-assembler"),
    "H1-C": ("H1", "novel-conception-review-html-generator"),
    "H1-publish": ("H1", "production-orchestrator"),
    "author-decision": (None, "external-author-forwarder"),
    "final": (None, "production-orchestrator"),
}
H1_ACTION_STATES = {
    "H1-A-plan": ("initialized", "planned"),
    "H1-B": ("planned", "fragments_ready"),
    "H1-A-assemble": ("fragments_ready", "assembled"),
    "H1-C": ("assembled", "rendered"),
    "H1-publish": ("rendered", None),
}


@dataclass(frozen=True)
class ProductionContext:
    store: ProductionRunStore
    coordinator: AutonomousCoordinator
    state: SealedDocument
    active_return: SealedDocument | None


def _sealed(transition: StateTransition) -> SealedDocument:
    return SealedDocument(
        data=copy.deepcopy(transition.snapshot),
        reference=copy.deepcopy(transition.reference),
    )


def _require_context_current(
    context: ProductionContext, latest: SealedDocument
) -> None:
    if latest.reference != context.state.reference:
        raise ProductionOrchestratorError(
            "PROD_CONTEXT_STALE", "resume the production run before advancing"
        )


def _require_work_actor(work_order: SealedDocument, actor: str) -> None:
    action = work_order.data.get("action")
    contract = ACTION_CONTRACT.get(str(action))
    required = work_order.data.get("required_actor")
    if (
        contract is None
        or not isinstance(actor, str)
        or not actor
        or required != contract[1]
        or actor != required
    ):
        raise ProductionOrchestratorError(
            "PROD_WORK_ACTOR_MISMATCH",
            f"{action} requires {required}",
        )


def _bound_h1_workspace(
    context: ProductionContext, work_order: SealedDocument
) -> SealedDocument:
    reference = work_order.data.get("h1_workspace")
    if not isinstance(reference, Mapping):
        raise ProductionOrchestratorError(
            "PROD_H1_WORKSPACE_UNBOUND", str(work_order.data.get("action"))
        )
    bound = context.store.load_document(reference)
    latest = context.store.latest_workspace()
    if latest.reference != bound.reference or latest.data != bound.data:
        raise ProductionOrchestratorError(
            "PROD_H1_WORKSPACE_STALE", str(work_order.data.get("action"))
        )
    return bound


def _prepare_state_commit(
    context: ProductionContext,
    work_order: SealedDocument,
    successor: SealedDocument,
    evidence: SealedDocument,
    *,
    return_request: SealedDocument | None = None,
) -> None:
    """Recompute the normative full transition before journaling it."""

    action = str(work_order.data.get("action"))
    fresh = AutonomousCoordinator.from_snapshot(
        copy.deepcopy(context.state.data),
        copy.deepcopy(context.state.reference),
        active_return_request=context.active_return,
        runtime=context.store.runtime,
    )
    next_state_path = str(successor.reference.get("path"))
    try:
        if action in STAGE_ORDER[:-1] or action == "H1-publish":
            gate = context.store.load_document(work_order.data["input_gate"])
            workspace_reference = None
            if action == "H1-publish":
                workspace_reference = _bound_h1_workspace(
                    context, work_order
                ).reference
            expected = fresh.accept_stage_completion(
                gate=gate,
                completion=evidence,
                h1_workspace=workspace_reference,
                next_state_path=next_state_path,
                active_return_request=context.active_return,
            )
        elif action == "author-decision":
            return_id = (
                return_request.data["return_id"]
                if return_request is not None
                else "RET-AUTHOR-REVISION"
            )
            recomputed = record_author_decision(
                event=evidence,
                coordinator=fresh,
                next_state_path=next_state_path,
                return_id=return_id,
                runtime=context.store.runtime,
            )
            if (
                recomputed.return_request is None
                and return_request is not None
            ) or (
                recomputed.return_request is not None
                and (
                    return_request is None
                    or recomputed.return_request.reference
                    != return_request.reference
                    or recomputed.return_request.data != return_request.data
                )
            ):
                raise ProductionOrchestratorError(
                    "PROD_COMMIT_EVIDENCE_INVALID", "author return request"
                )
            expected = recomputed.transition
        elif action == "final":
            expected = fresh.accept_final_completion(
                completion=evidence,
                next_state_path=next_state_path,
            )
        else:
            raise ProductionOrchestratorError("PROD_ACTION_UNKNOWN", action)
    except ProductionOrchestratorError:
        raise
    except Exception as error:
        raise ProductionOrchestratorError(
            "PROD_COMMIT_EVIDENCE_INVALID", str(error)
        ) from error
    if (
        expected.snapshot != successor.data
        or expected.reference != successor.reference
    ):
        raise ProductionOrchestratorError(
            "PROD_COMMIT_DELTA_INVALID", action
        )
    context.store.persist_document(evidence)
    context.store._persist_commit_intent(
        work_order,
        successor=successor,
        successor_kind="state",
        evidence=evidence,
    )


def _prepare_h1_commit(
    context: ProductionContext,
    work_order: SealedDocument,
    *,
    bound: SealedDocument,
    successor: SealedDocument,
    manifest: SealedDocument,
) -> None:
    """Prove the exact owner manifest and one legal H1 workspace delta."""

    contracts = {
        "H1-A-plan": ("initialized", "planned", "plan_manifest", "h1-plan"),
        "H1-B": (
            "planned",
            "fragments_ready",
            "fragment_manifest",
            "h1-fragments",
        ),
        "H1-A-assemble": (
            "fragments_ready",
            "assembled",
            "assembly_manifest",
            "h1-assembly",
        ),
        "H1-C": ("assembled", "rendered", "html_manifest", "h1-html"),
    }
    action = str(work_order.data.get("action"))
    expected = contracts.get(action)
    if expected is None:
        raise ProductionOrchestratorError("PROD_ACTION_UNKNOWN", action)
    prior_state, next_state, artifact_key, profile = expected
    expected_artifacts = {
        **bound.data["artifacts"],
        artifact_key: manifest.reference,
    }
    if (
        bound.data.get("state") != prior_state
        or successor.data.get("state") != next_state
        or successor.data.get("run_id") != bound.data.get("run_id")
        or successor.data.get("session_id") != bound.data.get("session_id")
        or successor.data.get("p1_completion")
        != bound.data.get("p1_completion")
        or successor.data.get("previous_state_sha256")
        != bound.reference["sha256"]
        or successor.data.get("artifacts") != expected_artifacts
    ):
        raise ProductionOrchestratorError(
            "PROD_COMMIT_DELTA_INVALID", action
        )
    try:
        context.store.runtime.validate(
            manifest.data, "package-manifest.schema.json"
        )
    except Exception as error:
        raise ProductionOrchestratorError(
            "PROD_COMMIT_EVIDENCE_INVALID", str(error)
        ) from error
    if (
        canonical_sha256(manifest.data) != manifest.reference.get("sha256")
        or manifest.data.get("run_id") != bound.data.get("run_id")
        or manifest.data.get("stage") != "H1"
        or manifest.data.get("package_profile") != profile
        or manifest.data.get("verdict") != "ready"
        or manifest.data.get("session_id") != bound.data.get("session_id")
        or manifest.data.get("parent_state_sha256")
        != bound.reference["sha256"]
    ):
        raise ProductionOrchestratorError(
            "PROD_COMMIT_EVIDENCE_INVALID", action
        )
    context.store.persist_document(manifest)
    context.store._persist_commit_intent(
        work_order,
        successor=successor,
        successor_kind="h1-workspace",
        evidence=manifest,
    )


def _reconcile_pending_commit(
    store: ProductionRunStore, state: SealedDocument
) -> None:
    """Reconcile only a successor named by the immutable prepared intent."""

    order = store.pending_work_order()
    if order is None:
        return
    intent = store._load_commit_intent(order)
    if order.data.get("state") != state.reference:
        if (
            intent is None
            or intent.data.get("successor_kind") != "state"
            or intent.data.get("successor") != state.reference
        ):
            raise ProductionOrchestratorError(
                "PROD_UNJOURNALED_SUCCESSOR", str(order.data.get("work_id"))
            )
        store.mark_work_order_consumed(order, successor=state)
        return
    action = str(order.data.get("action"))
    if action not in H1_ACTION_STATES or action == "H1-publish":
        return
    bound_ref = order.data.get("h1_workspace")
    if not isinstance(bound_ref, Mapping):
        raise ProductionOrchestratorError(
            "PROD_H1_WORKSPACE_UNBOUND", action
        )
    current = store.latest_workspace()
    if current.reference == bound_ref:
        return
    if (
        intent is None
        or intent.data.get("successor_kind") != "h1-workspace"
        or intent.data.get("successor") != current.reference
    ):
        raise ProductionOrchestratorError(
            "PROD_UNJOURNALED_SUCCESSOR", str(order.data.get("work_id"))
        )
    store.mark_work_order_consumed(order, successor=current)


def initialize_production_run(
    run_root: str | Path,
    *,
    run_id: str,
    source_interview_state: Mapping[str, str],
    runtime: ContractRuntime | None = None,
) -> ProductionContext:
    contract_runtime = runtime or ContractRuntime()
    store = ProductionRunStore(run_root, runtime=contract_runtime)
    with store.lock():
        store.ensure_uninitialized()
        coordinator = AutonomousCoordinator.initialize(
            run_id=run_id,
            source_interview_state=source_interview_state,
            state_path="state/revision-000.json",
            runtime=contract_runtime,
        )
        state = SealedDocument(
            data=coordinator.state, reference=coordinator.state_reference
        )
        store.persist_state(state)
    return ProductionContext(store, coordinator, state, None)


def resume_production_run(
    run_root: str | Path, *, runtime: ContractRuntime | None = None
) -> ProductionContext:
    contract_runtime = runtime or ContractRuntime()
    store = ProductionRunStore(run_root, runtime=contract_runtime)
    with store.lock():
        state = store.latest_state()
        _reconcile_pending_commit(store, state)
        # Canonical JSON sorts object keys; restore the normative stage order
        # required by author-decision validation without changing the hash.
        state_data = copy.deepcopy(state.data)
        current = state_data["current_stage_completions"]
        state_data["current_stage_completions"] = {
            stage: current[stage] for stage in STAGE_ORDER if stage in current
        }
        state = SealedDocument(data=state_data, reference=state.reference)
        active = None
        if state.data["active_return"] is not None:
            active = store.load_document(state.data["active_return"])
        coordinator = AutonomousCoordinator.from_snapshot(
            state.data,
            state.reference,
            active_return_request=active,
            runtime=contract_runtime,
        )
    return ProductionContext(store, coordinator, state, active)


def issue_stage_work(
    context: ProductionContext,
    *,
    action: str,
    inputs: Mapping[str, Any],
) -> tuple[SealedDocument, SealedDocument]:
    """Build the exact current gate and publish the unique Agent work order."""

    with context.store.lock():
        latest = context.store.latest_state()
        _require_context_current(context, latest)
        contract = ACTION_CONTRACT.get(action)
        if contract is None:
            raise ProductionOrchestratorError("PROD_ACTION_UNKNOWN", action)
        target_stage, required_actor = contract
        if action == "author-decision" and latest.data["status"] != "waiting_author":
            raise ProductionOrchestratorError(
                "PROD_ACTION_NOT_READY", "author decision requires waiting_author"
            )
        if action == "final" and latest.data["status"] != "approved":
            raise ProductionOrchestratorError(
                "PROD_ACTION_NOT_READY", "final requires approved"
            )
        if action in H1_ACTION_STATES:
            workspace = context.store.latest_workspace()
            required_state = H1_ACTION_STATES[action][0]
            if workspace.data["state"] != required_state:
                raise ProductionOrchestratorError(
                    "PROD_ACTION_NOT_READY",
                    f"{action} requires H1 workspace {required_state}",
                )
        gate = None
        workspace = None
        if target_stage is not None:
            gate_path = (
                "orchestration/input-gates/"
                f"revision-{latest.data['revision']:03d}-{action}.json"
            )
            gate = context.coordinator.build_input_gate(
                target_stage, gate_path,
                active_return_request=context.active_return,
            )
            context.store.persist_document(gate)
        if action in H1_ACTION_STATES:
            workspace = context.store.latest_workspace()
        order = context.store.issue_work_order(
            run_id=context.state.data["run_id"],
            action=action,
            state=context.state,
            input_gate=gate,
            h1_workspace=workspace,
            required_actor=required_actor,
            inputs=inputs,
        )
        return gate, order


def initialize_h1_workspace(
    context: ProductionContext, *, session_id: str
) -> SealedDocument:
    """Create the deterministic H1 ``initialized`` workspace after current P1."""

    with context.store.lock():
        latest = context.store.latest_state()
        if latest.reference != context.state.reference:
            raise ProductionOrchestratorError(
                "PROD_CONTEXT_STALE", "reload before initializing H1"
            )
        current = latest.data["current_stage_completions"]
        if set(current) != set(STAGE_ORDER[:-1]) or len(current) != len(
            STAGE_ORDER[:-1]
        ):
            raise ProductionOrchestratorError(
                "PROD_ACTION_NOT_READY", "H1 initialization requires B0-P1"
            )
        try:
            prior = context.store.latest_workspace()
        except ProductionStoreError as error:
            if error.code != "PROD_H1_WORKSPACE_MISSING":
                raise
            prior = None
        if prior is not None:
            same_p1 = prior.data["p1_completion"] == current["P1"]
            if (
                same_p1
                and prior.data["state"] == "initialized"
                and prior.data["session_id"] == session_id
            ):
                return prior
            h1_return = (
                context.active_return is not None
                and context.active_return.data.get("resume_stage") == "H1"
            )
            if same_p1 and not (
                h1_return and prior.data["state"] == "rendered"
            ):
                raise ProductionOrchestratorError(
                    "PROD_H1_SESSION_EXISTS",
                    "resume the current H1 workspace instead of replacing it",
                )
            if same_p1 and prior.data["session_id"] == session_id:
                raise ProductionOrchestratorError(
                    "PROD_H1_SESSION_ID_REUSED",
                    "an H1 revision requires a new session_id",
                )
        data = {
            "schema_version": "2.0",
            "run_id": latest.data["run_id"],
            "stage": "H1",
            "session_id": session_id,
            "state": "initialized",
            "p1_completion": copy.deepcopy(current["P1"]),
            "previous_state_sha256": None,
            "artifacts": {},
        }
        workspace = SealedDocument(
            data=data,
            reference={
                "path": f"H1/{session_id}/workspace-initialized.json",
                "sha256": canonical_sha256(data),
            },
        )
        context.store.persist_workspace(workspace)
        return workspace


def execute_stage_work(
    context: ProductionContext,
    *,
    work_order: SealedDocument,
    actor: str,
    executor: Callable[[AutonomousCoordinator, SealedDocument], Any],
) -> tuple[Any, ProductionContext]:
    """Execute one existing stage runner and durably commit its transition.

    The callback is the only semantic seam.  It must call the stage's existing
    start/submit/run API and return a receipt exposing ``transition``.
    """

    with context.store.lock():
        latest = context.store.latest_state()
        _require_context_current(context, latest)
        context.store.require_current_work_order(work_order, state=latest)
        _require_work_actor(work_order, actor)
        gate_ref = work_order.data.get("input_gate")
        if not isinstance(gate_ref, Mapping):
            raise ProductionOrchestratorError(
                "PROD_WORK_GATE_MISSING", str(work_order.data.get("work_id"))
            )
        gate = context.store.load_document(gate_ref)
        receipt = executor(context.coordinator, gate)
        transition = getattr(receipt, "transition", None)
        completion = getattr(receipt, "completion", None)
        if not isinstance(transition, StateTransition):
            raise ProductionOrchestratorError(
                "PROD_STAGE_RECEIPT_INVALID", "executor returned no StateTransition"
            )
        if not isinstance(completion, SealedDocument):
            raise ProductionOrchestratorError(
                "PROD_STAGE_RECEIPT_INVALID", "executor returned no completion"
            )
        successor = _sealed(transition)
        _prepare_state_commit(context, work_order, successor, completion)
        context.store.persist_state(successor)
        context.store.mark_work_order_consumed(work_order, successor=successor)
    return receipt, ProductionContext(
        context.store, context.coordinator, successor, None
    )


def recover_stage_admission(
    context: ProductionContext,
    *,
    work_order: SealedDocument,
    actor: str,
    completion: SealedDocument,
) -> ProductionContext:
    """Admit a validator-proven package orphan after a worker crash.

    The caller must first run the owning skill's public package validator and
    seal its persisted ``stage-completion.json``.  No package is repaired.
    """

    with context.store.lock():
        latest = context.store.latest_state()
        _require_context_current(context, latest)
        context.store.require_current_work_order(work_order, state=latest)
        _require_work_actor(work_order, actor)
        gate = context.store.load_document(work_order.data["input_gate"])
        transition = context.coordinator.accept_stage_completion(
            gate=gate,
            completion=completion,
            next_state_path=(
                f"state/revision-{context.state.data['revision'] + 1:03d}.json"
            ),
            active_return_request=context.active_return,
        )
        successor = _sealed(transition)
        _prepare_state_commit(context, work_order, successor, completion)
        context.store.persist_state(successor)
        context.store.mark_work_order_consumed(work_order, successor=successor)
    return ProductionContext(
        context.store, context.coordinator, successor, None
    )


def commit_h1_workspace(
    context: ProductionContext,
    *,
    work_order: SealedDocument,
    actor: str,
    executor: Callable[[AutonomousCoordinator, SealedDocument], Any],
) -> tuple[Any, SealedDocument]:
    """Commit one H1-A/B/C package and its durable internal workspace."""

    with context.store.lock():
        latest = context.store.latest_state()
        _require_context_current(context, latest)
        context.store.require_current_work_order(work_order, state=latest)
        _require_work_actor(work_order, actor)
        bound = _bound_h1_workspace(context, work_order)
        gate = context.store.load_document(work_order.data["input_gate"])
        receipt = executor(context.coordinator, gate)
        transition = getattr(receipt, "transition", None)
        if not isinstance(transition, H1WorkspaceTransition):
            raise ProductionOrchestratorError(
                "PROD_H1_RECEIPT_INVALID", "executor returned no H1 workspace"
            )
        workspace = transition.workspace
        action = work_order.data["action"]
        expected = H1_ACTION_STATES.get(action)
        if expected is None or expected[1] != workspace.data["state"]:
            raise ProductionOrchestratorError(
                "PROD_H1_ACTION_MISMATCH", str(action)
            )
        if (
            workspace.data.get("previous_state_sha256")
            != bound.reference["sha256"]
            or workspace.data.get("session_id") != bound.data.get("session_id")
            or workspace.data.get("p1_completion")
            != bound.data.get("p1_completion")
        ):
            raise ProductionOrchestratorError(
                "PROD_H1_WORKSPACE_STALE", str(action)
            )
        manifest_data = getattr(receipt, "manifest", None)
        added = set(workspace.data["artifacts"]) - set(bound.data["artifacts"])
        if not isinstance(manifest_data, Mapping) or len(added) != 1:
            raise ProductionOrchestratorError(
                "PROD_H1_RECEIPT_INVALID", "executor returned no exact manifest"
            )
        manifest_reference = workspace.data["artifacts"][added.pop()]
        manifest = SealedDocument(
            data=copy.deepcopy(dict(manifest_data)),
            reference=copy.deepcopy(dict(manifest_reference)),
        )
        _prepare_h1_commit(
            context,
            work_order,
            bound=bound,
            successor=workspace,
            manifest=manifest,
        )
        context.store.persist_workspace(workspace)
        context.store.mark_work_order_consumed(work_order, successor=workspace)
        return receipt, workspace


def recover_h1_workspace(
    context: ProductionContext,
    *,
    work_order: SealedDocument,
    actor: str,
    current_workspace: SealedDocument,
    package_manifest: SealedDocument,
    expected_next_state: str,
) -> SealedDocument:
    """Reconstruct one validated H1 package orphan without regenerating it."""

    with context.store.lock():
        latest = context.store.latest_state()
        _require_context_current(context, latest)
        context.store.require_current_work_order(work_order, state=latest)
        _require_work_actor(work_order, actor)
        bound = _bound_h1_workspace(context, work_order)
        if (
            current_workspace.reference != bound.reference
            or current_workspace.data != bound.data
        ):
            raise ProductionOrchestratorError(
                "PROD_H1_WORKSPACE_STALE", str(work_order.data.get("action"))
            )
        transition = context.coordinator.accept_h1_workspace_transition(
            current_workspace=current_workspace,
            package_manifest=package_manifest,
            expected_next_state=expected_next_state,
            active_return_request=context.active_return,
        )
        workspace = transition.workspace
        action = work_order.data["action"]
        expected = H1_ACTION_STATES.get(action)
        if expected is None or expected[1] != workspace.data["state"]:
            raise ProductionOrchestratorError(
                "PROD_H1_ACTION_MISMATCH", str(action)
            )
        _prepare_h1_commit(
            context,
            work_order,
            bound=bound,
            successor=workspace,
            manifest=package_manifest,
        )
        context.store.persist_workspace(workspace)
        context.store.mark_work_order_consumed(work_order, successor=workspace)
        return workspace


def publish_h1_transaction(
    context: ProductionContext,
    output_root: str | Path,
    *,
    work_order: SealedDocument,
    **arguments: Any,
) -> tuple[H1CompletionReceipt, ProductionContext]:
    """Publish H1 and persist ``waiting_author`` before accepting a decision."""

    with context.store.lock():
        latest = context.store.latest_state()
        _require_context_current(context, latest)
        context.store.require_current_work_order(work_order, state=latest)
        if work_order.data["action"] != "H1-publish":
            raise ProductionOrchestratorError("PROD_ACTION_MISMATCH", "H1-publish")
        bound = _bound_h1_workspace(context, work_order)
        rendered = arguments.get("rendered_workspace")
        if (
            not isinstance(rendered, SealedDocument)
            or rendered.reference != bound.reference
            or rendered.data != bound.data
        ):
            raise ProductionOrchestratorError(
                "PROD_H1_WORKSPACE_STALE", "H1-publish"
            )
        receipt = publish_h1_completion(
            output_root,
            coordinator=context.coordinator,
            next_state_path=(
                f"state/revision-{context.state.data['revision'] + 1:03d}.json"
            ),
            active_return_request=context.active_return,
            runtime=context.store.runtime,
            **arguments,
        )
        successor = _sealed(receipt.transition)
        _prepare_state_commit(
            context, work_order, successor, receipt.completion
        )
        context.store.persist_state(successor)
        context.store.mark_work_order_consumed(work_order, successor=successor)
    return receipt, ProductionContext(
        context.store, context.coordinator, successor, None
    )


def record_author_transaction(
    context: ProductionContext,
    *,
    work_order: SealedDocument,
    event: SealedDocument,
    **arguments: Any,
) -> tuple[AuthorDecisionReceipt, ProductionContext]:
    """Consume an external event and persist return body before revise state."""

    with context.store.lock():
        latest = context.store.latest_state()
        _require_context_current(context, latest)
        context.store.require_current_work_order(work_order, state=latest)
        if work_order.data["action"] != "author-decision":
            raise ProductionOrchestratorError(
                "PROD_ACTION_MISMATCH", "author-decision"
            )
        receipt = record_author_decision(
            event=event,
            coordinator=context.coordinator,
            next_state_path=(
                f"state/revision-{context.state.data['revision'] + 1:03d}.json"
            ),
            runtime=context.store.runtime,
            **arguments,
        )
        if receipt.return_request is not None:
            context.store.persist_document(receipt.return_request)
        successor = _sealed(receipt.transition)
        _prepare_state_commit(
            context,
            work_order,
            successor,
            receipt.decision,
            return_request=receipt.return_request,
        )
        context.store.persist_state(successor)
        context.store.mark_work_order_consumed(work_order, successor=successor)
    return receipt, ProductionContext(
        context.store,
        context.coordinator,
        successor,
        receipt.return_request,
    )


def publish_final_transaction(
    context: ProductionContext,
    output_root: str | Path,
    *,
    work_order: SealedDocument,
    **arguments: Any,
) -> tuple[FinalCompletionReceipt, ProductionContext]:
    """Publish/recover final completion and durably grant admission."""

    with context.store.lock():
        latest = context.store.latest_state()
        _require_context_current(context, latest)
        context.store.require_current_work_order(work_order, state=latest)
        if work_order.data["action"] != "final":
            raise ProductionOrchestratorError("PROD_ACTION_MISMATCH", "final")
        receipt = publish_final_completion(
            output_root,
            coordinator=context.coordinator,
            next_state_path=(
                f"state/revision-{context.state.data['revision'] + 1:03d}.json"
            ),
            runtime=context.store.runtime,
            **arguments,
        )
        successor = _sealed(receipt.transition)
        _prepare_state_commit(
            context, work_order, successor, receipt.completion
        )
        context.store.persist_state(successor)
        context.store.mark_work_order_consumed(work_order, successor=successor)
    return receipt, ProductionContext(
        context.store, context.coordinator, successor, None
    )


__all__ = [
    "ProductionContext",
    "ProductionOrchestratorError",
    "ACTION_CONTRACT",
    "H1_ACTION_STATES",
    "commit_h1_workspace",
    "execute_stage_work",
    "initialize_production_run",
    "initialize_h1_workspace",
    "issue_stage_work",
    "publish_final_transaction",
    "publish_h1_transaction",
    "recover_h1_workspace",
    "recover_stage_admission",
    "record_author_transaction",
    "resume_production_run",
]
