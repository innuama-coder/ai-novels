from __future__ import annotations

import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from runtime.contracts import invalidated_suffix, owner_for_id  # noqa: E402


class OwnerRoutingTests(unittest.TestCase):
    def test_hk1_lwr_and_hp1_lwk_have_distinct_owners(self) -> None:
        self.assertEqual(owner_for_id("LWR-001"), "HK1")
        self.assertEqual(owner_for_id("LWK-001"), "HP1")

    def test_revision_suffix_uses_canonical_lwr_owner(self) -> None:
        suffix = invalidated_suffix(owner_for_id("LWR-001"), "hld_content")
        self.assertEqual(suffix[0], "HK1")
        self.assertIn("HP1", suffix)
        self.assertIn("HF1", suffix)


if __name__ == "__main__":
    unittest.main()
