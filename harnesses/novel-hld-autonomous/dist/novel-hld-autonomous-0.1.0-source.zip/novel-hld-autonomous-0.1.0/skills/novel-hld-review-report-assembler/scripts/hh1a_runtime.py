#!/usr/bin/env python3
"""Public HH1-A hybrid runtime: admit HP1/HQ2, validate a semantic draft, seal atomically."""

from __future__ import annotations

import argparse
import json
import re
import shutil
import sys
from pathlib import Path
from typing import Any, Mapping

SKILL_ROOT=Path(__file__).resolve().parents[1];REPO=SKILL_ROOT.parents[1];HARNESS_ROOT=REPO/"harnesses/novel-hld-autonomous"
sys.path.insert(0,str(HARNESS_ROOT))
from runtime.canonical import ContractError, canonical_sha256, json_pointer, read_json, write_json  # noqa:E402
from runtime.composite_internal_runtime import (Context,InternalCondition,InternalRuntimeError,Spec,atomic_execute,catalog,finalize_condition,finalize_ready,finalize_runtime_error,implementation_sha256,load_context,sha256)  # noqa:E402

SKILL="novel-hld-review-report-assembler";VERSION="1.0.0"
MODEL_ROLES={
 "hld_model_ha1":"canonical-models/narrative-architecture.json","hld_model_hs1":"canonical-models/storyline-choreography.json",
 "hld_model_hc1":"canonical-models/character-arc-placement.json","hld_model_hi1":"canonical-models/narrative-information-architecture.json",
 "hld_model_hr1":"canonical-models/rhythm-continuity-architecture.json","hld_model_hk1":"canonical-models/key-scene-function-map.json",
}
HP1_PACKAGE_SCHEMA=REPO/"skills/novel-hld-package-assembler/references/novel-hld-package.schema.json"
HP1_CROSS_INDEX_SCHEMA=REPO/"skills/novel-hld-package-assembler/references/hld-cross-index.schema.json"
REQUIRED_ROLES=("hb0_completion","hp1_completion","hp1_manifest","hp1_validation","novel_hld_package","hld_cross_index","hld_traceability_matrix","hld_spec",*MODEL_ROLES,"hq2_completion","hq2_manifest","hq2_validation","lld_handoff_acceptance")
SPEC=Spec(SKILL,VERSION,"HH1.A","hld-human-review-report.json","human_review_report","generation-session.json","report-assembly-execution.json","hh1-a-validation.schema.json",REQUIRED_ROLES,True)
DOMAIN_BY_ROLE={"hld_model_ha1":"overall_narrative_architecture","hld_model_hs1":"storyline_choreography","hld_model_hc1":"character_arc_placement","hld_model_hi1":"pov_information_suspense","hld_model_hr1":"time_space_pacing_tension","hld_model_hk1":"key_scene_functions"}
DOMAIN_SECTIONS=tuple(DOMAIN_BY_ROLE.values())+("open_items_constraints_and_lld_boundary",)
IDENTITY_FIELDS={"schema_version","skill","stage","hld_run_id","status","input_gate_ref","source_artifacts","derivation_claims","decision_dependencies"}
CJK=re.compile(r"[\u3400-\u4dbf\u4e00-\u9fff\uf900-\ufaff]");LATIN=re.compile(r"\b[A-Za-z]+(?:['’][A-Za-z]+)*\b")
SCHEMA_NAMES=("hld-human-review-report.schema.json","hh1-a-generation-session.schema.json","hh1-a-material-inventory.schema.json","hh1-a-organization.schema.json","hh1-a-adversarial-review.schema.json","hh1-a-execution.schema.json","hh1-a-validation.schema.json")

def schema_paths():return [*(SKILL_ROOT/"references"/name for name in SCHEMA_NAMES),HP1_PACKAGE_SCHEMA,HP1_CROSS_INDEX_SCHEMA]
def implementation_paths():return [Path(__file__),SKILL_ROOT/"scripts/run_skill.py",SKILL_ROOT/"references/runtime-contract.json",HARNESS_ROOT/"runtime/composite_internal_runtime.py",HARNESS_ROOT/"runtime/canonical.py",HARNESS_ROOT/"runtime/package_envelope.py",HARNESS_ROOT/"runtime/schema_catalog.py",*sorted((HARNESS_ROOT/"schemas").glob("*.schema.json")),*schema_paths()]
def impl_hash():return implementation_sha256(implementation_paths())
def _catalog():return catalog(HARNESS_ROOT,schema_paths())

def _member(manifest:Mapping[str,Any],path:Path,package:Path)->bool:
    try:relative=path.resolve(strict=True).relative_to(package.resolve(strict=True)).as_posix()
    except ValueError:return False
    return sum(1 for item in manifest.get("files",[]) if item.get("path")==relative and item.get("sha256")==sha256(path))==1

def _artifact(ref:Mapping[str,Any],main:Path,manifest:Path,completion:Path,workspace:Path)->bool:
    return ref=={"path":main.relative_to(workspace).as_posix(),"sha256":sha256(main),"manifest_path":manifest.relative_to(workspace).as_posix(),"manifest_sha256":sha256(manifest),"completion_path":completion.relative_to(workspace).as_posix(),"completion_sha256":sha256(completion)}

def admit(context:Context)->dict[str,Any]:
    if len(context.work_order["upstream_completions"])!=3:raise InternalCondition("blocked","HH1A_UPSTREAM_TOPOLOGY","expected ordered HB0, HP1, HQ2",blocker_class="input_invalid")
    machine=read_json(context.roles["novel_hld_package"]);hp1_manifest=read_json(context.roles["hp1_manifest"]);hp1_completion=read_json(context.roles["hp1_completion"]);hp1_validation=read_json(context.roles["hp1_validation"])
    q2=read_json(context.roles["lld_handoff_acceptance"]);q2_manifest=read_json(context.roles["hq2_manifest"]);q2_completion=read_json(context.roles["hq2_completion"]);q2_validation=read_json(context.roles["hq2_validation"]);hb0_completion=read_json(context.roles["hb0_completion"])
    for value,schema in ((hp1_manifest,"package-manifest.schema.json"),(hp1_completion,"stage-completion.schema.json"),(q2,"lld-handoff-acceptance.schema.json"),(q2_manifest,"package-manifest.schema.json"),(q2_completion,"stage-completion.schema.json"),(hb0_completion,"stage-completion.schema.json")):
        context.catalog.validate(value,schema)
    run=context.work_order["hld_run_id"];revision=context.work_order["revision"]
    if (machine.get("stage"),machine.get("hld_run_id"),machine.get("status"))!=("HP1",run,"ready") or hp1_completion.get("revision")!=revision or hp1_validation.get("status")!="pass":raise InternalCondition("blocked","HH1A_HP1_NOT_CURRENT_READY","HP1 identity/revision/validation mismatch",["HP1"])
    if (q2.get("stage"),q2.get("hld_run_id"),q2.get("revision"),q2.get("status"))!=("HQ2",run,revision,"ready") or q2_validation.get("status")!="pass":raise InternalCondition("blocked","HH1A_HQ2_NOT_CURRENT_READY","HQ2 identity/revision/validation mismatch",["HQ2"])
    if hp1_completion["manifest_ref"]["sha256"]!=sha256(context.roles["hp1_manifest"]) or hp1_completion["validation_ref"]["sha256"]!=sha256(context.roles["hp1_validation"]):raise InternalCondition("blocked","HH1A_HP1_ENVELOPE_DRIFT","HP1 completion bindings drift",["HP1"])
    if q2_completion["manifest_ref"]["sha256"]!=sha256(context.roles["hq2_manifest"]) or q2_completion["validation_ref"]["sha256"]!=sha256(context.roles["hq2_validation"]):raise InternalCondition("blocked","HH1A_HQ2_ENVELOPE_DRIFT","HQ2 completion bindings drift",["HQ2"])
    for role in ("novel_hld_package","hld_cross_index","hld_traceability_matrix","hld_spec",*MODEL_ROLES):
        if not _member(hp1_manifest,context.roles[role],context.roles["hp1_manifest"].parent):raise InternalCondition("blocked","HH1A_HP1_MEMBER_UNSEALED",role,[role])
    for role in ("lld_handoff_acceptance","hq2_validation"):
        if not _member(q2_manifest,context.roles[role],context.roles["hq2_manifest"].parent):raise InternalCondition("blocked","HH1A_HQ2_MEMBER_UNSEALED",role,[role])
    if not _artifact(context.work_order["upstream_completions"][1],context.roles["novel_hld_package"],context.roles["hp1_manifest"],context.roles["hp1_completion"],context.workspace):raise InternalCondition("blocked","HH1A_HP1_ARTIFACT_DRIFT","work-order HP1 artifact differs from sealed inputs",["HP1"])
    if not _artifact(context.work_order["upstream_completions"][2],context.roles["lld_handoff_acceptance"],context.roles["hq2_manifest"],context.roles["hq2_completion"],context.workspace):raise InternalCondition("blocked","HH1A_HQ2_ARTIFACT_DRIFT","work-order HQ2 artifact differs from sealed inputs",["HQ2"])
    hb=context.work_order["upstream_completions"][0]
    if hb.get("completion_path")!=context.roles["hb0_completion"].relative_to(context.workspace).as_posix() or hb.get("completion_sha256")!=sha256(context.roles["hb0_completion"]):raise InternalCondition("blocked","HH1A_HB0_ARTIFACT_DRIFT","HB0 completion binding drift",["HB0"])
    if q2["hp1_completion_ref"]!={"role":q2["hp1_completion_ref"]["role"],"path":context.roles["hp1_completion"].relative_to(context.workspace).as_posix(),"sha256":sha256(context.roles["hp1_completion"])} or q2["hb0_completion_ref"]["sha256"]!=sha256(context.roles["hb0_completion"]):raise InternalCondition("blocked","HH1A_Q2_BASELINE_BINDING_DRIFT","HQ2 does not bind current HP1/HB0",["HQ2"])
    context.catalog.validate(machine,HP1_PACKAGE_SCHEMA.name)
    cross_index=read_json(context.roles["hld_cross_index"]);context.catalog.validate(cross_index,HP1_CROSS_INDEX_SCHEMA.name)
    models={role:read_json(context.roles[role]) for role in MODEL_ROLES}
    expected_stages={role[10:].upper() for role in MODEL_ROLES}
    if {value.get("stage") for value in models.values()}!=expected_stages or any(value.get("hld_run_id")!=run or value.get("status")!="ready" for value in models.values()):raise InternalCondition("blocked","HH1A_CANONICAL_IDENTITY_DRIFT","one or more HP1 canonical-model copies are not current ready",sorted(expected_stages))
    documents={"novel-hld-package.json":machine,**{MODEL_ROLES[role]:value for role,value in models.items()}}
    binding_index={}
    for item in cross_index["entries"]:
        model_path=item["model_path"];locator=f"{model_path}#{item['locator']}";key=(item["id"],locator)
        if model_path not in documents or key in binding_index or canonical_sha256(json_pointer(documents[model_path],item["locator"]))!=item["value_sha256"]:raise InternalCondition("blocked","HH1A_CROSS_INDEX_VALUE_DRIFT",f"cross-index entry is not a unique value-bound locator: {item['id']}",[item["id"]])
        binding_index[key]=item
    return {"machine":machine,"models":models,"hp1_completion":hp1_completion,"q2":q2,"cross_entries":cross_index["entries"],"binding_index":binding_index}

def material_locator_map(admitted:Mapping[str,Any])->dict[str,str]:
    by_path={name:DOMAIN_BY_ROLE[role] for role,name in MODEL_ROLES.items()};by_path["novel-hld-package.json"]="open_items_constraints_and_lld_boundary"
    return {f"{item['model_path']}#{item['locator']}":by_path[item["model_path"]] for item in admitted["cross_entries"]}

def _all_elements(report:Mapping[str,Any])->list[dict[str,Any]]:
    result=[]
    for section in ("title_and_decision_scope",*DOMAIN_SECTIONS,"visual_models"):
        value=report.get(section,[])
        if isinstance(value,list):result.extend(item for item in value if isinstance(item,dict))
    return result

def _validate_pairs(item:Mapping[str,Any],binding_index:Mapping[tuple[str,str],Any],label:str)->list[tuple[str,str]]:
    sources=item["source_ids"];locators=item["locators"]
    if len(sources)!=len(locators):raise InternalCondition("revise","HH1A_UNPAIRED_EVIDENCE",f"{label} source_ids/locators lengths differ",[label])
    pairs=list(zip(sources,locators))
    if len(pairs)!=len(set(pairs)) or any(pair not in binding_index for pair in pairs):raise InternalCondition("revise","HH1A_MISATTRIBUTED_EVIDENCE",f"{label} contains duplicate or non-cross-index source/locator pairs",[label])
    return pairs

def _validate_visual(visual:Mapping[str,Any],binding_index:Mapping[tuple[str,str],Any])->None:
    node_ids=[node["id"] for node in visual["nodes"]]
    if len(node_ids)!=len(set(node_ids)):raise InternalCondition("revise","HH1A_VISUAL_NODE_DUPLICATE",visual["id"],[visual["id"]])
    for node in visual["nodes"]:_validate_pairs(node,binding_index,f"{visual['id']}:node:{node['id']}")
    for index,edge in enumerate(visual["edges"]):
        if edge["from"] not in node_ids or edge["to"] not in node_ids:raise InternalCondition("revise","HH1A_VISUAL_EDGE_DANGLING",f"{visual['id']} edge {index}",[visual["id"]])
        _validate_pairs(edge,binding_index,f"{visual['id']}:edge:{index}")

def _validate_budget(report:Mapping[str,Any],elements:list[dict[str,Any]])->None:
    text=" ".join(str(item.get(key,"")) for item in elements for key in ("conclusion","visual_role","review_question"));visuals=report["visual_models"]
    cjk=len(CJK.findall(text));latin=len(LATIN.findall(text));minutes=round(cjk/500+latin/250+len(visuals)*.25,4);budget=report["review_budget"]
    if budget!={"cjk_characters":cjk,"latin_words":latin,"visual_count":len(visuals),"formula":"CJK/500 + Latin/250 + visuals*0.25","estimated_read_minutes":minutes}:raise InternalCondition("revise","HH1A_BUDGET_DRIFT","declared reading budget differs from deterministic recount")
    if minutes>10:raise InternalCondition("revise","HH1A_BUDGET_EXCEEDED",f"estimated {minutes} minutes exceeds 10")

def validate_draft(context:Context,draft:Path,admitted:Mapping[str,Any])->tuple[dict[str,Any],dict[str,Any],dict[str,Any]]:
    expected={"canonical.json","generation-session.json","generation-evidence"}
    if {path.name for path in draft.iterdir()}!=expected:raise InternalCondition("revise","HH1A_DRAFT_CLOSURE","draft must contain canonical, session and generation-evidence only")
    evidence_dir=draft/"generation-evidence";names=("00-material-inventory.json","01-organization.json","02-adversarial-review.json")
    if tuple(path.name for path in sorted(evidence_dir.iterdir()))!=names:raise InternalCondition("revise","HH1A_EVIDENCE_CLOSURE","generation evidence set/order mismatch")
    report=read_json(draft/"canonical.json");session=read_json(draft/"generation-session.json");evidence={name:read_json(evidence_dir/name) for name in names}
    context.catalog.validate(report,"hld-human-review-report.schema.json");context.catalog.validate(session,"hh1-a-generation-session.schema.json");context.catalog.validate(evidence[names[0]],"hh1-a-material-inventory.schema.json");context.catalog.validate(evidence[names[1]],"hh1-a-organization.schema.json");context.catalog.validate(evidence[names[2]],"hh1-a-adversarial-review.schema.json")
    if (report["hld_run_id"],report["revision"])!=(context.work_order["hld_run_id"],context.work_order["revision"]):raise InternalCondition("revise","HH1A_REPORT_IDENTITY","report run/revision mismatch")
    if report["hp1_content_binding"]!={"package_sha256":sha256(context.roles["novel_hld_package"]),"completion_sha256":sha256(context.roles["hp1_completion"])} or report["hq2_gate_binding"]!={"acceptance_sha256":sha256(context.roles["lld_handoff_acceptance"]),"bound_hp1_package_sha256":sha256(context.roles["novel_hld_package"])}:raise InternalCondition("revise","HH1A_REPORT_BINDING","report HP1/HQ2 binding mismatch")
    declared=context.work_order["file_allowlist"]
    if session["actual_read_refs"]!=declared or session["task_id"]!=context.work_order["task_id"] or session["hld_run_id"]!=context.work_order["hld_run_id"]:raise InternalCondition("revise","HH1A_SESSION_READ_DRIFT","generation session must exactly equal ordered allowlist and task identity")
    elements=_all_elements(report);ids=[item["id"] for item in elements]
    if len(ids)!=len(set(ids)) or any("HUI-" in json.dumps(item,ensure_ascii=False) for item in elements):raise InternalCondition("revise","HH1A_ELEMENT_ID_INVALID","duplicate or renderer-owned report ID")
    expected_list=[]
    for item in elements:
        expected_list.extend((item["id"],source,locator) for source,locator in _validate_pairs(item,admitted["binding_index"],item["id"]))
        if item["id"].startswith("HVG-"):_validate_visual(item,admitted["binding_index"])
    actual_list=[(item["report_element_id"],item["source_id"],item["locator"]) for item in report["source_bindings"]]
    if len(actual_list)!=len(set(actual_list)) or actual_list!=expected_list:raise InternalCondition("revise","HH1A_SOURCE_BINDING_DRIFT","source_bindings must be the unique ordered expansion of all outer element pairs")
    actual_bindings=set(actual_list)
    material=material_locator_map(admitted);primary_covered={locator for section in DOMAIN_SECTIONS for item in report[section] for locator in item["locators"] if locator in material}
    missing=set(material)-primary_covered
    wrong_domain=[]
    for section in DOMAIN_SECTIONS:
        for item in report[section]:
            wrong_domain.extend(locator for locator in item["locators"] if locator in material and material[locator]!=section)
    if missing:raise InternalCondition("revise","HH1A_REPORT_MATERIAL_OMISSION",f"uncovered material locators: {sorted(missing)}",missing)
    if wrong_domain:raise InternalCondition("revise","HH1A_DOMAIN_MISPLACEMENT",f"locators placed in wrong domain: {sorted(set(wrong_domain))}",wrong_domain)
    domain_coverage={section:{"expected_locators":sorted(locator for locator,owner in material.items() if owner==section),"covered_locators":sorted(locator for locator in primary_covered if material[locator]==section),"uncovered_locators":sorted(locator for locator,owner in material.items() if owner==section and locator not in primary_covered)} for section in DOMAIN_SECTIONS}
    if evidence[names[0]]["material_locators"]!=sorted(material) or evidence[names[0]]["covered_locators"]!=sorted(primary_covered) or evidence[names[0]]["uncovered_locators"]!=sorted(missing) or evidence[names[0]]["domain_coverage"]!=domain_coverage:raise InternalCondition("revise","HH1A_INVENTORY_DRIFT","material inventory/domain coverage does not exactly bind runtime inventory")
    org=evidence[names[1]]["domain_element_ids"]
    if any(org[section]!=[item["id"] for item in report[section]] for section in DOMAIN_SECTIONS) or evidence[names[1]]["visual_model_ids"]!=[item["id"] for item in report["visual_models"]]:raise InternalCondition("revise","HH1A_ORGANIZATION_DRIFT","organization evidence differs from report")
    if session["material_locator_count"]!=len(material):raise InternalCondition("revise","HH1A_SESSION_INVENTORY_DRIFT","session material count mismatch")
    _validate_budget(report,elements)
    return report,session,evidence

def build_ready(context:Context,staging:Path,report:Mapping[str,Any],session:Mapping[str,Any],evidence:Mapping[str,Any])->dict[str,Any]:
    staging.mkdir(parents=True,exist_ok=False);write_json(staging/SPEC.canonical_name,report);write_json(staging/SPEC.session_name,session)
    for name,value in evidence.items():write_json(staging/"generation-evidence"/name,value)
    execution={"schema_version":"1.0","skill":SKILL,"stage":"HH1","hld_run_id":context.work_order["hld_run_id"],"work_order_id":context.work_order["work_order_id"],"task_id":context.work_order["task_id"],"implementation_sha256":impl_hash(),"actual_read_hashes":{role:sha256(path) for role,path in sorted(context.roles.items())},"report_sha256":sha256(staging/SPEC.canonical_name),"deterministic":True}
    context.catalog.validate(execution,"hh1-a-execution.schema.json");write_json(staging/SPEC.execution_name,execution)
    validation={"schema_version":"1.0","skill":SKILL,"stage":"HH1","hld_run_id":context.work_order["hld_run_id"],"status":"pass","checks":["exact-read-closure","hp1-hq2-current-bindings","seven-domain-material-coverage","source-binding-bijection","budget-recount","task-isolation","adversarial-pass","deterministic-reproduction"],"errors":[]}
    context.catalog.validate(validation,"hh1-a-validation.schema.json");write_json(staging/"validation.json",validation)
    roles={SPEC.canonical_name:SPEC.canonical_role,SPEC.session_name:"generation_session",SPEC.execution_name:"execution_record","validation.json":"validation"}
    return finalize_ready(context,staging,roles)

def execute(work_order:Path,draft:Path)->tuple[int,dict[str,Any]]:
    context=load_context(work_order,SPEC,impl_hash(),_catalog())
    def build(ctx:Context,staging:Path):
        try:
            try:admitted=admit(ctx)
            except ContractError as error:raise InternalCondition("blocked","HH1A_UPSTREAM_SCHEMA_INVALID",str(error),["HP1"]) from error
            try:report,session,evidence=validate_draft(ctx,draft.resolve(strict=True),admitted)
            except ContractError as error:raise InternalCondition("revise","HH1A_DRAFT_SCHEMA_INVALID",str(error)) from error
            return 0,build_ready(ctx,staging,report,session,evidence)
        except InternalCondition as condition:
            return 2,finalize_condition(ctx,staging,condition,read_json(draft/"canonical.json") if (draft/"canonical.json").is_file() else None)
        except Exception as error:return 1,finalize_runtime_error(ctx,staging,error,"HH1-A admission/draft validation/sealing")
    return atomic_execute(context,build)

def main(argv=None):
    parser=argparse.ArgumentParser();parser.add_argument("work_order",type=Path);parser.add_argument("draft_dir",type=Path);args=parser.parse_args(argv)
    try:code,_=execute(args.work_order,args.draft_dir);return code
    except Exception as error:print(str(error),file=sys.stderr);return 1
if __name__=="__main__":raise SystemExit(main())
