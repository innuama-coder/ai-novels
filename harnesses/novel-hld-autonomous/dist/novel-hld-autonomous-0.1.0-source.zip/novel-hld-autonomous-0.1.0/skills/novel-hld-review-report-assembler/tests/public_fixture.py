from __future__ import annotations

import importlib
import json
import sys
from pathlib import Path
from typing import Any

REPO=Path(__file__).resolve().parents[3];HARNESS=REPO/"harnesses/novel-hld-autonomous"
sys.path.insert(0,str(HARNESS));sys.path.insert(0,str(REPO))
from runtime import composite_publisher as publisher
from runtime.canonical import write_json

PUBTEST=importlib.import_module("harnesses.novel-hld-autonomous.tests.test_composite_publisher")
A=importlib.import_module("skills.novel-hld-review-report-assembler.scripts.hh1a_runtime")
B=importlib.import_module("skills.novel-hld-presentation-fidelity-reviewer.scripts.hh1b_runtime")

def fref(path:Path,root:Path,role:str):return publisher.file_ref(path,root,role)

def build_base(root:Path):
    fixture=PUBTEST.Fixture(root);state_ref=fref(fixture.state,fixture.workspace,"state_before");up=fixture.upstream("HQ2");previous={}
    first=fixture.ready_task("consumer_test",30,state_ref,up,previous);previous[first.kind]=first
    second=fixture.ready_task("fidelity_test",31,state_ref,up,previous);order=fixture.publish_order("HQ2",[first,second]);code,_=publisher.execute(order)
    if code!=0:raise AssertionError("HQ2 fixture failed")
    return fixture

def a_allowlist(ws:Path):
    hp1=ws/"HP1-package";q2=ws/"HQ2-package";hb0=ws/"HB0-package"
    paths={"hb0_completion":hb0/"stage-completion.json","hp1_completion":hp1/"stage-completion.json","hp1_manifest":hp1/"package-manifest.json","hp1_validation":hp1/"validation.json","novel_hld_package":hp1/"novel-hld-package.json","hld_cross_index":hp1/"hld-cross-index.json","hld_traceability_matrix":hp1/"hld-traceability-matrix.json","hld_spec":hp1/"novel-hld-spec.md","hq2_completion":q2/"stage-completion.json","hq2_manifest":q2/"package-manifest.json","hq2_validation":q2/"validation.json","lld_handoff_acceptance":q2/"lld-handoff-acceptance.json"}
    for role,name in A.MODEL_ROLES.items():paths[role]=hp1/name
    return [fref(paths[role],ws,role) for role in A.REQUIRED_ROLES]

def work_order(ws:Path,skill:str,version:str,implementation:str,allow:list[dict],output:str,task:str,event:int):
    state_ref=fref(ws/"publisher-state.json",ws,"state_before");up=[PUBTEST.artifact(ws,stage) for stage in publisher.UPSTREAM["HH1"]]
    folder=ws/output.rsplit("/",1)[0];gate_path=folder/"input-gate.json"
    shared={"schema_version":"1.0","harness":"novel-hld-autonomous","hld_run_id":"hld-fixture","stage":"HH1","mode":"forward","state_before_ref":state_ref,"hb0_completion_ref":up[0],"upstream_completions":up,"baseline_manifest_ref":None,"baseline_validation_ref":None,"source_lineage_refs":[],"exact_owner_skill":skill,"owner_version":version,"implementation_sha256":implementation,"return_binding":None,"unresolved_projection":[],"revision_plan_ref":None,"revision_plan_state_ref":None,"file_allowlist":allow}
    write_json(gate_path,shared);gate_ref=fref(gate_path,ws,"input_gate")
    value={"schema_version":"1.0","harness":"novel-hld-autonomous","hld_run_id":"hld-fixture","revision":1,"work_order_id":"WO-"+task,"task_id":task,"stage":"HH1","action":"execute","exact_owner_skill":skill,"owner_version":version,"implementation_sha256":implementation,"event_sequence":event,"result_timestamp":"2026-08-06T00:00:00Z","input_gate_ref":gate_ref,"state_before_ref":state_ref,"upstream_completions":up,"file_allowlist":allow,"unresolved_projection":[],"mode":"forward","return_binding":None,"revision_plan_ref":None,"revision_plan_state_ref":None,"output_directory":output,"submission_status":"open"}
    path=folder/"work-order.json";write_json(path,value);return path,value,gate_path

def report_draft(ws:Path,order:dict,draft:Path):
    models={role:json.loads((ws/"HP1-package"/name).read_text(encoding="utf-8")) for role,name in A.MODEL_ROLES.items()};machine=json.loads((ws/"HP1-package/novel-hld-package.json").read_text(encoding="utf-8"));cross=json.loads((ws/"HP1-package/hld-cross-index.json").read_text(encoding="utf-8"));material=A.material_locator_map({"models":models,"machine":machine,"cross_entries":cross["entries"]})
    by_locator={f"{item['model_path']}#{item['locator']}":item for item in cross["entries"]};sections={name:[] for name in A.DOMAIN_SECTIONS};counter=1
    for locator,section in sorted(material.items()):
        source=by_locator[locator]["id"];element={"id":f"HRE-{counter:03d}","element_kind":"control","conclusion":f"The HLD fixes the control bound at {locator}.","source_ids":[source],"locators":[locator],"visual_role":"decision summary","review_question":"Is this control the intended development boundary?"};sections[section].append(element);counter+=1
    first,second=cross["entries"][:2];first_locator=f"{first['model_path']}#{first['locator']}";second_locator=f"{second['model_path']}#{second['locator']}"
    title={"id":"HRE-TITLE","element_kind":"orientation","conclusion":"Review the sealed HLD controls for author approval.","source_ids":[first["id"]],"locators":[first_locator],"visual_role":"orientation","review_question":"Should this HLD proceed to LLD?"}
    visual={"id":"HVG-001","element_kind":"visual_model","conclusion":"Two sealed controls are connected for review.","source_ids":[first["id"]],"locators":[first_locator],"visual_role":"relationship map","review_question":"Is this relationship presentation acceptable?","model_kind":"architecture","nodes":[{"id":"N1","label":"first control","source_ids":[first["id"]],"locators":[first_locator]},{"id":"N2","label":"second control","source_ids":[second["id"]],"locators":[second_locator]}],"edges":[{"from":"N1","to":"N2","label":"review connection","source_ids":[first["id"]],"locators":[first_locator]}],"text_alternative":"The first sealed control connects to the second for review."}
    report={"schema_version":"1.0","skill":A.SKILL,"stage":"HH1","hld_run_id":"hld-fixture","revision":1,"status":"ready","hp1_content_binding":{"package_sha256":publisher.sha256(ws/"HP1-package/novel-hld-package.json"),"completion_sha256":publisher.sha256(ws/"HP1-package/stage-completion.json")},"hq2_gate_binding":{"acceptance_sha256":publisher.sha256(ws/"HQ2-package/lld-handoff-acceptance.json"),"bound_hp1_package_sha256":publisher.sha256(ws/"HP1-package/novel-hld-package.json")},"title_and_decision_scope":[title],**sections,"visual_models":[visual],"source_bindings":[],"review_budget":{"cjk_characters":0,"latin_words":0,"visual_count":0,"formula":"CJK/500 + Latin/250 + visuals*0.25","estimated_read_minutes":0}}
    report["source_bindings"]=[{"report_element_id":item["id"],"source_id":source,"locator":locator} for item in A._all_elements(report) for source,locator in zip(item["source_ids"],item["locators"])]
    elements=A._all_elements(report);text=" ".join(str(item.get(key,"")) for item in elements for key in ("conclusion","visual_role","review_question"));cjk=len(A.CJK.findall(text));latin=len(A.LATIN.findall(text));visual_count=len(report["visual_models"]);minutes=round(cjk/500+latin/250+visual_count*.25,4);report["review_budget"].update({"cjk_characters":cjk,"latin_words":latin,"visual_count":visual_count,"estimated_read_minutes":minutes})
    allow=order["file_allowlist"];session={"schema_version":"1.0","skill":A.SKILL,"stage":"HH1","hld_run_id":"hld-fixture","task_id":order["task_id"],"actual_read_refs":allow,"material_locator_count":len(material)}
    organization={"schema_version":"1.0","domain_element_ids":{section:[item["id"] for item in report[section]] for section in A.DOMAIN_SECTIONS},"visual_model_ids":[item["id"] for item in report["visual_models"]]};ids=[item["id"] for item in elements]
    domain_coverage={section:{"expected_locators":sorted(locator for locator,owner in material.items() if owner==section),"covered_locators":sorted(locator for locator,owner in material.items() if owner==section),"uncovered_locators":[]} for section in A.DOMAIN_SECTIONS}
    evidence={"00-material-inventory.json":{"schema_version":"1.0","material_locators":sorted(material),"covered_locators":sorted(material),"uncovered_locators":[],"domain_coverage":domain_coverage},"01-organization.json":organization,"02-adversarial-review.json":{"schema_version":"1.0","verdict":"pass","challenges":[{"id":"CH-1","challenge":"omission challenge","evidence_element_ids":ids,"result":"pass"},{"id":"CH-2","challenge":"authority challenge","evidence_element_ids":ids,"result":"pass"},{"id":"CH-3","challenge":"boundary challenge","evidence_element_ids":ids,"result":"pass"}],"blockers":[]}}
    write_json(draft/"canonical.json",report);write_json(draft/"generation-session.json",session)
    for name,value in evidence.items():write_json(draft/"generation-evidence"/name,value)
    return report

def build_a(root:Path):
    fixture=build_base(root);ws=fixture.workspace;allow=a_allowlist(ws);path,order,gate=work_order(ws,A.SKILL,A.VERSION,A.impl_hash(),allow,"internal/HH1-A/package","TASK-HH1-A",40);draft=ws/"draft-a";report=report_draft(ws,order,draft);return fixture,path,order,gate,draft,report

def b_allowlist(ws:Path,a_order_path:Path):
    hp1=ws/"HP1-package";a=ws/"internal/HH1-A/package"
    paths={"hp1_completion":hp1/"stage-completion.json","hp1_manifest":hp1/"package-manifest.json","novel_hld_package":hp1/"novel-hld-package.json","hld_cross_index":hp1/"hld-cross-index.json","human_review_report":a/"hld-human-review-report.json","hh1_a_manifest":a/"package-manifest.json","hh1_a_generation_session":a/"generation-session.json","hh1_a_work_order":a_order_path}
    for role,name in B.MODEL_ROLES.items():paths[role]=hp1/name
    return [fref(paths[role],ws,role) for role in B.REQUIRED_ROLES]

def review_draft(ws:Path,order:dict,draft:Path,verdict="pass"):
    report=json.loads((ws/"internal/HH1-A/package/hld-human-review-report.json").read_text(encoding="utf-8"));elements=A._all_elements(report);first=elements[0];source=first["source_ids"][0];locator=first["locators"][0];eid=first["id"];cross=json.loads((ws/"HP1-package/hld-cross-index.json").read_text(encoding="utf-8"));binding_index={(item["id"],f"{item['model_path']}#{item['locator']}"):item for item in cross["entries"]}
    def evidence(ids):
        sources,locators=B._evidence_for(report,binding_index,set(ids));return {"verdict":"pass","claims":["The bound report meaning is preserved."],"challenges":["A counterexample search found no material drift."],"report_element_ids":sorted(ids),"source_ids":sorted(sources),"locators":sorted(locators)}
    all_ids={item["id"] for item in elements};relation={item["id"] for section in ("overall_narrative_architecture","storyline_choreography","character_arc_placement","time_space_pacing_tension","key_scene_functions") for item in report[section]};authority={item["id"] for item in report["open_items_constraints_and_lld_boundary"]};visuals={item["id"] for item in report["visual_models"]};dimensions={"fact_fidelity":evidence(all_ids),"structure_and_relation_fidelity":evidence(relation),"coverage_fidelity":evidence(all_ids),"authority_and_open_item_fidelity":evidence(authority),"visual_data_fidelity":evidence(visuals)}
    questions=[]
    for code in sorted(B.QUESTIONS):
        ev=evidence({item["id"] for item in report[B.QUESTION_SECTIONS[code]]});questions.append({"question_code":code,"question":"What must the author decide?","answer":"The bound report elements state the applicable HLD control.","report_element_ids":ev["report_element_ids"],"source_ids":ev["source_ids"],"locators":ev["locators"],"verdict":"pass"})
    budget=B._budget(report);review={"schema_version":"1.0","skill":B.SKILL,"stage":"HH1","hld_run_id":"hld-fixture","revision":1,"review_bindings":{"hp1_package_sha256":publisher.sha256(ws/"HP1-package/novel-hld-package.json"),"report_sha256":publisher.sha256(ws/"internal/HH1-A/package/hld-human-review-report.json"),"report_manifest_sha256":publisher.sha256(ws/"internal/HH1-A/package/package-manifest.json"),"assembler_task_id":"TASK-HH1-A","reviewer_task_id":order["task_id"]},**dimensions,"material_drift_findings":[],"reading_budget_validation":{"formula":"CJK/500 + Latin/250 + visuals*0.25","declared":budget,"recomputed":budget,"verdict":"pass"},"decision_retrieval_tests":questions,"cognitive_overload_findings":[],"defect_origin":"none","verdict":"pass"}
    if verdict=="fail":
        review["verdict"]="fail";review["defect_origin"]="upstream_content";review["coverage_fidelity"]={**dimensions["coverage_fidelity"],"verdict":"fail"};review["material_drift_findings"]=[{"drift_type":"omission","affected_report_element_ids":[eid],"source_ids":[source],"hp1_locators":[locator],"report_evidence":"A material control is absent.","material_impact":"The author cannot verify the fixed HLD boundary.","requested_correction":"Restore the omitted bound control without changing HP1."}]
    refs={item["role"]:item for item in order["file_allowlist"]};session={"schema_version":"1.0","skill":B.SKILL,"stage":"HH1","hld_run_id":"hld-fixture","review_task_id":order["task_id"],"producer_task_id":"TASK-HH1-A","declared_allowlist":order["file_allowlist"],"actual_read_refs":order["file_allowlist"],"hp1_package_ref":refs["novel_hld_package"],"candidate_report_ref":refs["human_review_report"],"candidate_manifest_ref":refs["hh1_a_manifest"],"producer_session_ref":refs["hh1_a_generation_session"],"producer_work_order_ref":refs["hh1_a_work_order"]}
    write_json(draft/"canonical.json",review);write_json(draft/"review-session.json",session);return review

def build_b(root:Path,verdict="pass"):
    fixture,a_path,a_order,_,a_draft,_=build_a(root);code,_=A.execute(a_path,a_draft)
    if code!=0:raise AssertionError("HH1-A fixture failed")
    ws=fixture.workspace;allow=b_allowlist(ws,a_path);path,order,gate=work_order(ws,B.SKILL,B.VERSION,B.impl_hash(),allow,"internal/HH1-B/package","TASK-HH1-B",41);draft=ws/"draft-b";review=review_draft(ws,order,draft,verdict);return fixture,path,order,gate,draft,review
