# SOP

## A. Admit

1. Validate work-order and input-gate identity before semantic reads.
2. Verify current HP1 and HQ2 completions and same-HP1 binding.
3. Reduce the readable set to the allowlist. Treat HQ2 as gate-only evidence.
4. If the schema version, bindings, or sole-content-source rule fails, stop with durable non-ready evidence.

## B. Inventory HP1

5. Enumerate every material control in HP1: structure, storyline connections, arc placements, POV/knowledge, suspense chains, time-space/resource continuity, pacing/tension, key scene functions, open items, prohibitions, and LLD freedoms.
6. Record each control's HP1 stable ID and locator. Do not draft until all controls are assigned to at least one report domain.
7. Mark apparent HP1 absence as upstream evidence; never fill it from memory or raw conception.

## C. Organize conclusions

8. Write `title_and_decision_scope` as orientation, not story content.
9. Populate all seven HLD domains with conclusion-first HRE elements. One element should answer one author decision question.
10. Preserve modal strength and open/closed status. Combine only compatible controls and retain all bindings.
11. Put open items, constraints, prohibited interpretations, and LLD freedoms in the final boundary section.

## D. Design visual models

12. Identify relations with three or more nodes, convergence points, multi-step reveal chains, or pacing curves that are materially faster to inspect visually.
13. Create the minimum useful HVG set. Each visual has a textual conclusion, visual role, review question, and complete HP1 bindings.
14. Do not create HTML, SVG, DOM, styling, or HUI identifiers.

## E. Bind and budget

15. Assign stable unique HRE/HVG IDs. Forbid `element_id` aliases.
16. Expand each element's source arrays into `source_bindings`; require exact set equality and valid HP1 locators.
17. Count CJK characters and Latin words in decision-layer fields; count HVG elements; calculate `CJK/500 + Latin/250 + visuals*0.25` to four decimals.
18. If over ten minutes, compress repetition and restructure. Do not omit material controls.

## F. Reverse challenge and emit

19. Ask: Can every HP1 material control be found? Did any statement add, correct, weaken, strengthen, or expose process? Is every visual necessary? Can the author identify what is fixed, open, forbidden, and delegated to LLD?
20. Emit the exact internal package, external composite-internal result envelope, validation evidence, and generation evidence. Never emit HH1 completion.
21. Run deterministic validation, then the semantic rubric. A ready package proceeds only to HH1-B and, after B/C pass, the fixed composite publisher.
