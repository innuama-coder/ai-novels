# Input and output contract

## Admission

The harness supplies a sealed `HH1` work order and input gate. `exact_owner_skill` is `novel-hld-review-report-assembler`; `action=execute`; upstream stages are exactly `[HB0,HP1,HQ2]`. HP1 and HQ2 are current ready completions and HQ2 binds the same HP1 hash. The work order declares the report-schema version and output directory.

Allowed semantic inputs are exactly the ordered roles in `runtime-contract.json`: HP1 completion/manifest/validation, `novel-hld-package.json`, cross-index, traceability matrix, spec, and the six byte-copied canonical models. HH1 state and work-order/input-gate are operational bootstrap inputs. HB0 completion and HQ2 completion/manifest/validation/acceptance are gate evidence only. No other file is a content source. In particular, sample chapters and novel prose are neither input nor output of HLD review assembly.

## Canonical report

`hld-human-review-report.json` contains identity and bindings plus these non-empty sections:

1. `title_and_decision_scope`
2. `overall_narrative_architecture`
3. `storyline_choreography`
4. `character_arc_placement`
5. `pov_information_suspense`
6. `time_space_pacing_tension`
7. `key_scene_functions`
8. `open_items_constraints_and_lld_boundary`
9. `visual_models`
10. `source_bindings`
11. `review_budget`

All section entries are display elements. Report/control elements use `HRE-`; visual models use `HVG-`. Each has `id`, `element_kind`, `conclusion`, `source_ids`, `locators`, `visual_role`, and `review_question`. `element_id`, `HUI-`, DOM, HTML, CSS, and SVG markup are forbidden. Every `(element, source, locator)` pair appears exactly once in `source_bindings`.

The seven HLD domains are the seven sections after title and before visuals; all must be non-empty. The title section states project title, review scope, report version, status, and requested author decision without adding story content.

`review_budget.formula` is exactly `CJK/500 + Latin/250 + visuals*0.25`; counts are recomputed from all display-element conclusions, visual roles, and review questions. `estimated_read_minutes` is rounded to four decimals and must be `<=10`.

## Internal package

Ready package closure is exactly:

- `hld-human-review-report.json`
- `generation-session.json`
- one or more `generation-evidence/*.json`
- `report-assembly-execution.json`
- `validation.json`
- `package-manifest.json`

The single `stage-result.json` sits outside the package, has `result_scope=composite_internal`, `result=ready`, `completion_ref=null`, and a non-null `internal_manifest_ref`. HH1-A never emits a stage completion.

Local report defects produce `revise` evidence. Missing or unsealed HP1 conclusions produce `blocked` evidence with `blocker_class=upstream_defect`. A post-admission execution fault produces sealed `runtime_error` evidence. Input closure and hash mismatches fail admission before canonical content is written. The harness, not the skill, resolves routing.
