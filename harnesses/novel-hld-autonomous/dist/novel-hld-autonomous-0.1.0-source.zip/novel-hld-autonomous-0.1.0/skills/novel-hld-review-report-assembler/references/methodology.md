# Methodology

## 1. Decision-first information architecture

Begin with the decision the author must make, then expose the minimum complete conclusion layer. Front-load the main message and use descriptive headings so a scanning reader can predict each section. “Short” means decision-proportionate, not incomplete.

## 2. Progressive disclosure without concealment

Layer information as: decision scope → seven HLD conclusions → relationships/visual models → open items and LLD boundary. Essential controls stay in the primary path. Supporting locators are machine-readable rather than repeated prose. Progressive disclosure is never permission to hide a material control.

## 3. Evidence-bound compression

Treat HP1 as immutable evidence. Build a material-control inventory before drafting. A report sentence may combine controls only when its source binding retains every contributing source ID and locator and its modality is unchanged. Preserve `must`, `must not`, `open`, and `LLD freedom` distinctly.

## 4. Visuals as relationship models

Use a visual model only when it reduces the cost of understanding a multi-node relation, sequence, convergence, information path, or pacing pattern. A visual has a conclusion, textual role, review question, and source bindings. It is semantic data for HH1-C, never SVG markup. Avoid decorative or duplicate visuals.

## 5. Accessible dual encoding

Every visual model must be understandable through its textual conclusion and `visual_role`; do not rely on color, position, or shape alone. Section order remains meaningful without rendering. HH1-C later supplies accessible HTML/SVG semantics.

## 6. Ten-minute budget as a lossless constraint

Count decision-layer text deterministically and add 0.25 minutes per visual. If over budget, remove repetition, shorten headings/questions, merge semantically compatible elements, and move locator detail into bindings. Never delete a material control or invent a summary that weakens it.

## 7. Separation of duties

HH1-A assembles. HH1-B independently proves fidelity and decision usability. HH1-C renders. The publisher seals all three. This prevents self-certification and keeps presentation changes from mutating the machine HLD.
