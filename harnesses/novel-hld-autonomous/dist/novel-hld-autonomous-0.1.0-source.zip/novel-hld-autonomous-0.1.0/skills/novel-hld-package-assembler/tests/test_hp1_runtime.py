from __future__ import annotations

import importlib
import hashlib
import shutil
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

SKILL_ROOT = Path(__file__).resolve().parents[1]
REPO_ROOT = SKILL_ROOT.parents[1]
sys.path.insert(0, str(SKILL_ROOT / "scripts"))

import hp1_runtime as hp1  # noqa: E402

hb0_test = importlib.import_module("skills.novel-hld-baseline-admitter.tests.test_hb0_runtime")


def write_json(path: Path, value: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(hp1.canonical_bytes(value))


def file_ref(path: Path, workspace: Path, role: str) -> dict[str, str]:
    return {"role": role, "path": path.relative_to(workspace).as_posix(), "sha256": hp1.file_hash(path)}


def artifact_ref(main: Path, manifest: Path, completion: Path, workspace: Path) -> dict[str, str]:
    return {
        "path": main.relative_to(workspace).as_posix(), "sha256": hp1.file_hash(main),
        "manifest_path": manifest.relative_to(workspace).as_posix(), "manifest_sha256": hp1.file_hash(manifest),
        "completion_path": completion.relative_to(workspace).as_posix(), "completion_sha256": hp1.file_hash(completion),
    }


def manifest_for(package: Path, content: list[Path], stage: str) -> Path:
    refs = [file_ref(path, package, "content") for path in sorted(content, key=lambda item: item.relative_to(package).as_posix())]
    value = {
        "schema_version": "1.0", "harness": hp1.HARNESS, "hld_run_id": "hld-fixture", "revision": 1,
        "stage": stage, "skill": "fixture", "status": "ready", "files": refs,
        "artifact_roles": {f"content::{index}": {**item, "role": f"content::{index}"} for index, item in enumerate(refs)},
    }
    value["files"] = [{**item, "role": f"content::{index}"} for index, item in enumerate(refs)]
    target = package / "package-manifest.json"
    write_json(target, value)
    return target


def make_completion(package: Path, stage: str, main: Path, manifest: Path, validation: Path, workspace: Path) -> Path:
    value = {
        "schema_version": "1.0", "harness": hp1.HARNESS, "stage": stage, "skill": f"fixture-{stage.lower()}",
        "hld_run_id": "hld-fixture", "revision": 1, "status": "ready",
        "input_gate_ref": {"role": "fixture", "path": main.relative_to(workspace).as_posix(), "sha256": hp1.file_hash(main)},
        "state_before_ref": {"role": "fixture", "path": main.relative_to(workspace).as_posix(), "sha256": hp1.file_hash(main)},
        "work_order_ref": {"role": "fixture", "path": main.relative_to(workspace).as_posix(), "sha256": hp1.file_hash(main)},
        "manifest_ref": file_ref(manifest, workspace, "package_manifest"),
        "validation_ref": file_ref(validation, workspace, "validation"), "upstream_completions": [],
        "canonical_artifacts": [file_ref(main, workspace, "canonical")],
        "owner_implementation": {"skill": f"fixture-{stage.lower()}", "version": "0.1.0", "sha256": "1" * 64},
        "return_binding": None, "ready_capabilities": ["fixture"], "next_allowed_stage": "HP1",
    }
    target = package / "stage-completion.json"
    write_json(target, value)
    return target


def build_design_package(workspace: Path, stage: str, authority: dict, *, lwr_prefix: str = "LWR") -> tuple[Path, Path, Path, Path]:
    package = workspace / f"{stage}-package"
    package.mkdir()
    decision = f"HDDES-{stage}-001"
    object_ids = {"HA1": "HNU-001", "HS1": "HTS-001", "HC1": "HAS-001", "HI1": "HIN-001", "HR1": "HTM-001", "HK1": "HKF-001"}
    object_id = object_ids[stage]
    stage_authority = hp1.json.loads(hp1.canonical_json(authority))
    stage_authority["hld_ownership"] = {"source_projection": [object_id], "hld_owned": [], "preserved_open": [], "lld_freedom": []}
    model = {
        "schema_version": "1.0", "skill": f"fixture-{stage.lower()}", "stage": stage,
        "hld_run_id": "hld-fixture", "status": "ready", "authority_partition": stage_authority,
        "design_decisions": [{"id": decision}], "decision_dependencies": [], "open_items": [],
        "objects": [] if stage == "HK1" else [{"id": object_id, "source_refs": ["NAR-001"], "design_decision_ids": [decision]}],
    }
    if stage == "HK1":
        model["key_scene_functions"] = [{"id": "HKF-001", "source_refs": ["NAR-001"], "design_decision_ids": [decision]}]
        model["lld_work_requirements"] = [{
            "id": f"{lwr_prefix}-001", "hkf_ids": ["HKF-001"], "grouping_rationale": "one required function",
            "chapter_shell_ids": ["HCH-001"], "entry_state": "before", "exit_state": "after",
            "character_ids": ["CHR-001"], "environment_ids": ["ENV-001"], "storyline_ids": ["SL-001"],
            "event_ids": ["EV-001"], "pov_constraints": ["HPV-001"], "knowledge_boundaries": ["HKS-001"],
            "prohibitions": ["no unsupported solution"], "required_elaboration": ["scene realization"],
            "lld_freedom": ["dialogue and sensory detail"], "acceptance_criteria": ["HKF-001 completed"],
        }]
    main = package / hp1.CANONICAL_FILES[stage]
    write_json(main, model)
    content = [main]
    session = package / "generation-session.json"; write_json(session, {"ready": True}); content.append(session)
    evidence = package / "generation-evidence" / "01.json"; write_json(evidence, {"ready": True}); content.append(evidence)
    execution = package / "execution-record.json"; write_json(execution, {"ready": True}); content.append(execution)
    preview = package / hp1.CANONICAL_FILES[stage].removesuffix(".json").__add__(".md"); preview.write_text("# preview\n", encoding="utf-8"); content.append(preview)
    validation = package / "validation.json"; write_json(validation, {"status": "pass"}); content.append(validation)
    manifest = manifest_for(package, content, stage)
    completion = make_completion(package, stage, main, manifest, validation, workspace)
    return main, manifest, validation, completion


def build_hq1_package(workspace: Path, *, finding: bool = False) -> tuple[Path, Path, Path, Path]:
    package = workspace / "HQ1-package"; package.mkdir()
    hdd = {"id": "HDD-HQ1-INT-OPEN", "owner_stage": "HQ1", "source_id": "INT-OPEN", "disposition": "not_needed_for_current_stage", "resolution_ref": None}
    review = {
        "schema_version": "1.0", "stage": "HQ1", "hld_run_id": "hld-fixture", "verdict": "pass" if not finding else "fail",
        "findings": [] if not finding else [{"id": "HFN-001"}], "decision_dependencies": [hdd],
        "decision_dependency_review": [{"source_id": "INT-OPEN", "status": "covered"}],
    }
    main = package / "hld-semantic-review.json"; write_json(main, review)
    session = package / "review-session.json"; write_json(session, {"ready": True})
    execution = package / "review-execution.json"; write_json(execution, {"ready": True})
    validation = package / "validation.json"; write_json(validation, {"status": "pass"})
    manifest = manifest_for(package, [main, session, execution, validation], "HQ1")
    completion = make_completion(package, "HQ1", main, manifest, validation, workspace)
    return main, manifest, validation, completion


def build_workspace(root: Path, *, finding: bool = False, lwr_prefix: str = "LWR", unresolved_projection: bool = False) -> Path:
    hb0_order = hb0_test.build_workspace(root)
    with patch.object(hb0_test.runtime, "_run_preparation_validator", return_value=None):
        code, _ = hb0_test.runtime.execute(hb0_order)
    if code != 0:
        raise AssertionError("HB0 fixture did not become ready")
    workspace = hb0_order.parent
    (workspace / "stage-result.json").unlink()
    hb0_package = workspace / "HB0-package"
    role_paths: dict[str, Path] = {
        "hb0_control_baseline": hb0_package / "hld-control-baseline.json",
        "hb0_source_index": hb0_package / "hld-source-index.json",
        "hb0_manifest": hb0_package / "package-manifest.json",
        "hb0_validation": hb0_package / "validation.json",
        "hb0_completion": hb0_package / "stage-completion.json",
    }
    authority = hp1.read_json(role_paths["hb0_control_baseline"])["authority_partition"]
    stage_values: dict[str, tuple[Path, Path, Path, Path]] = {}
    for stage in hp1.DESIGN_STAGES:
        values = build_design_package(workspace, stage, authority, lwr_prefix=lwr_prefix if stage == "HK1" else "LWR")
        stage_values[stage] = values
        for suffix, path in zip(("canonical", "manifest", "validation", "completion"), values):
            role_paths[f"{stage.lower()}_{suffix}"] = path
    stage_values["HQ1"] = build_hq1_package(workspace, finding=finding)
    for suffix, path in zip(("semantic_review", "manifest", "validation", "completion"), stage_values["HQ1"]):
        role_paths[f"hq1_{suffix}"] = path
    upstream = []
    for stage in hp1.UPSTREAM:
        main_role = hp1.MAIN_ROLES[stage]
        upstream.append(artifact_ref(role_paths[main_role], role_paths[f"{stage.lower()}_manifest"], role_paths[f"{stage.lower()}_completion"], workspace))
    allowlist = [file_ref(path, workspace, role) for role, path in sorted(role_paths.items())]
    state = workspace / "hp1-state-before.json"; write_json(state, {"stage": "HP1", "revision": 1})
    gate_path = workspace / "hp1-input-gate.json"
    gate = {
        "schema_version": "1.0", "harness": hp1.HARNESS, "hld_run_id": "hld-fixture", "stage": "HP1", "mode": "forward",
        "state_before_ref": file_ref(state, workspace, "state_before"), "hb0_completion_ref": upstream[0], "upstream_completions": upstream,
        "baseline_manifest_ref": None, "baseline_validation_ref": None, "source_lineage_refs": [],
        "exact_owner_skill": hp1.SKILL, "owner_version": hp1.VERSION, "implementation_sha256": hp1.implementation_sha256(),
        "return_binding": None, "unresolved_projection": ["INT-OPEN"] if unresolved_projection else [],
        "revision_plan_ref": None, "revision_plan_state_ref": None, "file_allowlist": allowlist,
    }
    write_json(gate_path, gate)
    work_order = {
        "schema_version": "1.0", "harness": hp1.HARNESS, "hld_run_id": "hld-fixture", "revision": 1,
        "work_order_id": "WO-HP1-001", "task_id": "TASK-HP1-001", "stage": "HP1", "action": "execute",
        "exact_owner_skill": hp1.SKILL, "owner_version": hp1.VERSION, "implementation_sha256": hp1.implementation_sha256(),
        "event_sequence": 9, "result_timestamp": "2026-08-06T00:00:00Z", "input_gate_ref": file_ref(gate_path, workspace, "input_gate"),
        "state_before_ref": file_ref(state, workspace, "state_before"), "upstream_completions": upstream,
        "file_allowlist": allowlist, "unresolved_projection": gate["unresolved_projection"], "mode": "forward",
        "return_binding": None, "revision_plan_ref": None, "revision_plan_state_ref": None,
        "output_directory": "HP1-package", "submission_status": "open",
    }
    order = workspace / "hp1-work-order.json"; write_json(order, work_order)
    return order


class HP1RuntimeTests(unittest.TestCase):
    def test_fixture_manifest_hashes_are_current(self) -> None:
        fixture_root = SKILL_ROOT / "tests" / "fixtures"
        manifest = hp1.read_json(fixture_root / "fixture-manifest.json")
        self.assertEqual(
            [(item["path"], item["sha256"]) for item in manifest["files"]],
            sorted((item["path"], item["sha256"]) for item in manifest["files"]),
        )
        for item in manifest["files"]:
            self.assertEqual(hashlib.sha256((fixture_root / item["path"]).read_bytes()).hexdigest(), item["sha256"])

    def test_positive_ready_is_lossless_bijective_and_reproducible(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            order = build_workspace(Path(temporary))
            code, result = hp1.execute(order)
            self.assertEqual((code, result["result"]), (0, "ready"))
            self.assertEqual(hp1.validate_existing(order)["status"], "pass")
            package = order.parent / "HP1-package"
            handoff = hp1.read_json(package / "lld-handoff.json")
            self.assertEqual([(item["source_lwr_id"], item["id"]) for item in handoff["work_units"]], [("LWR-001", "LWK-001")])
            cross_ids = {item["id"] for item in hp1.read_json(package / "hld-cross-index.json")["entries"]}
            self.assertTrue({"NAR-001", "INT-OPEN", "LWR-001", "HKF-001"}.issubset(cross_ids))
            entries = {item["id"]: item for item in hp1.read_json(package / "hld-cross-index.json")["entries"]}
            self.assertEqual((entries["NAR-001"]["owner_stage"], entries["NAR-001"]["kind"]), ("HB0", "source_control"))
            for record in hp1.read_json(package / "hld-traceability-matrix.json")["records"]:
                self.assertTrue(set(record["source_ids"]).issubset(entries))
            self.assertTrue((order.parent / "stage-result.json").is_file())
            self.assertFalse((package / "stage-result.json").exists())
            completion = hp1.read_json(package / "stage-completion.json")
            result_document = hp1.read_json(order.parent / "stage-result.json")
            refs = [completion["manifest_ref"], completion["validation_ref"], *completion["canonical_artifacts"], result_document["completion_ref"], result_document["result_manifest_ref"], result_document["validation_ref"]]
            self.assertFalse(any(".hp1-" in item["path"] for item in refs))
            for item in refs:
                hp1.verify_ref(item, order.parent)

    def test_negative_hq1_nonpass_blocks_without_ready_artifacts(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            order = build_workspace(Path(temporary), finding=True)
            code, result = hp1.execute(order)
            self.assertEqual((code, result["result"]), (2, "blocked"))
            self.assertEqual({path.name for path in (order.parent / "HP1-package").iterdir()}, hp1.BLOCKED_FILES)

    def test_negative_hk1_lwk_source_id_is_rejected(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            order = build_workspace(Path(temporary), lwr_prefix="LWK")
            code, result = hp1.execute(order)
            self.assertEqual((code, result["result"]), (2, "blocked"))
            self.assertEqual(hp1.read_json(order.parent / "HP1-package" / "blocked-report.json")["code"], "HP1_LWR_ID_INVALID")

    def test_boundary_unresolved_projection_is_rejected_before_output(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            order = build_workspace(Path(temporary), unresolved_projection=True)
            with self.assertRaises(hp1.RuntimeFailure):
                hp1.load_context(order)
            self.assertFalse((order.parent / "HP1-package").exists())
            self.assertFalse((order.parent / "stage-result.json").exists())

    def test_negative_non_main_upstream_hash_drift_is_rejected(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            order = build_workspace(Path(temporary))
            context = hp1.load_context(order)
            write_json(order.parent / "HA1-package" / "generation-session.json", {"ready": False})
            with self.assertRaisesRegex(hp1.AssemblyBlocked, "HP1_UPSTREAM_ENVELOPE_INVALID"):
                hp1.admit_upstreams(context)

    def test_negative_upstream_closure_extra_file_is_rejected(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            order = build_workspace(Path(temporary))
            context = hp1.load_context(order)
            write_json(order.parent / "HS1-package" / "undeclared.json", {"extra": True})
            with self.assertRaisesRegex(hp1.AssemblyBlocked, "HP1_UPSTREAM_ENVELOPE_INVALID"):
                hp1.admit_upstreams(context)

    def test_negative_completion_canonical_binding_is_rejected(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            order = build_workspace(Path(temporary))
            context = hp1.load_context(order)
            completion_path = order.parent / "HC1-package" / "stage-completion.json"
            completion = hp1.read_json(completion_path)
            completion["canonical_artifacts"] = [file_ref(order.parent / "HC1-package" / "package-manifest.json", order.parent, "canonical")]
            write_json(completion_path, completion)
            context.work_order["upstream_completions"][3]["completion_sha256"] = hp1.file_hash(completion_path)
            with self.assertRaisesRegex(hp1.AssemblyBlocked, "HP1_UPSTREAM_ENVELOPE_INVALID"):
                hp1.admit_upstreams(context)


if __name__ == "__main__":
    unittest.main()
