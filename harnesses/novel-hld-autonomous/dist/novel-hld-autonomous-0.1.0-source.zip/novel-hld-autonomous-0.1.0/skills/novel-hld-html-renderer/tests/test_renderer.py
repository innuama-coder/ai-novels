from __future__ import annotations
import copy,json,subprocess,sys,tempfile,unittest
from pathlib import Path
from unittest.mock import patch

HERE=Path(__file__).resolve().parent;sys.path.insert(0,str(HERE));import public_fixture as fx  # noqa:E402
C=fx.C;publisher=fx.ab.publisher
from runtime.package_envelope import validate_completion_bindings,validate_manifest,validate_ready_profile,validate_result_envelope  # noqa:E402
from runtime.canonical import read_json  # noqa:E402
from render_validation import validate_render_model  # noqa:E402

def write(path,value):fx.ab.write_json(path,value)
def tree(root):return {p.relative_to(root).as_posix():p.read_bytes() for p in root.rglob("*") if p.is_file()}
def rewrite_allow(work_path,gate_path,allow,workspace):
    work=read_json(work_path);gate=read_json(gate_path);work["file_allowlist"]=allow;gate["file_allowlist"]=allow;write(gate_path,gate);work["input_gate_ref"]=fx.ab.fref(gate_path,workspace,"input_gate");write(work_path,work);return work
class HH1CRuntimeTests(unittest.TestCase):
    def build(self):self.temp=tempfile.TemporaryDirectory();self.addCleanup(self.temp.cleanup);return fx.build_c(Path(self.temp.name))
    def test_ready_profile_accessible_chinese_and_envelope(self):
        fixture,work,order,_,_,_=self.build();code,result=C.execute(work);package=fixture.workspace/order["output_directory"]
        self.assertEqual((code,result["result"],result["result_scope"]),(0,"ready","composite_internal"));validate_ready_profile(package,"HH1.C");validate_manifest(package,read_json(package/"package-manifest.json"));validate_result_envelope(result,order)
        self.assertFalse((package/"stage-completion.json").exists());html=(package/"hld-human-review-report.html").read_text(encoding="utf-8");self.assertIn("小说高层设计评审报告",html);self.assertIn("整体叙事架构",html);self.assertIn("节点",html);self.assertIn("评审问题",html);self.assertIn("图形文字说明",html);self.assertNotIn(chr(0xfffd),html)
        report=read_json(fixture.workspace/"internal/HH1-A/package/hld-human-review-report.json");registry=read_json(package/"render-target-registry.json");self.assertEqual(validate_render_model(html,report,registry),[]);self.assertEqual(len(registry["targets"]),sum(len(report[name]) for name,_ in C.SECTIONS)+len(report["visual_models"]))
    def test_deterministic_across_independent_workspaces(self):
        values=[]
        for _ in range(2):
            with tempfile.TemporaryDirectory() as temp:
                fixture,work,order,_,_,_=fx.build_c(Path(temp));self.assertEqual(C.execute(work)[0],0);values.append(tree(fixture.workspace/order["output_directory"]))
        self.assertEqual(values[0],values[1])
    def test_machine_contract_and_public_cli(self):
        fixture,work,order,_,_,_=self.build();contract=json.loads((C.SKILL_ROOT/"references/runtime-contract.json").read_text(encoding="utf-8"));self.assertEqual(contract["required_roles"],list(C.REQUIRED_ROLES));self.assertEqual(contract["public_entrypoint"]["path"],"skills/novel-hld-html-renderer/scripts/run_skill.py");self.assertEqual(len(C.impl_hash()),64)
        done=subprocess.run([sys.executable,str(C.SKILL_ROOT/"scripts/run_skill.py"),str(work)],capture_output=True,text=True,timeout=60);self.assertEqual((done.returncode,done.stderr),(0,""));self.assertTrue((fixture.workspace/order["output_directory"]/C.SPEC.canonical_name).is_file())
    def test_full_real_a_b_c_publisher_integration_and_byte_copy(self):
        fixture,c_path,c_order,_,a_path,b_path=self.build();self.assertEqual(C.execute(c_path)[0],0);ws=fixture.workspace;(ws/"stage-result.json").unlink(missing_ok=True);tasks=fx.ready_tasks(fixture,a_path,b_path,c_path);publish_order=fixture.publish_order("HH1",tasks);code,result=publisher.execute(publish_order);package=ws/"HH1-package"
        self.assertEqual((code,result["result"]),(0,"ready"));validate_ready_profile(package,"HH1");manifest=read_json(package/"package-manifest.json");completion=read_json(package/"stage-completion.json");validate_manifest(package,manifest);validate_completion_bindings(ws,package,completion)
        for source,target in ((ws/"internal/HH1-A/package/hld-human-review-report.json",package/"hld-human-review-report.json"),(ws/"internal/HH1-B/package/presentation-fidelity-review.json",package/"presentation-fidelity-review.json"),(ws/"internal/HH1-C/package/hld-human-review-report.html",package/"hld-human-review-report.html"),(ws/"internal/HH1-C/package/render-target-registry.json",package/"render-target-registry.json")):self.assertEqual(source.read_bytes(),target.read_bytes())
    def test_extra_missing_and_reordered_reads_fail_hard(self):
        for mode in ("extra","missing","reordered"):
            with self.subTest(mode=mode):
                with tempfile.TemporaryDirectory() as temp:
                    fixture,work,order,gate,_,_=fx.build_c(Path(temp));allow=copy.deepcopy(order["file_allowlist"])
                    if mode=="extra":extra=fixture.workspace/"sample-chapter.md";extra.write_text("正文",encoding="utf-8");allow.append(fx.ab.fref(extra,fixture.workspace,"sample_chapter"))
                    elif mode=="missing":allow.pop()
                    else:allow[0],allow[1]=allow[1],allow[0]
                    rewrite_allow(work,gate,allow,fixture.workspace)
                    with self.assertRaises(C.InternalCondition):C.execute(work)
                    self.assertFalse((fixture.workspace/order["output_directory"]).exists())
    def test_report_tamper_with_updated_allow_is_blocked_by_a_manifest(self):
        fixture,work,order,gate,_,_=self.build();report=fixture.workspace/"internal/HH1-A/package/hld-human-review-report.json";value=read_json(report);value["title_and_decision_scope"][0]["conclusion"]="篡改";write(report,value);allow=copy.deepcopy(order["file_allowlist"])
        for item in allow:
            if item["role"]=="human_review_report":item["sha256"]=publisher.sha256(report)
        rewrite_allow(work,gate,allow,fixture.workspace);code,result=C.execute(work);package=fixture.workspace/order["output_directory"]
        self.assertEqual((code,result["result"],result["blocker_class"]),(2,"blocked","upstream_defect"));self.assertFalse((package/C.SPEC.canonical_name).exists())
    def test_duplicate_dom_id_becomes_durable_local_revise(self):
        fixture,work,order,_,_,_=self.build();original=C.render_document
        def duplicate(report,review):document,targets=original(report,review);return document.replace("</body>",'<div id="overall_narrative_architecture"></div></body>'),targets
        with patch.object(C,"render_document",side_effect=duplicate):code,result=C.execute(work)
        package=fixture.workspace/order["output_directory"];self.assertEqual((code,result["result"]),(2,"revise"));self.assertFalse((package/C.SPEC.canonical_name).exists())
    def test_dangling_svg_edge_is_durable_blocked(self):
        fixture,work,order,_,_,_=self.build();original=C.admit
        def inject(context):value=original(context);value=copy.deepcopy(value);value["report"]["visual_models"][0]["edges"][0]["to"]="MISSING";return value
        with patch.object(C,"admit",side_effect=inject):code,result=C.execute(work)
        package=fixture.workspace/order["output_directory"];self.assertEqual((code,result["result"]),(2,"blocked"));self.assertFalse((package/C.SPEC.canonical_name).exists())
    def test_script_and_external_url_content_is_escaped_not_executed(self):
        fixture,work,_,_,_,_=self.build();context=C.load_context(work,C.SPEC,C.impl_hash(),C._catalog());admitted=C.admit(context);report=copy.deepcopy(admitted["report"]);report["overall_narrative_architecture"][0]["conclusion"]='<script src="https://evil.invalid/x.js">alert(1)</script>';report["visual_models"][0]["nodes"][0]["label"]='https://evil.invalid is text';document,targets=C.render_document(report,admitted["review"]);registry={"targets":targets}
        self.assertIn("&lt;script",document);self.assertNotIn('<script src=',document);self.assertNotIn('src="https://',document);self.assertEqual(validate_render_model(document,report,registry),[])
    def test_b_nonready_prefix_publishes_without_c_issue(self):
        with tempfile.TemporaryDirectory() as temp:
            fixture,b_path,b_order,_,b_draft,_=fx.ab.build_b(Path(temp),"fail");self.assertEqual(fx.ab.B.execute(b_path,b_draft)[0],2);ws=fixture.workspace;a_path=ws/next(item["path"] for item in b_order["file_allowlist"] if item["role"]=="hh1_a_work_order");a=fx.task_fixture("HH1-A",ws,a_path,("hld-human-review-report.json",));b_work=read_json(b_path);b_pkg=ws/b_work["output_directory"];b=fx.ab.PUBTEST.TaskFixture("HH1-B",b_path,b_work,b_pkg.parent/"stage-result.json",b_pkg/"result-manifest.json",());(ws/"stage-result.json").unlink(missing_ok=True);publish=fixture.publish_order("HH1",[a,b]);code,result=publisher.execute(publish)
            self.assertEqual((code,result["result"]),(2,"blocked"));self.assertFalse((ws/"internal/HH1-C").exists());self.assertFalse((ws/"HH1-package/hld-human-review-report.html").exists())
    def test_c_nonready_prefix_publishes_without_canonical(self):
        fixture,c_path,_,_,a_path,b_path=self.build();original=C.render_document
        def duplicate(report,review):document,targets=original(report,review);return document.replace("</body>",'<div id="overall_narrative_architecture"></div></body>'),targets
        with patch.object(C,"render_document",side_effect=duplicate):self.assertEqual(C.execute(c_path)[0],2)
        ws=fixture.workspace;c_work=read_json(c_path);c_pkg=ws/c_work["output_directory"];tasks=fx.ready_tasks(fixture,a_path,b_path,c_path)[:2]+[fx.ab.PUBTEST.TaskFixture("HH1-C",c_path,c_work,c_pkg.parent/"stage-result.json",c_pkg/"result-manifest.json",())];(ws/"stage-result.json").unlink(missing_ok=True);publish=fixture.publish_order("HH1",tasks);code,result=publisher.execute(publish)
        self.assertEqual((code,result["result"]),(2,"revise"));self.assertFalse((ws/"HH1-package/hld-human-review-report.html").exists())

if __name__=="__main__":unittest.main()
