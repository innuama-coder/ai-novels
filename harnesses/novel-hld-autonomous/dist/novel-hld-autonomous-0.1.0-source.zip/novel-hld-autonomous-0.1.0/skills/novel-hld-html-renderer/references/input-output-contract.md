# 输入输出契约

## 输入硬准入

当前 Harness work order/input gate 必须满足：`stage=HH1`、`action=execute`、`exact_owner_skill=novel-hld-html-renderer`、top-level upstream 精确为 `[HB0,HP1,HQ2]`、`unresolved_projection=[]`。二者 run、state、owner、implementation、allowlist、return/revision binding 必须逐值一致；所有引用 path 必须受控、sha256 当前。

内容读取权只有：

- HH1-A 密封 `hld-human-review-report.json` 与 manifest；
- HH1-B 密封 `presentation-fidelity-review.json` 与 manifest；
- 固定 report schema、HTML template、CSS、renderer implementation snapshot。

不得授予或读取 HP1、canonical、构思、故事源、聊天、旧报告或预期答案。HH1-B 必须 `verdict=pass`，其 `report_ref` 必须逐值等于当前 HH1-A report 引用；renderer snapshot hash 必须等于 work order `implementation_sha256`。

## report 契约

输入必须通过 [HH1-A 权威 report schema](../../novel-hld-review-report-assembler/references/hld-human-review-report.schema.json)。正式标题/项目标题、评审范围、版本、状态、作者决定说明和目录来源于 `title_and_decision_scope`。七个内容域中的每个展示元素使用 `HRE-`，visual models 使用 `HVG-`；元素公共字段固定为 `id / element_kind / conclusion / source_ids / locators / visual_role / review_question`。Renderer 不接受 `element_id` 同义字段。

## 渲染契约

- 每个 report element 恰好生成一个带 `data-render-target-id` 与 `data-report-element-id` 的可见 DOM 容器。
- HUI ID 固定为 `HUI-<report_element_id>-<render_role>-0`；当前 profile 每元素只渲染一次，因此 ordinal 固定从 0 开始且集合中唯一。
- 结论、review question、source IDs、locator 和 visual data 逐值 HTML-escape 后呈现；不得解释或重写。
- HVG 使用内联 SVG，必须含 `role=img`、`aria-labelledby`、首子元素 `<title>` 和 `<desc>`，并提供同数据的可见文本替代。
- HTML 必须有 `lang`、准确 `<title>`、skip link、header/nav/main/footer landmark、唯一 h1、顺序 heading、可键盘访问的 fragment links。
- CSS 内联；支持 320 CSS px reflow、长字符串换行、forced colors、reduced motion 和 `@media print/@page`。不得依赖 JS。
- 禁止远程 URL、外部资源、script、iframe、object/embed、非 fragment link 和未转义输入。
- 相同 report/template/CSS/renderer bytes 必须产生字节完全相同的 HTML、registry、execution 和 validation。

## render target registry

`render-target-registry.json` 顶层字段和每个 target 都由 schema 冻结。每项包含：

- `id`：HUI ID；
- `dom_locator`：`[data-render-target-id="<HUI>"]`；
- `render_role`；
- `report_element_id`：原 HRE/HVG；
- `report_element_kind`；
- `visual_model_id`：HVG 时同其 ID，否则 null；
- `content_sha256`：该原始 report element 的 canonical JSON hash。

registry HUI 集合必须与 HTML `data-render-target-id` 集合全等；`data-report-element-id` 回指集合必须与 report HRE/HVG 集合全等。

## 交付与结果信封

ready 内容包精确是 catalog 2.4-B 的五文件 profile。manifest 不包含包外 work-order result；包外 result 固定 `result_scope=composite_internal`、`result=ready`、只有 `internal_manifest_ref`，`completion_ref=null`。

输入、hash、fidelity binding 或隔离失败 → fail closed，不渲染。脚本/模板/registry 本地缺陷 → `revise/local_candidate`。本技能不得生成 HH1 顶层结果、publisher 包或 completion。
