# HS1 SOP

## 1. Admit coordinates

Verify HS1 identity, current `[HB0, HA1]` order, hashes, active return binding,
and allowlist. Resolve HA1 units by registered role and stable IDs only.

## 2. Assess unresolved dependencies

Create exactly `HDD-HS1-<source_id>` for every projected source. Stop before
candidate generation if any source is required now.

## 3. Build the semantic register

Read authoritative object values and identify actual lines. Record type,
driver, goal, conflict, turn, payoff, mandatory/open/optional status, and
source evidence. Separate background-carried material from active storylines.

## 4. Test each line alone

Trace establishment → development → turn → payoff/open result. Record missing
functions without inventing events. A gap in conception authority is a fail,
not an invitation to fill it.

## 5. Generate choreography options

Create at least two materially distinct placements or provide unique-solution
evidence. Map segments to HA1 units and compare connection effects, switch
cost, orientation, causality, emotional contrast, theme, and ending payoff.

## 6. Project the selected network

Publish the register, segments, unit matrix, typed connections,
convergence/split points, existing-event placement, and one disposition per
line. Use only stable IDs.

## 7. Reconstruct and attack

Attempt to remove, duplicate, disconnect, starve, overinflate, or prematurely
resolve every line. Prove the trunk remains continuous and the combined network
recovers the authorized story subject.

## 8. Publish

Run the deterministic entrypoint and leave routing to the harness. A ready
result is consumable by HC1; a revise or blocked result is durable evidence,
not a partial handoff.
