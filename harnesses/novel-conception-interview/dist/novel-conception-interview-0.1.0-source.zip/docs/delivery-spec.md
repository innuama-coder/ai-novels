# Delivery Spec

For each I-stage, deliver one design artifact plus a session evidence directory:

```text
interview-sessions/I#/session-id/
  plan.v1.json [plan.v2.json ...]
  events.ndjson
  report.md
  validation.json
  stage-completion.json
```

The final bundle additionally contains `interview-integrity-report.md`, one HTML
brief, `author-approval.json`, a development map and a conception review.
Every packet must expose its uncertainty register and input completion paths.
