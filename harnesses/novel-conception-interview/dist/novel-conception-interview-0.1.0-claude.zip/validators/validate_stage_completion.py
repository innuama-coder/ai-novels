#!/usr/bin/env python3
"""Validate a hash-bound stage completion and its mandatory upstream evidence."""
from __future__ import annotations

import hashlib
import json
import subprocess
import sys
from pathlib import Path

INTERVIEW_STAGES = {"I0", "I1", "I2", "I3", "I4", "I5"}
INTERVIEW_ORDER = ["I0", "I1", "I2", "I3", "I4", "I5"]
SEMANTIC_AREAS = {"intent": "I0", "subject": "I1", "world": "I2", "character": "I3", "causality": "I4", "narrative": "I5"}
ALLOWED_RETURN_TARGETS = {
    "I2": {"I0", "I1"}, "I3": {"I0", "I1", "I2"},
    "I4": {"I0", "I1", "I2", "I3"}, "I5": {"I0", "I1", "I2", "I4"},
    "V1": {"I0", "I1", "I2", "I3", "I4", "I5"},
    "V2": {"I0", "I1", "I2", "I3", "I4", "I5"},
    "R1": {"I0", "I1", "I2", "I3", "I4", "I5"},
}
REQUIRED_INPUT_STAGES = {
    "I0": [], "I1": ["I0"], "I2": ["I0", "I1"],
    "I3": ["I0", "I1", "I2"], "I4": ["I0", "I1", "I2", "I3"],
    "I5": ["I0", "I1", "I2", "I3", "I4"],
    "V1": ["I0", "I1", "I2", "I3", "I4", "I5"], "V2": ["V1"],
    "D1": ["I0", "I1", "I2", "I3", "I4", "I5", "V1", "V2"],
    "R1": ["V1", "V2", "D1"],
}
D1_PACKAGE_FILES = {
    "map-data.json",
    "development-map.md",
    "coverage-matrix.md",
    "map-check.md",
    "validation.json",
}
R1_PACKAGE_FILES = {
    "review-data.json",
    "novel-design-brief.md",
    "conception-review.md",
    "independent-handoff.json",
    "validation.json",
}
D1_VALIDATOR = (
    Path(__file__).resolve().parents[3]
    / "skills"
    / "novel-development-map-designer"
    / "scripts"
    / "validate_development_map.py"
)
R1_VALIDATOR = (
    Path(__file__).resolve().parents[3]
    / "skills"
    / "novel-conception-reviewer"
    / "scripts"
    / "validate_conception_review.py"
)


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load(path: Path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def fail(message: str) -> int:
    print("FAIL: " + message)
    return 1


def load_hash_bound_reference(base: Path, reference, label: str):
    if not isinstance(reference, dict):
        return None, None, f"{label} is not a hash-bound reference"
    relative_path = reference.get("path")
    expected_hash = reference.get("sha256")
    if not isinstance(relative_path, str) or not relative_path or not isinstance(expected_hash, str):
        return None, None, f"{label} is not a hash-bound reference"
    relative = Path(relative_path)
    if relative.is_absolute():
        return None, None, f"{label} must use a relative path"
    candidate = (base / relative).resolve()
    if not candidate.is_file() or digest(candidate) != expected_hash:
        return None, None, f"{label} is missing or has changed"
    try:
        return candidate, load(candidate), None
    except json.JSONDecodeError:
        return None, None, f"{label} is invalid"


def valid_return_package(data, run_id: str, base: Path):
    origin = data.get("origin_stage")
    target = data.get("target_stage")
    valid = (
        data.get("harness") == "novel-conception-interview"
        and data.get("run_id") == run_id
        and data.get("status") == "active"
        and isinstance(data.get("evidence"), list) and bool(data["evidence"])
        and all(
            isinstance(item, str) and item.strip()
            for item in data["evidence"]
        )
        and isinstance(data.get("requested_decision"), str)
        and bool(data["requested_decision"].strip())
        and isinstance(data.get("affected_artifacts"), list) and bool(data["affected_artifacts"])
        and all(
            isinstance(item, str) and item.strip()
            for item in data["affected_artifacts"]
        )
        and target in ALLOWED_RETURN_TARGETS.get(origin, set())
    )
    if valid and origin == "V2":
        _, approval, error = load_hash_bound_reference(base, data.get("author_approval"), "V2 revision author approval")
        valid = not error and approval.get("harness") == "novel-conception-interview" and approval.get("run_id") == run_id and approval.get("approval_scope") == "V2" and approval.get("decision") == "revise" and approval.get("record_assurance") == "self_recorded"
    return valid, target


def validate_d1_package_manifest(
    manifest_path: Path,
    manifest,
    run_id: str,
    validation_path: Path,
    validation_hash: str,
):
    if not isinstance(manifest, dict):
        return "D1 package manifest root is not an object"
    if (
        manifest.get("schema_version") != "1.0"
        or manifest.get("harness") != "novel-conception-interview"
        or manifest.get("run_id") != run_id
        or manifest.get("stage") != "D1"
        or manifest.get("verdict") != "ready"
    ):
        return "D1 package manifest does not identify a ready package for this run"
    records = manifest.get("files")
    if not isinstance(records, list):
        return "D1 package manifest files are invalid"
    observed = {}
    for record in records:
        if not isinstance(record, dict):
            return "D1 package manifest contains an invalid file record"
        name = record.get("path")
        expected_hash = record.get("sha256")
        if (
            name not in D1_PACKAGE_FILES
            or name in observed
            or not isinstance(expected_hash, str)
        ):
            return "D1 package manifest file set is invalid or duplicated"
        candidate = (manifest_path.parent / name).resolve()
        if candidate.parent != manifest_path.parent or not candidate.is_file():
            return f"D1 package file is missing or escapes its package: {name}"
        if digest(candidate) != expected_hash:
            return f"D1 package file has changed: {name}"
        observed[name] = (candidate, expected_hash)
    if set(observed) != D1_PACKAGE_FILES:
        return "D1 package manifest must bind the complete five-file package"
    validation_record = manifest.get("validation")
    if (
        not isinstance(validation_record, dict)
        or validation_record.get("path") != "validation.json"
        or validation_record.get("sha256") != validation_hash
        or observed["validation.json"][0] != validation_path
        or observed["validation.json"][1] != validation_hash
    ):
        return "D1 package manifest is not bound to completion validation evidence"
    return None


def validate_r1_package_manifest(
    manifest_path: Path,
    manifest,
    run_id: str,
    validation_path: Path,
    validation_hash: str,
):
    if not isinstance(manifest, dict):
        return "R1 package manifest root is not an object"
    if (
        manifest.get("schema_version") != "1.0"
        or manifest.get("harness") != "novel-conception-interview"
        or manifest.get("run_id") != run_id
        or manifest.get("stage") != "R1"
        or manifest.get("verdict") != "ready"
    ):
        return "R1 package manifest does not identify a ready package for this run"
    records = manifest.get("files")
    if not isinstance(records, list):
        return "R1 package manifest files are invalid"
    observed = {}
    for record in records:
        if not isinstance(record, dict):
            return "R1 package manifest contains an invalid file record"
        name = record.get("path")
        expected_hash = record.get("sha256")
        if (
            name not in R1_PACKAGE_FILES
            or name in observed
            or not isinstance(expected_hash, str)
        ):
            return "R1 package manifest file set is invalid or duplicated"
        candidate = (manifest_path.parent / name).resolve()
        if candidate.parent != manifest_path.parent or not candidate.is_file():
            return f"R1 package file is missing or escapes its package: {name}"
        if digest(candidate) != expected_hash:
            return f"R1 package file has changed: {name}"
        observed[name] = (candidate, expected_hash)
    if set(observed) != R1_PACKAGE_FILES:
        return "R1 package manifest must bind the complete five-file package"
    validation_record = manifest.get("validation")
    if (
        not isinstance(validation_record, dict)
        or validation_record.get("path") != "validation.json"
        or validation_record.get("sha256") != validation_hash
        or observed["validation.json"][0] != validation_path
        or observed["validation.json"][1] != validation_hash
    ):
        return "R1 package manifest is not bound to completion validation evidence"
    for field, filename in (
        ("author_review_artifact", "conception-review.md"),
        ("independent_handoff", "independent-handoff.json"),
    ):
        record = manifest.get(field)
        if (
            not isinstance(record, dict)
            or record.get("path") != filename
            or record.get("sha256") != observed[filename][1]
        ):
            return f"R1 package manifest has an invalid {field} reference"
    return None


def reference_identity(base: Path, reference):
    if not isinstance(reference, dict):
        return None
    path = reference.get("path")
    sha = reference.get("sha256")
    if not isinstance(path, str) or not path or not isinstance(sha, str):
        return None
    relative = Path(path)
    if relative.is_absolute():
        return None
    return ((base / relative).resolve(), sha.lower())


def validate_d1_input_binding(
    map_path: Path,
    map_data,
    packet_path: Path,
    packet,
    input_references,
):
    if not isinstance(map_data, dict):
        return "D1 map-data root is not an object"
    gate = map_data.get("input_gate")
    if not isinstance(gate, dict):
        return "D1 map-data lacks input_gate"
    packet_base = packet_path.parent
    map_base = map_path.parent
    if reference_identity(map_base, gate.get("run_state")) != reference_identity(
        packet_base, packet.get("run_state")
    ):
        return "D1 completion and map-data bind different run-state records"
    interviews = gate.get("interview_completions")
    if not isinstance(interviews, list) or len(interviews) != len(INTERVIEW_ORDER):
        return "D1 map-data must bind exactly the six current interview completions"
    observed = {}
    for reference in interviews:
        if not isinstance(reference, dict):
            return "D1 map-data contains an invalid interview completion reference"
        stage = reference.get("stage")
        if stage not in INTERVIEW_STAGES or stage in observed:
            return "D1 map-data interview completion stages are invalid or duplicated"
        observed[stage] = reference
    for stage in INTERVIEW_ORDER:
        if reference_identity(map_base, observed.get(stage)) != reference_identity(
            packet_base, input_references.get(stage)
        ):
            return f"D1 completion and map-data bind different {stage} completions"
    for stage, field in (("V1", "v1_completion"), ("V2", "v2_completion")):
        if reference_identity(map_base, gate.get(field)) != reference_identity(
            packet_base, input_references.get(stage)
        ):
            return f"D1 completion and map-data bind different {stage} completions"
    if reference_identity(map_base, gate.get("author_approval")) != reference_identity(
        packet_base, packet.get("author_approval")
    ):
        return "D1 completion and map-data bind different author approval records"
    return None


def canonical_d1_validation(package_dir: Path):
    if not D1_VALIDATOR.is_file():
        return None, "canonical D1 validator is unavailable"
    try:
        process = subprocess.run(
            [sys.executable, str(D1_VALIDATOR), str(package_dir)],
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            check=False,
            timeout=30,
        )
    except subprocess.TimeoutExpired:
        return None, "canonical D1 validation timed out"
    except OSError as exc:
        return None, f"canonical D1 validation could not run: {exc}"
    try:
        result = json.loads(process.stdout)
    except json.JSONDecodeError:
        detail = process.stderr.strip() or process.stdout.strip() or "no output"
        return None, "canonical D1 validator returned invalid output: " + detail
    if process.returncode != 0:
        return result, "canonical D1 validation did not pass"
    return result, None


def canonical_r1_validation(package_dir: Path):
    if not R1_VALIDATOR.is_file():
        return None, "canonical R1 validator is unavailable"
    try:
        process = subprocess.run(
            [sys.executable, str(R1_VALIDATOR), str(package_dir)],
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            check=False,
            timeout=60,
        )
    except subprocess.TimeoutExpired:
        return None, "canonical R1 validation timed out"
    except OSError as exc:
        return None, f"canonical R1 validation could not run: {exc}"
    try:
        result = json.loads(process.stdout)
    except json.JSONDecodeError:
        detail = process.stderr.strip() or process.stdout.strip() or "no output"
        return None, "canonical R1 validator returned invalid output: " + detail
    if process.returncode != 0:
        return result, "canonical R1 validation did not pass"
    return result, None


def validate_ready_completion(completion_path: Path):
    try:
        process = subprocess.run(
            [sys.executable, str(Path(__file__).resolve()), str(completion_path)],
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            check=False,
            timeout=30,
        )
    except subprocess.TimeoutExpired:
        return "upstream completion validation timed out"
    except OSError as exc:
        return f"upstream completion validation could not run: {exc}"
    if process.returncode != 0:
        return (
            "upstream completion failed canonical validation: "
            + (process.stdout or process.stderr).strip()
        )
    return None


def validate_independent_handoff(
    handoff,
    run_id: str,
    handoff_path: Path,
    d1_completion_path: Path,
    d1_completion,
):
    if not isinstance(handoff, dict):
        return "R1 independent handoff root is not an object"
    if (
        handoff.get("schema_version") != "1.0"
        or handoff.get("harness") != "novel-conception-interview"
        or handoff.get("run_id") != run_id
        or handoff.get("stage") != "R1"
        or handoff.get("verdict") != "pass"
        or handoff.get("reviewer_role") != "independent_developer"
        or handoff.get("assurance") != "role_separated_execution"
        or handoff.get("evidence_scope") != "d1_package_only"
    ):
        return (
            "R1 independent handoff does not identify a passing "
            "role-separated execution"
        )
    reviewer_id = handoff.get("reviewer_id")
    method = handoff.get("method")
    if not isinstance(reviewer_id, str) or not reviewer_id.strip():
        return "R1 independent handoff lacks reviewer_id"
    if not isinstance(method, str) or len(method.strip()) < 20:
        return "R1 independent handoff method is not auditable"
    d1_manifest = (
        d1_completion_path.parent / d1_completion.get("design_artifact", "")
    ).resolve()
    if reference_identity(handoff_path.parent, handoff.get("d1_package")) != (
        d1_manifest,
        str(d1_completion.get("design_artifact_sha256", "")).lower(),
    ):
        return "R1 independent handoff is not bound to the validated D1 package"
    try:
        map_data = load(d1_manifest.parent / "map-data.json")
    except (OSError, json.JSONDecodeError):
        return "R1 independent handoff cannot read the validated D1 map-data"
    if not isinstance(map_data, dict) or map_data.get("schema_version") != "2.2":
        return "R1 independent handoff requires D1 map-data schema 2.2"
    controls = {
        item.get("id")
        for item in map_data.get("control_points", [])
        if isinstance(item, dict) and isinstance(item.get("id"), str)
    }
    units = {
        item.get("id")
        for item in map_data.get("units", [])
        if isinstance(item, dict) and isinstance(item.get("id"), str)
    }
    obligations = {
        item.get("id")
        for item in map_data.get("information_obligations", [])
        if isinstance(item, dict) and isinstance(item.get("id"), str)
    }
    derivations = {
        item.get("id"): item
        for item in map_data.get("derivation_claims", [])
        if isinstance(item, dict) and isinstance(item.get("id"), str)
    }
    self_test = map_data.get("handoff_self_test")
    if (
        isinstance(self_test, dict)
        and self_test.get("reviewer_id") == reviewer_id
    ):
        return "R1 reviewer_id must differ from the D1 self-test executor"
    subject_ids = handoff.get("subject_ids")
    if (
        not isinstance(subject_ids, list)
        or not all(isinstance(item, str) and item.strip() for item in subject_ids)
        or len(subject_ids) != len(set(subject_ids))
        or set(subject_ids) != units
    ):
        return "R1 independent handoff subject_ids must exactly cover all D1 units"
    reviews = handoff.get("derivation_reviews")
    if not isinstance(reviews, list):
        return "R1 independent handoff derivation_reviews are invalid"
    reviewed = set()
    for review in reviews:
        if not isinstance(review, dict):
            return "R1 independent handoff contains an invalid derivation review"
        derivation_id = review.get("derivation_id")
        if not isinstance(derivation_id, str) or not derivation_id:
            return "R1 independent handoff contains an invalid derivation id"
        if derivation_id in reviewed:
            return "R1 independent handoff contains duplicate derivation reviews"
        reviewed.add(derivation_id)
        claim = derivations.get(derivation_id)
        if claim is None:
            return (
                "R1 independent handoff reviews an unknown derivation: "
                f"{derivation_id}"
            )
        if (
            review.get("status") != "pass"
            or not isinstance(review.get("finding"), str)
            or len(review["finding"].strip()) < 20
            or review.get("source_control_ids") != claim.get("source_controls")
        ):
            return (
                "R1 independent handoff derivation review is not auditable: "
                f"{derivation_id}"
            )
    if reviewed != set(derivations):
        return "R1 independent handoff must review every D1 derivation claim"
    tasks = handoff.get("tasks")
    if not isinstance(tasks, list):
        return "R1 independent handoff tasks are invalid"
    required = {
        "promise",
        "causal_chain",
        "unit_contract",
        "freedom_boundary",
        "drift_detection",
        "scene_plan",
    }
    valid_evidence_ids = controls | units | obligations | set(derivations)
    observed = set()
    for task in tasks:
        if not isinstance(task, dict):
            return "R1 independent handoff contains an invalid task"
        task_id = task.get("id")
        if task_id in observed:
            return "R1 independent handoff contains duplicate tasks"
        observed.add(task_id)
        if (
            task.get("status") != "pass"
            or not isinstance(task.get("response"), str)
            or len(task["response"].strip()) < 40
            or not isinstance(task.get("evidence_ids"), list)
            or not task["evidence_ids"]
            or not all(
                isinstance(item, str) and item.strip()
                for item in task["evidence_ids"]
            )
        ):
            return f"R1 independent handoff task is not auditable: {task_id}"
        unknown_ids = set(task["evidence_ids"]) - valid_evidence_ids
        if unknown_ids:
            return (
                f"R1 independent handoff task cites unknown evidence: {task_id}: "
                + ", ".join(sorted(unknown_ids))
            )
    if observed != required:
        return "R1 independent handoff must contain exactly the six required tasks"
    return None


def main(argv: list[str]) -> int:
    if len(argv) != 2:
        print("usage: validate_stage_completion.py <stage-completion.json>", file=sys.stderr)
        return 2
    packet_path = Path(argv[1]).resolve()
    try:
        packet = load(packet_path)
    except (OSError, json.JSONDecodeError) as exc:
        return fail(f"invalid completion packet: {exc}")
    required = {"harness", "run_id", "stage", "session_id", "status", "design_artifact", "design_artifact_sha256", "validation", "input_completions", "run_state"}
    if missing := required - set(packet):
        return fail("missing completion fields: " + ", ".join(sorted(missing)))
    if packet["harness"] != "novel-conception-interview" or packet["status"] != "ready":
        return fail("completion is not a ready packet for this harness")
    if packet["stage"] not in REQUIRED_INPUT_STAGES:
        return fail("unknown stage")
    state = packet.get("run_state", {})
    state_path = (packet_path.parent / state.get("path", "")).resolve()
    if not state_path.is_file() or digest(state_path) != state.get("sha256"):
        return fail("completion lacks hash-bound run state")
    try:
        state_data = load(state_path)
    except json.JSONDecodeError:
        return fail("run state is invalid")
    if state_data.get("harness") != "novel-conception-interview" or state_data.get("run_id") != packet["run_id"]:
        return fail("run state belongs to another conception run")
    active_return = state_data.get("active_return")
    if active_return is not None:
        _, return_data, error = load_hash_bound_reference(state_path.parent, active_return, "active return package")
        if error:
            return fail(error)
        valid_return, target = valid_return_package(return_data, packet["run_id"], state_path.parent)
        if not valid_return:
            return fail("active return package violates the bounded return contract")
        prior_rounds = 0
        for resolved in state_data.get("resolved_returns", []):
            _, prior_return, prior_error = load_hash_bound_reference(state_path.parent, resolved.get("return") if isinstance(resolved, dict) else None, "resolved return package")
            if prior_error:
                return fail(prior_error)
            if prior_return.get("origin_stage") == return_data.get("origin_stage"):
                prior_rounds += 1
        if prior_rounds >= 2:
            return fail("return-round limit reached; author direction is required")
        resolution = packet.get("return_resolution")
        if packet["stage"] != target:
            return fail("an active return package blocks further handoff")
        if reference_identity(
            packet_path.parent, resolution
        ) != reference_identity(state_path.parent, active_return):
            return fail("the return target must hash-bind the active return package")
    artifact = (packet_path.parent / packet["design_artifact"]).resolve()
    validation = (packet_path.parent / packet["validation"].get("path", "")).resolve()
    if not artifact.is_file() or digest(artifact) != packet["design_artifact_sha256"]:
        return fail("design artifact is missing or has changed")
    if packet["validation"].get("verdict") != "ready" or not validation.is_file() or digest(validation) != packet["validation"].get("sha256"):
        return fail("validation evidence is missing or has changed")
    try:
        validation_data = load(validation)
    except json.JSONDecodeError as exc:
        return fail(f"invalid validation evidence: {exc}")
    if validation_data.get("verdict") != "ready" or validation_data.get("run_id") != packet["run_id"]:
        return fail("validation evidence is not ready for this conception run")
    if packet["stage"] in INTERVIEW_STAGES:
        report = packet.get("report", {})
        report_path = (packet_path.parent / report.get("path", "")).resolve()
        if not report_path.is_file() or digest(report_path) != report.get("sha256"):
            return fail("interview completion lacks the current rendered report")
    seen = []
    upstream_packets = []
    input_references = {}
    for reference in packet["input_completions"]:
        input_path, upstream, error = load_hash_bound_reference(packet_path.parent, reference, "input completion")
        if error:
            return fail(error)
        if upstream.get("harness") != "novel-conception-interview" or upstream.get("status") != "ready":
            return fail(f"input completion is not ready: {reference.get('path', '<unknown>')}")
        if upstream.get("run_id") != packet["run_id"]:
            return fail(f"input completion belongs to another run: {reference.get('path', '<unknown>')}")
        upstream_stage = upstream.get("stage")
        if upstream_stage in input_references:
            return fail(f"duplicate input completion stage: {upstream_stage}")
        seen.append(upstream_stage)
        input_references[upstream_stage] = reference
        upstream_packets.append((input_path, upstream))
    missing_inputs = set(REQUIRED_INPUT_STAGES[packet["stage"]]) - set(seen)
    if missing_inputs:
        return fail("stage bypasses required inputs: " + ", ".join(sorted(missing_inputs)))
    if packet["stage"] == "D1" and set(seen) != set(REQUIRED_INPUT_STAGES["D1"]):
        return fail("D1 input completions must be exactly current I0-I5, V1 and V2")
    current_interviews = state_data.get("current_interview_completions", {})
    if not isinstance(current_interviews, dict):
        return fail("run state current_interview_completions is invalid")
    for required_stage in REQUIRED_INPUT_STAGES[packet["stage"]]:
        if required_stage in INTERVIEW_STAGES and input_references.get(required_stage) != current_interviews.get(required_stage):
            return fail(f"stage does not consume the current {required_stage} completion")
    for resolved in state_data.get("resolved_returns", []):
        if not isinstance(resolved, dict):
            return fail("run state has an invalid resolved return")
        _, return_data, error = load_hash_bound_reference(state_path.parent, resolved.get("return"), "resolved return package")
        completion_path, completion_data, completion_error = load_hash_bound_reference(state_path.parent, resolved.get("target_completion"), "resolved return target completion")
        if error:
            return fail(error)
        if completion_error:
            return fail(completion_error)
        valid_return, target = valid_return_package(return_data, packet["run_id"], state_path.parent)
        resolution = completion_data.get("return_resolution")
        completion_state_path, completion_state, completion_state_error = load_hash_bound_reference(completion_path.parent, completion_data.get("run_state"), "resolved return target run state")
        if completion_state_error:
            return fail(completion_state_error)
        resolved_return_identity = reference_identity(
            state_path.parent, resolved.get("return")
        )
        if not valid_return or completion_data.get("harness") != "novel-conception-interview" or completion_data.get("run_id") != packet["run_id"] or completion_data.get("stage") != target or completion_data.get("status") != "ready" or reference_identity(completion_path.parent, resolution) != resolved_return_identity or completion_state.get("harness") != "novel-conception-interview" or completion_state.get("run_id") != packet["run_id"] or reference_identity(completion_state_path.parent, completion_state.get("active_return")) != resolved_return_identity:
            return fail("resolved return does not prove a corrected target completion")
        if not any(path == completion_path for path, _ in upstream_packets):
            return fail("resolved return requires its corrected target completion as input")
        if target in INTERVIEW_STAGES:
            target_index = INTERVIEW_ORDER.index(target)
            for later_stage in INTERVIEW_ORDER[target_index + 1:]:
                current_reference = current_interviews.get(later_stage)
                if current_reference is None:
                    continue
                _, later_completion, later_error = load_hash_bound_reference(state_path.parent, current_reference, f"current {later_stage} completion")
                if later_error:
                    return fail(later_error)
                target_identity = reference_identity(
                    state_path.parent, resolved.get("target_completion")
                )
                later_inputs = {
                    reference_identity(
                        (state_path.parent / current_reference.get("path", "")).resolve().parent,
                        item,
                    )
                    for item in later_completion.get("input_completions", [])
                    if isinstance(item, dict)
                }
                if later_completion.get("stage") != later_stage or target_identity not in later_inputs:
                    return fail(f"current {later_stage} completion is stale after the resolved return")
    v1_packets = [item for item in upstream_packets if item[1].get("stage") == "V1"]
    if packet["stage"] == "V1":
        v1_packets = [(packet_path, packet)]
    if packet["stage"] in {"V1", "V2", "D1", "R1"}:
        if not v1_packets:
            return fail("semantic integrity evidence has no V1 completion")
        semantic = v1_packets[0][1].get("semantic_review", {})
        semantic_path = (v1_packets[0][0].parent / semantic.get("path", "")).resolve()
        if not semantic_path.is_file() or digest(semantic_path) != semantic.get("sha256"):
            return fail("V1 semantic integrity evidence is missing or has changed")
        try:
            semantic_data = load(semantic_path)
        except json.JSONDecodeError:
            return fail("V1 semantic integrity evidence is invalid")
        evidence = semantic_data.get("evidence")
        if semantic_data.get("harness") != "novel-conception-interview" or semantic_data.get("run_id") != packet["run_id"] or semantic_data.get("stage") != "V1" or semantic_data.get("verdict") != "pass" or semantic_data.get("reviewer_role") != "integrity_auditor" or semantic_data.get("return_package") is not None or not isinstance(evidence, list) or len(evidence) != len(SEMANTIC_AREAS):
            return fail("V1 semantic integrity evidence is not a passing review")
        observed = {(item.get("control_area"), item.get("owner_stage")) for item in evidence if isinstance(item, dict) and isinstance(item.get("artifact"), str) and item["artifact"] and isinstance(item.get("finding"), str) and item["finding"].strip()}
        expected = set(SEMANTIC_AREAS.items())
        if observed != expected:
            return fail("V1 semantic evidence must uniquely cover intent, subject, world, character, causality and narrative")
    if packet["stage"] == "D1":
        approval = packet.get("author_approval", {})
        approval_path = (packet_path.parent / approval.get("path", "")).resolve()
        if not approval_path.is_file() or digest(approval_path) != approval.get("sha256"):
            return fail("D1 lacks hash-bound author approval")
        try:
            approval_data = load(approval_path)
        except json.JSONDecodeError:
            return fail("D1 author approval is invalid")
        if approval_data.get("run_id") != packet["run_id"] or approval_data.get("approval_scope") != "V2" or approval_data.get("decision") != "approved" or approval_data.get("record_assurance") != "self_recorded":
            return fail("D1 author approval does not approve this self-recorded run")
        brief = approval_data.get("review_brief", {})
        brief_path = (approval_path.parent / brief.get("path", "")).resolve()
        record = approval_data.get("approval_record", {})
        if not brief_path.is_file() or digest(brief_path) != brief.get("sha256"):
            return fail("D1 author approval is not bound to the reviewed HTML")
        if not isinstance(record.get("event_seq"), int) or not isinstance(record.get("text"), str) or not record["text"].strip():
            return fail("D1 author approval has no recorded author decision")
        v2_packets = [item for item in upstream_packets if item[1].get("stage") == "V2"]
        if not v2_packets or (v2_packets[0][0].parent / v2_packets[0][1].get("design_artifact", "")).resolve() != brief_path or v2_packets[0][1].get("design_artifact_sha256") != brief.get("sha256"):
            return fail("D1 author approval is not bound to the current V2 brief")
        v1_inputs_of_v2 = [
            reference
            for reference in v2_packets[0][1].get("input_completions", [])
            if isinstance(reference, dict)
            and reference_identity(v2_packets[0][0].parent, reference)
            == (
                v1_packets[0][0],
                digest(v1_packets[0][0]),
            )
        ]
        if len(v1_inputs_of_v2) != 1:
            return fail("D1 V2 completion is not bound to the consumed V1 completion")
        if artifact.name != "package-manifest.json":
            return fail("D1 design artifact must be package-manifest.json")
        try:
            manifest_data = load(artifact)
        except json.JSONDecodeError:
            return fail("D1 package manifest is invalid")
        manifest_error = validate_d1_package_manifest(
            artifact,
            manifest_data,
            packet["run_id"],
            validation,
            packet["validation"].get("sha256"),
        )
        if manifest_error:
            return fail(manifest_error)
        map_path = artifact.parent / "map-data.json"
        try:
            map_data = load(map_path)
        except json.JSONDecodeError:
            return fail("D1 map-data is invalid")
        binding_error = validate_d1_input_binding(
            map_path,
            map_data,
            packet_path,
            packet,
            input_references,
        )
        if binding_error:
            return fail(binding_error)
        required_validation = {
            "schema_version": "1.0",
            "harness": "novel-conception-interview",
            "run_id": packet["run_id"],
            "stage": "D1",
            "mode": "map",
            "verdict": "ready",
            "errors": [],
            "blockers": [],
        }
        if any(validation_data.get(key) != value for key, value in required_validation.items()):
            return fail("stored D1 validation does not identify a clean canonical ready result")
        canonical, canonical_error = canonical_d1_validation(artifact.parent)
        if canonical_error:
            return fail(canonical_error)
        if canonical != validation_data:
            return fail("stored D1 validation differs from canonical revalidation")
    if packet["stage"] == "R1":
        approval = packet.get("final_author_approval", {})
        approval_path = (packet_path.parent / approval.get("path", "")).resolve()
        if (
            not approval_path.is_file()
            or digest(approval_path) != approval.get("sha256")
        ):
            return fail("R1 lacks hash-bound final author approval")
        if artifact.name != "package-manifest.json":
            return fail("R1 design artifact must be package-manifest.json")
        try:
            r1_manifest = load(artifact)
        except json.JSONDecodeError:
            return fail("R1 design artifact is not a valid package manifest")
        r1_manifest_error = validate_r1_package_manifest(
            artifact,
            r1_manifest,
            packet["run_id"],
            validation,
            packet["validation"].get("sha256"),
        )
        if r1_manifest_error:
            return fail(r1_manifest_error)
        required_validation = {
            "schema_version": "1.0",
            "harness": "novel-conception-interview",
            "run_id": packet["run_id"],
            "stage": "R1",
            "mode": "review",
            "verdict": "ready",
            "errors": [],
            "blockers": [],
        }
        if any(
            validation_data.get(key) != value
            for key, value in required_validation.items()
        ):
            return fail(
                "stored R1 validation does not identify a clean canonical ready result"
            )
        canonical, canonical_error = canonical_r1_validation(artifact.parent)
        if canonical_error:
            return fail(canonical_error)
        if canonical != validation_data:
            return fail("stored R1 validation differs from canonical revalidation")
        try:
            approval_data = load(approval_path)
        except json.JSONDecodeError:
            return fail("R1 final author approval is invalid")
        if approval_data.get("run_id") != packet["run_id"] or approval_data.get("approval_scope") != "R1" or approval_data.get("decision") != "approved" or approval_data.get("record_assurance") != "self_recorded":
            return fail("R1 final author approval does not approve this run")
        brief = approval_data.get("review_brief", {})
        brief_path = (approval_path.parent / brief.get("path", "")).resolve()
        record = approval_data.get("approval_record", {})
        review_record = r1_manifest.get("author_review_artifact", {})
        expected_review = (
            artifact.parent / review_record.get("path", "")
        ).resolve()
        if (
            not brief_path.is_file()
            or digest(brief_path) != brief.get("sha256")
            or brief_path != expected_review
            or brief.get("sha256") != review_record.get("sha256")
        ):
            return fail("R1 final approval is not bound to the current review artifact")
        if not isinstance(record.get("event_seq"), int) or not isinstance(record.get("text"), str) or not record["text"].strip():
            return fail("R1 final author approval has no recorded author decision")
        d1_packets = [
            item for item in upstream_packets if item[1].get("stage") == "D1"
        ]
        if len(d1_packets) != 1:
            return fail("R1 must consume exactly one D1 completion")
        d1_path, d1_packet = d1_packets[0]
        d1_error = validate_ready_completion(d1_path)
        if d1_error:
            return fail("R1 cannot consume D1: " + d1_error)
        handoff_path, handoff_data, handoff_reference_error = load_hash_bound_reference(
            packet_path.parent,
            packet.get("independent_handoff"),
            "R1 independent handoff",
        )
        if handoff_reference_error:
            return fail(handoff_reference_error)
        manifest_handoff = r1_manifest.get("independent_handoff", {})
        if reference_identity(
            packet_path.parent, packet.get("independent_handoff")
        ) != reference_identity(artifact.parent, manifest_handoff):
            return fail(
                "R1 completion and package manifest bind different independent handoff records"
            )
        handoff_error = validate_independent_handoff(
            handoff_data,
            packet["run_id"],
            handoff_path,
            d1_path,
            d1_packet,
        )
        if handoff_error:
            return fail(handoff_error)
    print("OK: stage completion is consumable")
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv))
