# Workflow Contract

## Stage graph

```text
I0 Intent ─> I1 Subject ─> I2 World ─> I3 Characters ─> I4 Causality ─> I5 Narrative
                                                                          │
                                                                          v
                         V1 deterministic + semantic integrity gate <────┘
                                      │
                                      v
                         V2 HTML author-review brief ─> Author approval
                                                              │
                                                              v
                                           D1 development map ─> R1 conception review
```

This is a DAG with bounded returns, not a collection of skills that may call
one another directly. In particular, I1 never hands off directly to I3: I2
establishes the world in which characters operate.

## Stage contracts

| Stage | Creative owner | Required inputs | Required output | Entry/exit gate |
| --- | --- | --- | --- | --- |
| I0 | intent facilitator | author's idea | intent card + session | author accepts intended meaning and boundaries |
| I1 | subject designer | I0 completion | subject design + session | I0 `ready`; subject's central conflict is usable |
| I2 | world interviewer | I0–I1 completions | world operating contract + session | I1 `ready`; environment, operating logic and limits are coherent |
| I3 | character interviewer | I0–I2 completions | character design + session | I2 `ready`; agency and relationships can operate under world limits |
| I4 | causality architect | I0–I3 completions | causal storyline + session | I3 `ready`; causes, costs and constraints connect |
| I5 | narrative designer | I0–I4 completions | narrative contract + session | I4 `ready`; reveal/POV/time structure can carry the causal story |
| V1 | integrity auditor + validators | six completion packets | integrity report + semantic-review packet | all session validators `ready`; hash-bound semantic verdict must be `pass` with six-area evidence |
| V2 | brief generator | V1 `pass`, six artifacts | HTML brief + author decision | no missing evidence or hidden uncertainty |
| D1 | development-map designer | current I0–I5 + V1 pass + current V2 completion and approval | hash-bound development-map package manifest and generated completion | hard gate, exact source provenance, control-ID references, all business-derived fields hash-bound, information audiences/lifecycles, deterministic render, structured semantic checks and developer handoff self-test all pass |
| R1 | conception reviewer | validated D1 manifest/model/validation/completion, V1 completion, V2 completion and approval, all artifacts | manifest-bound NDB, review report, role-separated handoff evidence, validation and final author-approval packet | revalidates D1, reviews every derivation claim, independently executes the six-task handoff with real evidence IDs, deterministically renders the package, and binds final approval to the current review report; `ready` completion binds the full R1 manifest |

Every conception run also owns a hash-bound `run-state.json`. Every stage
completion consumes that state and hash-binds every upstream completion. The
state records the current valid I0–I5 completion references; a new stage must
consume those references rather than choose among historical packets. An
active return package blocks every stage except its named target; that target
must carry the same `{path, sha256}` in `return_resolution`. The next run state
records the immutable package plus the target's corrected completion in
`resolved_returns`, and downstream stages must consume that corrected packet.
Every interview session is stored under
`<project>/interview-sessions/<stage>/<session-id>/` with versioned
`plan.vN.json`, append-only-by-contract `events.ndjson`, regenerated `report.md`,
`validation.json`, and `stage-completion.json`. A completion packet names the
design artifact and validation evidence; downstream stages consume the packet,
not a conversational assertion.

## Bounded return rules

Only one active return package may exist at a time. It conforms to
`return-package.schema.json`, is registered in `run-state.json`, and states `origin_stage`,
`target_stage`, defect, evidence, requested decision, and affected artifacts.

- I2 may return to I1 only when the subject choice cannot operate in the world;
  it may return to I0 only for a contradiction in intent.
- I3 returns world gaps to I2, not to I1; it returns a central-subject defect to
  I1 and an intent contradiction to I0.
- I4 returns world facts to I2, character agency or relationship facts to I3,
  subject conflict to I1, and authorial intent to I0.
- I5 returns operational-world facts to I2 and causal facts to I4. It never
  silently repairs upstream meaning.
- V1/R1 issue a structured return package. The named target repeats its session
  with a new plan revision and emits a completion whose `return_resolution`
  hash-binds that package. The run state then records the package and corrected
  target completion as `resolved_returns`; all affected downstream completion
  packets become `superseded` and must be regenerated from the corrected input.
  The origin never rewrites the run state it consumed: it emits a next run state
  with the active return, and the coordinator promotes that validated state.
  References in different directories are compared by resolved path and hash,
  not by identical relative-path spelling.
- If the V2 author decision is `revise`, the harness may create a structured
  return package with origin `V2` only when it hash-binds that exact approval
  packet; the author chooses the affected target stage. A V2 `rejected` decision
  leaves the run `blocked` until the author gives new direction.

Maximum two return rounds per source stage in one conception run. A third
unresolved return produces `blocked` and requires author direction.

## Handoff and approval rules

`ready` means: exact plan presentation was validated, all planned question-answer
pairs were recorded (or an author-approved early close exists), the complete
report was regenerated from the event log and hash-bound, and the design
artifact has an explicit uncertainty register. V1 also requires the semantic
audit. V2 is review-only: its author approval is a separate
`author-approval.json` packet with scope, decision, unresolved items and date.
No downstream agent may infer approval from silence.
