# Harness Rules

## Authority order

1. This file and `workflow.md` define canonical orchestration.
2. JSON schemas and validator verdicts define structural truth.
3. A stage's leaf skill defines its creative method within its assigned stage.
4. Legacy documents under `docs/ai-novel-workflow/` explain compatibility only;
   they cannot alter the stage graph or gates.
5. An author's explicit decision controls artistic values and approvals.

## Evidence and file rules

- Create `plan.v1.json` before asking the first substantive question. It states
  the exact total question budget, per-group allocation, duration estimate,
  output artifact and transcript assurance mode.
- `plan.vN.json` files must not be overwritten. A changed plan is a new version
  linked to an `author_approved_plan_revision` decision event; completion files
  bind the report, design artifact and validation evidence by SHA-256 so later
  edits invalidate their handoff.
- The first event presents plan revision 1 to the author. Every question names
  the currently active `plan_revision`; a revision event must first record the
  author's approval reference and announce its exact revised question budget
  and duration. An early close must likewise name the active revision and an
  explicit approval reference. A later plan may not retroactively legitimise a
  question that was asked under another revision.
- Append one JSON object per event to `events.ndjson`; never rewrite prior
  events. Regenerate, do not hand-edit, `report.md` from the log.
- Run `validate_session.py` after every append and before a stage completion;
  downstream stages accept only `validation.json` verdict `ready`.
- Every completion must hash-bind `run-state.json`; every upstream completion
  reference is `{path, sha256}`. An active return package blocks every stage
  except its named target. That target must hash-bind the package in
  `return_resolution`; the next run state records both the package and that
  corrected completion in `resolved_returns`. Downstream handoffs must consume
  the corrected completion, never a stale pre-return packet.
- After a completion is validated, the controller writes the next run state with
  that I-stage packet as the current completion. Resolving a return clears every
  affected downstream current reference; regenerated stages must consume the
  corrected target packet before becoming current. A third return from one
  origin stage is blocked pending explicit author direction.
- All unresolved facts are recorded as `open`, `provisional`, `inference`, or
  `blocked`; never upgrade them to `confirmed` merely to pass a gate.
- A factual research claim, if needed, must carry claim text, source URL/title,
  retrieval date, scope, confidence, and adoption decision. Research is
  evidence, not a hard-coded fictional fact.

## Transcript assurance

This release supports only `self_recorded`. A future runtime may add
`event_backed` only with an adapter-specific verifier that resolves immutable
event IDs against that runtime; a string supplied by the agent is never proof.
A rendered self-recorded report must visibly say it is a reconstructed record
and cannot claim verbatim or externally event-backed provenance.

## Human approval rules

The author must explicitly approve a plan revision, early close, V2 review
brief, any third return round, and final R1 acceptance. Record V2 approval in
an `author-approval.json` conforming to `author-approval.schema.json`, hash-bind
it to the reviewed HTML, and make D1 consume that exact packet. Agents may
propose choices but cannot manufacture any of these approvals.

V1 must emit a hash-bound semantic-review packet with evidence for all six
control areas. V2, D1 and R1 consume only a V1 packet whose semantic verdict is
`pass`. R1 additionally consumes an author-approval packet scoped to `R1`.

D1 completion must bind `package-manifest.json` as its design artifact. The
manifest must hash-bind `map-data.json`, all three deterministically rendered
business documents, and the same `validation.json` named by the completion.
The main completion validator must re-run the canonical D1 validator, compare
the full result with stored validation, and confirm that D1 and `map-data.json`
bind the same current I0–I5, V1, V2, run-state and V2 approval. Changing or
forging any package member invalidates the completion. D1 records only a
developer handoff self-test; R1 owns the independent six-task handoff test,
must revalidate the consumed D1 completion, and must hash-bind an
`independent-handoff.json` record to that validated manifest. That record must
name a different execution role and reviewer, use the D1 package as its sole
evidence source, exactly cover all D1 units, cite only real control/unit/
information/derivation IDs, and independently review every hash-bound
derivation claim. D1 derivation claims cover every business-derived control
classification, unit field, information obligation, open-item boundary and
terminal-thread classification; information obligations separately identify
their audience and any story-character knowledge holders. Role separation is
auditable workflow evidence; it must not
be described as cryptographic proof that an executor had no prior context.
A hard-gate failure may produce a blocked report, but never a ready map package.

R1 separates the human review artifact from the machine handoff. Its
`package-manifest.json` hash-binds `review-data.json`,
`novel-design-brief.md`, `conception-review.md`,
`independent-handoff.json` and `validation.json`. Final author approval binds
the manifest's current `conception-review.md`; R1 completion binds the
manifest itself plus that approval and the same manifest-bound independent
handoff. The main completion validator re-runs the canonical R1 validator and
rejects any changed, omitted or hand-edited package member.

## Done rule

Do not state that a conception is complete, reviewable, or ready for development
unless V1 validation/semantic evidence, V2 author approval, D1 output and R1
verdict are all present. Do not use a legacy direct handoff to evade a gate.
