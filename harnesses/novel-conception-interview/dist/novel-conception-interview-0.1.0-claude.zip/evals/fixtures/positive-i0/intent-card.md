# Intent card fixture

The fixture preserves a story meaning and a stated expression boundary.
